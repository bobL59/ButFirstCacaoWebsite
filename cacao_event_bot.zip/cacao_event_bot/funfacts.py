import requests
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.constants import ParseMode
from telegram.ext import ContextTypes, ConversationHandler
from common import get_go_back_button, go_back_handler, get_env_vars, get_start_menu
from constants import ADD_FACT_TITLE, ADD_FACT_TEXT, DELETE_FACT_CHOOSE, DELETE_FACT_CONFIRM

# Get environment variables
env = get_env_vars()
FUN_FACTS_URL = env['FUN_FACTS_URL']
API_SECRET = env['API_SECRET']

# Helper to generate the fun facts message
FUNFACTS_MESSAGE = (
    "📝 <b>Fun Facts</b>\n"
    "Select an action below:"
)

# Inline keyboard for fun facts actions
FUNFACTS_KEYBOARD = [
    [InlineKeyboardButton("Add a new fun fact", callback_data="addfact")],
    [InlineKeyboardButton("View all fun facts", callback_data="listfacts")],
    [InlineKeyboardButton("Remove a fun fact", callback_data="deletefact")],
    get_go_back_button(),
]
FUNFACTS_REPLY_MARKUP = InlineKeyboardMarkup(FUNFACTS_KEYBOARD)

async def funfacts(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Handles both command and callback
    if update.message:
        await update.message.reply_text(
            FUNFACTS_MESSAGE,
            parse_mode=ParseMode.HTML,
            reply_markup=FUNFACTS_REPLY_MARKUP
        )
    elif update.callback_query:
        query = update.callback_query
        await query.answer()
        if query.data == "go_back":
            await go_back_handler(update, context)
            return
        await query.edit_message_text(
            FUNFACTS_MESSAGE,
            parse_mode=ParseMode.HTML,
            reply_markup=FUNFACTS_REPLY_MARKUP
        )

async def addfact(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start the add fact conversation"""
    query = update.callback_query
    await query.answer()
    await query.edit_message_text("Please send the fun fact title:")
    return ADD_FACT_TITLE

async def add_fact_title(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle the fun fact title input"""
    context.user_data['fact_title'] = update.message.text
    await update.message.reply_text("Now send the fun fact text:")
    return ADD_FACT_TEXT

async def add_fact_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle the fun fact text input and save to API"""
    try:
        fact_data = {
            'title': context.user_data['fact_title'],
            'text': update.message.text,
            'secret': API_SECRET
        }
        resp = requests.post(FUN_FACTS_URL, json=fact_data)
        if resp.status_code == 200:
            await update.message.reply_text("Fun fact added successfully!")
        else:
            await update.message.reply_text(f"Failed to add fun fact: {resp.text}")
    except Exception as e:
        await update.message.reply_text(f"Error adding fun fact: {e}")
    
    # Return to main menu after adding fact
    welcome_message, reply_markup = get_start_menu()
    await update.message.reply_text(welcome_message, reply_markup=reply_markup)
    return ConversationHandler.END

async def listfacts(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """List all fun facts"""
    query = update.callback_query
    await query.answer()
    
    try:
        resp = requests.get(FUN_FACTS_URL)
        if resp.status_code == 200:
            facts = resp.json()
        else:
            await query.edit_message_text(f"Failed to fetch fun facts: {resp.text}")
            # Return to main menu after error
            welcome_message, reply_markup = get_start_menu()
            await query.message.reply_text(welcome_message, reply_markup=reply_markup)
            return
    except Exception as e:
        await query.edit_message_text(f"Error fetching fun facts: {e}")
        # Return to main menu after error
        welcome_message, reply_markup = get_start_menu()
        await query.message.reply_text(welcome_message, reply_markup=reply_markup)
        return
    
    if not facts:
        await query.edit_message_text("No fun facts found.")
        # Return to main menu when no facts found
        welcome_message, reply_markup = get_start_menu()
        await query.message.reply_text(welcome_message, reply_markup=reply_markup)
        return

    # Split facts into chunks
    chunk_size = 5  # Number of facts per message
    for i in range(0, len(facts), chunk_size):
        chunk = facts[i:i + chunk_size]
        msg = f"Fun Facts (Part {i//chunk_size + 1}):\n"
        for f in chunk:
            msg += f"\n<b>{f['title']}</b>\n{f['text']}\n"
        if i == 0:
            await query.edit_message_text(msg, parse_mode='HTML')
        else:
            await query.message.reply_text(msg, parse_mode='HTML')
    
    # Return to main menu after listing all facts
    welcome_message, reply_markup = get_start_menu()
    await query.message.reply_text(welcome_message, reply_markup=reply_markup)

async def deletefact(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start the delete fact conversation"""
    query = update.callback_query
    await query.answer()
    
    try:
        resp = requests.get(FUN_FACTS_URL)
        if resp.status_code == 200:
            facts = resp.json()
        else:
            await query.edit_message_text(f"Failed to fetch fun facts: {resp.text}")
            return ConversationHandler.END
    except Exception as e:
        await query.edit_message_text(f"Error fetching fun facts: {e}")
        return ConversationHandler.END
    
    if not facts:
        await query.edit_message_text("No fun facts to delete.")
        return ConversationHandler.END
    
    context.user_data['facts'] = facts
    
    # Split facts into chunks
    chunk_size = 10  # Number of facts per message
    for i in range(0, len(facts), chunk_size):
        chunk = facts[i:i + chunk_size]
        msg = f"Which fun fact do you want to delete? (Part {i//chunk_size + 1})\nReply with the number.\n"
        for j, f in enumerate(chunk):
            msg += f"\n{i+j+1}. <b>{f['title']}</b>"
        if i == 0:
            await query.edit_message_text(msg, parse_mode='HTML')
        else:
            await query.message.reply_text(msg, parse_mode='HTML')
    
    return DELETE_FACT_CHOOSE

async def delete_fact_choose(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle the fact selection for deletion"""
    text = update.message.text.strip()
    if not text.isdigit():
        await update.message.reply_text("Please reply with a valid number.")
        return DELETE_FACT_CHOOSE
    
    idx = int(text) - 1
    facts = context.user_data.get('facts', [])
    if idx < 0 or idx >= len(facts):
        await update.message.reply_text("Number out of range. Try again.")
        return DELETE_FACT_CHOOSE
    
    context.user_data['delete_fact_idx'] = idx
    f = facts[idx]
    msg = f"Are you sure you want to delete <b>{f['title']}</b>? Reply YES to confirm, or /cancel."
    await update.message.reply_text(msg, parse_mode='HTML')
    return DELETE_FACT_CONFIRM

async def delete_fact_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle the deletion confirmation"""
    if update.message.text.strip().upper() != 'YES':
        await update.message.reply_text("Deletion cancelled.")
        # Return to main menu
        welcome_message, reply_markup = get_start_menu()
        await update.message.reply_text(welcome_message, reply_markup=reply_markup)
        return ConversationHandler.END
    
    idx = context.user_data.get('delete_fact_idx')
    if idx is None:
        await update.message.reply_text("No fun fact selected.")
        # Return to main menu
        welcome_message, reply_markup = get_start_menu()
        await update.message.reply_text(welcome_message, reply_markup=reply_markup)
        return ConversationHandler.END
    
    facts = context.user_data.get('facts', [])
    if idx < len(facts):
        fact_id = facts[idx]['id']
        try:
            resp = requests.delete(f"{FUN_FACTS_URL}/{fact_id}", json={'secret': API_SECRET})
            if resp.status_code == 200:
                await update.message.reply_text("Fun fact deleted!")
            else:
                await update.message.reply_text(f"Failed to delete fun fact: {resp.text}")
        except Exception as e:
            await update.message.reply_text(f"Error deleting fun fact: {e}")
    
    # Return to main menu after deletion
    welcome_message, reply_markup = get_start_menu()
    await update.message.reply_text(welcome_message, reply_markup=reply_markup)
    return ConversationHandler.END

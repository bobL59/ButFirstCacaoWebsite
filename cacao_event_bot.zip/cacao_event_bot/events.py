from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, InputMediaPhoto
from telegram.constants import ParseMode
from telegram.ext import ContextTypes
from common import get_go_back_button, go_back_handler, get_env_vars, get_start_menu
from constants import (
    ADD_EVENT_TITLE, ADD_EVENT_DATE, ADD_EVENT_START_TIME, ADD_EVENT_END_TIME, ADD_EVENT_DESC, ADD_EVENT_IMAGE, ADD_EVENT_VISIBILITY,
    DELETE_EVENT_CHOOSE, DELETE_EVENT_CONFIRM
)
import requests
from datetime import datetime
from telegram.ext import ConversationHandler, CallbackQueryHandler, MessageHandler, CommandHandler, filters
from handlers import cancel

# Helper to generate the events message
EVENTS_MESSAGE = (
    "📅 <b>Events</b>\n"
    "Select an action below:"
)

# Inline keyboard for event actions
EVENTS_KEYBOARD = [
    [InlineKeyboardButton("Create a new event", callback_data="addevent")],
    [InlineKeyboardButton("View all events", callback_data="listevents")],
    [InlineKeyboardButton("Remove an event", callback_data="deleteevent")],
    get_go_back_button(),
]
EVENTS_REPLY_MARKUP = InlineKeyboardMarkup(EVENTS_KEYBOARD)

# Inline keyboard for 'Done' during image upload
DONE_KEYBOARD = InlineKeyboardMarkup([[InlineKeyboardButton('Done', callback_data='done_adding_images')]])

# Inline keyboard for 'Skip' during time entry
SKIP_KEYBOARD = InlineKeyboardMarkup([[InlineKeyboardButton('Skip', callback_data='skip_time')]])

# Inline keyboard for visibility choice
VISIBILITY_KEYBOARD = InlineKeyboardMarkup([
    [
        InlineKeyboardButton('Both', callback_data='visibility_both'),
        InlineKeyboardButton('Website', callback_data='visibility_website'),
        InlineKeyboardButton('Channel', callback_data='visibility_channel'),
    ]
])

# Helper to reply regardless of update type
async def safe_reply(update, text, **kwargs):
    if hasattr(update, 'message') and update.message:
        return await update.message.reply_text(text, **kwargs)
    elif hasattr(update, 'callback_query') and update.callback_query and update.callback_query.message:
        return await update.callback_query.message.reply_text(text, **kwargs)
    else:
        return None

async def events(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Handles both command and callback
    if update.message:
        await update.message.reply_text(
            EVENTS_MESSAGE,
            parse_mode=ParseMode.HTML,
            reply_markup=EVENTS_REPLY_MARKUP
        )
    elif update.callback_query:
        query = update.callback_query
        await query.answer()
        if query.data == "go_back":
            await go_back_handler(update, context)
            return
        await query.edit_message_text(
            EVENTS_MESSAGE,
            parse_mode=ParseMode.HTML,
            reply_markup=EVENTS_REPLY_MARKUP
        )

async def list_events(update, context):
    env = get_env_vars()
    API_URL = env['API_URL']
    try:
        resp = requests.get(f"{API_URL}/all")
        if resp.status_code == 200:
            events = resp.json()
        else:
            if update.message:
                await update.message.reply_text(f"Failed to fetch events from website: {resp.text}")
            elif update.callback_query:
                await update.callback_query.edit_message_text(f"Failed to fetch events from website: {resp.text}")
            return
    except Exception as e:
        if update.message:
            await update.message.reply_text(f"Error fetching events from website: {e}")
        elif update.callback_query:
            await update.callback_query.edit_message_text(f"Error fetching events from website: {e}")
        return
    if not events:
        if update.message:
            await update.message.reply_text("No events found.")
        elif update.callback_query:
            await update.callback_query.edit_message_text("No events found.")
        # Show main menu even if no events
        welcome_message, reply_markup = get_start_menu()
        if update.message:
            await update.message.reply_text(welcome_message, reply_markup=reply_markup)
        elif update.callback_query:
            await update.callback_query.message.reply_text(welcome_message, reply_markup=reply_markup)
        return
    chunk_size = 5
    for i in range(0, len(events), chunk_size):
        chunk = events[i:i + chunk_size]
        msg = f"Events (Part {i//chunk_size + 1}):\n"
        for e in chunk:
            msg += f"\n<b>{e['title']}</b>\nDate: {e['date']}"
            if e.get('start_time') or e.get('end_time'):
                msg += "\nTime: "
                if e.get('start_time'):
                    msg += e['start_time']
                    if e.get('end_time'):
                        msg += f" - {e['end_time']}"
                elif e.get('end_time'):
                    msg += e['end_time']
            msg += f"\n{e['desc']}\n"
            msg += f"Visibility: {e.get('visibility', 'both')}\n"
        if update.message:
            await update.message.reply_text(msg, parse_mode='HTML', disable_web_page_preview=False)
        elif update.callback_query:
            await update.callback_query.message.reply_text(msg, parse_mode='HTML', disable_web_page_preview=False)
    # After all chunks, show main menu
    welcome_message, reply_markup = get_start_menu()
    if update.message:
        await update.message.reply_text(welcome_message, reply_markup=reply_markup)
    elif update.callback_query:
        await update.callback_query.message.reply_text(welcome_message, reply_markup=reply_markup)

async def add_event_start(update, context):
    if update.message:
        await update.message.reply_text("Please send the event title:")
    elif update.callback_query:
        await update.callback_query.edit_message_text("Please send the event title:")
    return ADD_EVENT_TITLE

async def add_event_title(update, context):
    context.user_data['title'] = update.message.text
    await update.message.reply_text("Now send the event date (e.g. 2024-07-01):")
    return ADD_EVENT_DATE

async def add_event_date(update, context):
    date_text = update.message.text
    try:
        datetime.strptime(date_text, "%Y-%m-%d")
    except ValueError:
        await update.message.reply_text("Invalid date format. Please use YYYY-MM-DD (e.g. 2024-07-01):")
        return ADD_EVENT_DATE
    context.user_data['date'] = date_text
    await update.message.reply_text(
        "Now send the event start time (e.g. 14:30) or press 'Skip' if there's no start time:",
        reply_markup=SKIP_KEYBOARD
    )
    return ADD_EVENT_START_TIME

# Handler for 'Skip' start time
async def skip_start_time(update, context):
    query = update.callback_query
    await query.answer()
    context.user_data['start_time'] = None
    await query.edit_message_text(
        "Now send the event description:"
    )
    return ADD_EVENT_DESC

async def add_event_start_time(update, context):
    time_text = update.message.text.strip().lower()
    if time_text == 'skip':
        context.user_data['start_time'] = None
        await update.message.reply_text("Now send the event description:")
        return ADD_EVENT_DESC
    else:
        try:
            datetime.strptime(time_text, "%H:%M")
            context.user_data['start_time'] = time_text
            await update.message.reply_text(
                "Now send the event end time (e.g. 16:30) or press 'Skip' if there's no end time:",
                reply_markup=SKIP_KEYBOARD
            )
            return ADD_EVENT_END_TIME
        except ValueError:
            await update.message.reply_text("Invalid time format. Please use HH:MM (e.g. 14:30) or press 'Skip':", reply_markup=SKIP_KEYBOARD)
            return ADD_EVENT_START_TIME

# Handler for 'Skip' end time
async def skip_end_time(update, context):
    query = update.callback_query
    await query.answer()
    context.user_data['end_time'] = None
    await query.edit_message_text(
        "Now send the event description:"
    )
    return ADD_EVENT_DESC

async def add_event_end_time(update, context):
    time_text = update.message.text.strip().lower()
    if time_text == 'skip':
        context.user_data['end_time'] = None
        await update.message.reply_text("Now send the event description:")
        return ADD_EVENT_DESC
    else:
        try:
            datetime.strptime(time_text, "%H:%M")
            context.user_data['end_time'] = time_text
            await update.message.reply_text("Now send the event description:")
            return ADD_EVENT_DESC
        except ValueError:
            await update.message.reply_text("Invalid time format. Please use HH:MM (e.g. 16:30) or press 'Skip':", reply_markup=SKIP_KEYBOARD)
            return ADD_EVENT_END_TIME

async def add_event_desc(update, context):
    try:
        context.user_data['desc'] = update.message.text
        context.user_data['images'] = []
        context.user_data['image_file_ids'] = []
        await update.message.reply_text(
            "Now send all images for the event, one by one. When done, press 'Done'.",
            reply_markup=DONE_KEYBOARD
        )
        return ADD_EVENT_IMAGE
    except Exception as e:
        await update.message.reply_text(f"Error in add_event_desc: {e}")
        return ConversationHandler.END

# Handler for visibility inline buttons
async def visibility_choice(update, context):
    query = update.callback_query
    await query.answer()
    data = query.data
    if data == 'visibility_both':
        visibility = 'both'
    elif data == 'visibility_website':
        visibility = 'website'
    elif data == 'visibility_channel':
        visibility = 'channel'
    else:
        await query.edit_message_text("Invalid option. Please choose again.", reply_markup=VISIBILITY_KEYBOARD)
        return ADD_EVENT_VISIBILITY
    context.user_data['visibility'] = visibility
    await query.edit_message_text(f"Selected: {visibility.capitalize()}")
    return await add_event_visibility(update, context)

async def add_event_image(update, context):
    # Only handle 'done' if it's a callback query now
    image_url = None
    file_id = None
    if update.message and update.message.photo:
        photo = update.message.photo[-1]
        file_id = photo.file_id
        file = await update.message.get_bot().get_file(file_id)
        image_url = file.file_path
    elif update.message and update.message.text and update.message.text.startswith('http'):
        image_url = update.message.text
    elif update.message:
        await update.message.reply_text("Please send a valid image or press 'Done' if finished.", reply_markup=DONE_KEYBOARD)
        return ADD_EVENT_IMAGE
    else:
        # If not a message (e.g., callback), ignore here
        return ADD_EVENT_IMAGE
    context.user_data['images'].append(image_url)
    context.user_data['image_file_ids'].append(file_id)
    await update.message.reply_text(
        f"Image added! Send another image, or press 'Done' if finished.",
        reply_markup=DONE_KEYBOARD
    )
    return ADD_EVENT_IMAGE

async def done_adding_images(update, context):
    query = update.callback_query
    await query.answer()
    if not context.user_data.get('images'):
        await query.edit_message_text("Please send at least one image before finishing.")
        return ADD_EVENT_IMAGE
    await query.edit_message_text(
        "Where should this event be displayed?",
        reply_markup=VISIBILITY_KEYBOARD
    )
    return ADD_EVENT_VISIBILITY

async def add_event_visibility(update, context):
    env = get_env_vars()
    API_URL = env['API_URL']
    API_SECRET = env['API_SECRET']
    CHANNEL_ID = env['CHANNEL_ID']
    # Always get visibility from context.user_data
    visibility = context.user_data.get('visibility', '').strip().lower()
    if visibility not in ['both', 'website', 'channel']:
        await safe_reply(update, "Invalid option. Please reply with 'both', 'website', or 'channel':")
        return ADD_EVENT_VISIBILITY
    channel_message_ids = []
    time_display = ""
    if context.user_data.get('start_time'):
        time_display = f" at {context.user_data['start_time']}"
        if context.user_data.get('end_time'):
            time_display += f" - {context.user_data['end_time']}"
    # Send all images to the channel as an album if multiple
    if visibility in ['both', 'channel'] and CHANNEL_ID:
        try:
            images = context.user_data.get('images', [])
            image_file_ids = context.user_data.get('image_file_ids', [])
            caption = (
                f"<b>{context.user_data['title']}</b>\n"
                f"Date: {context.user_data['date']}{time_display}\n"
                f"{context.user_data['desc']}"
            )
            media = []
            # Use up to 10 images for Telegram album
            for idx, (img_url, file_id) in enumerate(zip(images, image_file_ids)):
                if idx == 0:
                    media.append(InputMediaPhoto(media=file_id or img_url, caption=caption, parse_mode='HTML'))
                else:
                    media.append(InputMediaPhoto(media=file_id or img_url))
            if len(media) > 1:
                sent_msgs = await update.get_bot().send_media_group(chat_id=CHANNEL_ID, media=media)
                channel_message_ids = [msg.message_id for msg in sent_msgs]
            elif len(media) == 1:
                sent_msg = await update.get_bot().send_photo(chat_id=CHANNEL_ID, photo=media[0].media, caption=caption, parse_mode='HTML')
                channel_message_ids = [sent_msg.message_id]
        except Exception as e:
            await safe_reply(update, f"Event added, but failed to send to channel: {e}")
    try:
        event_data = {
            'title': context.user_data['title'],
            'date': context.user_data['date'],
            'start_time': context.user_data.get('start_time'),
            'end_time': context.user_data.get('end_time'),
            'desc': context.user_data['desc'],
            'images': context.user_data['images'],
            'channel_message_ids': channel_message_ids,
            'visibility': visibility
        }
        resp = requests.post(f"{API_URL}/local", json={**event_data, 'secret': API_SECRET})
        if resp.status_code == 200:
            await safe_reply(update, "Event added successfully!")
        else:
            await safe_reply(update, f"Failed to store event: {resp.text}")
    except Exception as e:
        await safe_reply(update, f"Error processing event: {e}")
    # Show main menu after event creation
    welcome_message, reply_markup = get_start_menu()
    await safe_reply(update, welcome_message, reply_markup=reply_markup)
    return ConversationHandler.END

async def delete_event_start(update, context):
    env = get_env_vars()
    API_URL = env['API_URL']
    try:
        resp = requests.get(f"{API_URL}/all")
        if resp.status_code == 200:
            events = resp.json()
        else:
            if update.message:
                await update.message.reply_text(f"Failed to fetch events: {resp.text}")
            elif update.callback_query:
                await update.callback_query.edit_message_text(f"Failed to fetch events: {resp.text}")
            return ConversationHandler.END
    except Exception as e:
        if update.message:
            await update.message.reply_text(f"Error fetching events: {e}")
        elif update.callback_query:
            await update.callback_query.edit_message_text(f"Error fetching events: {e}")
        return ConversationHandler.END
    if not events:
        if update.message:
            await update.message.reply_text("No events to delete.")
        elif update.callback_query:
            await update.callback_query.edit_message_text("No events to delete.")
        return ConversationHandler.END
    context.user_data['events'] = events
    chunk_size = 10
    for i in range(0, len(events), chunk_size):
        chunk = events[i:i + chunk_size]
        msg = f"Which event do you want to delete? (Part {i//chunk_size + 1})\nReply with the number.\n"
        for j, e in enumerate(chunk):
            msg += f"\n{i+j+1}. <b>{e['title']}</b> ({e['date']}) - {e.get('visibility', 'both')}"
        if update.message:
            await update.message.reply_text(msg, parse_mode='HTML')
        elif update.callback_query:
            if i == 0:
                await update.callback_query.edit_message_text(msg, parse_mode='HTML')
            else:
                await update.callback_query.message.reply_text(msg, parse_mode='HTML')
    return DELETE_EVENT_CHOOSE

async def delete_event_choose(update, context):
    events = context.user_data.get('events', [])
    try:
        choice = int(update.message.text.strip())
        if not (1 <= choice <= len(events)):
            raise ValueError
    except ValueError:
        await update.message.reply_text(f"Please reply with a valid number between 1 and {len(events)}.")
        return DELETE_EVENT_CHOOSE
    context.user_data['delete_idx'] = choice - 1  # zero-based index
    event = events[choice - 1]
    await update.message.reply_text(
        f"Are you sure you want to delete the event:\n<b>{event['title']}</b> ({event['date']})?\n\nReply with YES to confirm.",
        parse_mode='HTML'
    )
    return DELETE_EVENT_CONFIRM

async def delete_event_confirm(update, context):
    env = get_env_vars()
    API_URL = env['API_URL']
    API_SECRET = env['API_SECRET']
    CHANNEL_ID = env['CHANNEL_ID']
    if update.message.text.strip().upper() != 'YES':
        await update.message.reply_text("Deletion cancelled.")
        # Show main menu after cancellation
        welcome_message, reply_markup = get_start_menu()
        await update.message.reply_text(welcome_message, reply_markup=reply_markup)
        return ConversationHandler.END
    idx = context.user_data.get('delete_idx')
    if idx is None:
        await update.message.reply_text("No event selected.")
        # Show main menu if no event selected
        welcome_message, reply_markup = get_start_menu()
        await update.message.reply_text(welcome_message, reply_markup=reply_markup)
        return ConversationHandler.END
    events = context.user_data.get('events', [])
    # Collect all possible channel message IDs (array or single)
    channel_message_ids = []
    if idx < len(events):
        event = events[idx]
        # Support both new and old format
        if 'channel_message_ids' in event and isinstance(event['channel_message_ids'], list):
            channel_message_ids = event['channel_message_ids']
        elif 'channel_message_id' in event and event['channel_message_id']:
            channel_message_ids = [event['channel_message_id']]
    try:
        resp = requests.delete(f"{API_URL}/{idx}", json={'secret': API_SECRET})
        if resp.status_code == 200:
            await update.message.reply_text("Event deleted!")
            # Always attempt to delete all channel messages
            if CHANNEL_ID and channel_message_ids:
                for msg_id in channel_message_ids:
                    try:
                        await update.message.get_bot().delete_message(chat_id=CHANNEL_ID, message_id=msg_id)
                    except Exception as e:
                        await update.message.reply_text(f"Event deleted, but failed to delete channel message {msg_id}: {e}")
        else:
            await update.message.reply_text(f"Failed to delete event: {resp.text}")
    except Exception as e:
        await update.message.reply_text(f"Error deleting event: {e}")
    # Show main menu after deletion attempt
    welcome_message, reply_markup = get_start_menu()
    await update.message.reply_text(welcome_message, reply_markup=reply_markup)
    return ConversationHandler.END

delete_event_conv = ConversationHandler(
    entry_points=[CallbackQueryHandler(delete_event_start, pattern=r'^deleteevent$')],
    states={
        DELETE_EVENT_CHOOSE: [MessageHandler(filters.TEXT & ~filters.COMMAND, delete_event_choose)],
        DELETE_EVENT_CONFIRM: [MessageHandler(filters.TEXT & ~filters.COMMAND, delete_event_confirm)],
    },
    fallbacks=[CommandHandler('cancel', cancel)],
)

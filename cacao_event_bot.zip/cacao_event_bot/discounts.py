from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.constants import ParseMode
from telegram.ext import ContextTypes, ConversationHandler
from common import get_go_back_button, go_back_handler
from constants import (
    ADD_DISCOUNT_TITLE, ADD_DISCOUNT_DESC, ADD_DISCOUNT_OCCURRENCE, ADD_DISCOUNT_IMAGES, DELETE_DISCOUNT_CHOOSE, DELETE_DISCOUNT_CONFIRM, TOGGLE_DISCOUNT_CHOOSE,
    ADD_DISCOUNT_IMAGE_UPLOAD, ADD_DISCOUNT_DONE_IMAGES
)
import requests
from common import get_env_vars

# Helper to generate the discounts message
DISCOUNTS_MESSAGE = (
    "💸 <b>Discounts</b>\nSelect an action below:"
)

# Inline keyboard for discounts actions
DISCOUNTS_KEYBOARD = [
    [InlineKeyboardButton("Add a new discount", callback_data="adddiscount")],
    [InlineKeyboardButton("Delete a discount", callback_data="deletediscount")],
    [InlineKeyboardButton("List all discounts", callback_data="listdiscounts")],
    [InlineKeyboardButton("Toggle discount visibility", callback_data="togglediscount")],
    get_go_back_button(),
]
DISCOUNTS_REPLY_MARKUP = InlineKeyboardMarkup(DISCOUNTS_KEYBOARD)

env = get_env_vars()
DISCOUNTS_URL = env.get('DISCOUNTS_URL', 'http://localhost:3001/api/discounts')
API_SECRET = env['API_SECRET']

def get_effective_message(update):
    if update.callback_query:
        return update.callback_query.message
    return update.message

async def discounts(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message:
        await update.message.reply_text(
            DISCOUNTS_MESSAGE,
            parse_mode=ParseMode.HTML,
            reply_markup=DISCOUNTS_REPLY_MARKUP
        )
    elif update.callback_query:
        query = update.callback_query
        await query.answer()
        data = query.data
        if data == "go_back":
            await go_back_handler(update, context)
            return
        elif data == "adddiscount":
            await add_discount_start(update, context)
            return
        elif data == "deletediscount":
            await delete_discount_start(update, context)
            return
        elif data == "listdiscounts":
            await list_discounts(update, context)
            return
        elif data == "togglediscount":
            await toggle_discount_visibility(update, context)
            return
        # Default: re-show the menu
        await query.edit_message_text(
            DISCOUNTS_MESSAGE,
            parse_mode=ParseMode.HTML,
            reply_markup=DISCOUNTS_REPLY_MARKUP
        )

# --- Add Discount Flow ---
async def add_discount_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await get_effective_message(update).reply_text("Please enter the title of the new discount:")
    return ADD_DISCOUNT_TITLE

async def add_discount_title(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['discount_title'] = update.message.text
    await get_effective_message(update).reply_text("Please enter the description for the discount:")
    return ADD_DISCOUNT_DESC

async def add_discount_desc(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['discount_desc'] = update.message.text
    await get_effective_message(update).reply_text("Please enter the occurrence (e.g. 'June - August 2024'):")
    return ADD_DISCOUNT_OCCURRENCE

async def add_discount_occurrence(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['discount_occurrence'] = update.message.text
    context.user_data['discount_images'] = []
    # Inline keyboard for 'Done' button
    keyboard = [[InlineKeyboardButton('Done', callback_data='done_adding_discount_images')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await get_effective_message(update).reply_text(
        "Please send images for the discount (as files/photos). Press 'Done' when finished.",
        reply_markup=reply_markup
    )
    return ADD_DISCOUNT_IMAGE_UPLOAD

async def add_discount_image_upload(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Accept photo uploads
    if update.message.photo:
        photo = update.message.photo[-1]
        file = await update.message.get_bot().get_file(photo.file_id)
        file_path = file.file_path
        # Fix: Use file_path as is if it starts with http, else prepend the bot token URL
        if file_path.startswith('http'):
            image_url = file_path
        else:
            bot_token = context.bot.token
            image_url = f"https://api.telegram.org/file/bot{bot_token}/{file_path}"
        import requests as pyrequests
        import os
        from uuid import uuid4
        ext = os.path.splitext(file_path)[1] or '.jpg'
        filename = f"discount_{uuid4().hex}{ext}"
        save_path = os.path.join(os.path.dirname(__file__), '../Website/images/discounts', filename)
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        try:
            with pyrequests.get(image_url, stream=True) as r:
                r.raise_for_status()
                with open(save_path, 'wb') as f:
                    for chunk in r.iter_content(chunk_size=8192):
                        f.write(chunk)
            rel_path = f"/images/discounts/{filename}"
            context.user_data['discount_images'].append(rel_path)
            # Always show the 'Done' button after each image
            keyboard = [[InlineKeyboardButton('Done', callback_data='done_adding_discount_images')]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await get_effective_message(update).reply_text(
                f"Image received. Send more or press 'Done'.", reply_markup=reply_markup
            )
        except Exception as e:
            keyboard = [[InlineKeyboardButton('Done', callback_data='done_adding_discount_images')]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await get_effective_message(update).reply_text(
                f"Failed to download image: {e}. You can try again or press 'Done'.", reply_markup=reply_markup
            )
    else:
        keyboard = [[InlineKeyboardButton('Done', callback_data='done_adding_discount_images')]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await get_effective_message(update).reply_text(
            "Please send a photo (not a URL or text). Or press 'Done' if finished.", reply_markup=reply_markup
        )
    return ADD_DISCOUNT_IMAGE_UPLOAD

async def add_discount_done_images(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Called when user presses 'Done' button
    payload = {
        'title': context.user_data['discount_title'],
        'description': context.user_data['discount_desc'],
        'occurrence': context.user_data['discount_occurrence'],
        'images': context.user_data.get('discount_images', []),
        'secret': API_SECRET
    }
    try:
        resp = requests.post(DISCOUNTS_URL, json=payload)
        if resp.status_code == 200:
            await get_effective_message(update).reply_text("Discount added successfully!")
        else:
            await get_effective_message(update).reply_text(f"Failed to add discount: {resp.text}")
    except Exception as e:
        await get_effective_message(update).reply_text(f"Error adding discount: {e}")
    from handlers import get_start_menu
    welcome_message, reply_markup = get_start_menu()
    await get_effective_message(update).reply_text(welcome_message, reply_markup=reply_markup)
    return ConversationHandler.END

# --- List Discounts ---
async def list_discounts(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        resp = requests.get(DISCOUNTS_URL)
        if resp.status_code == 200:
            discounts = resp.json()
        else:
            await get_effective_message(update).reply_text(f"Failed to fetch discounts: {resp.text}")
            from handlers import get_start_menu
            welcome_message, reply_markup = get_start_menu()
            await get_effective_message(update).reply_text(welcome_message, reply_markup=reply_markup)
            return ConversationHandler.END
    except Exception as e:
        await get_effective_message(update).reply_text(f"Error fetching discounts: {e}")
        from handlers import get_start_menu
        welcome_message, reply_markup = get_start_menu()
        await get_effective_message(update).reply_text(welcome_message, reply_markup=reply_markup)
        return ConversationHandler.END
    if not discounts:
        await get_effective_message(update).reply_text("No discounts found.")
    else:
        chunk_size = 5
        for i in range(0, len(discounts), chunk_size):
            chunk = discounts[i:i + chunk_size]
            msg = f"Discounts (Part {i//chunk_size + 1}):\n\n"
            for idx, discount in enumerate(chunk):
                status = "👁️ Hidden" if discount.get('visibility') == 'hidden' else "👁️ Visible"
                msg += f"<b>{discount.get('title')}</b> - {status}\nOccurrence: {discount.get('occurrence','')}\nDescription: {discount.get('description','')}\nImages: {len(discount.get('images', []))} 📸\n\n"
            await get_effective_message(update).reply_text(msg, parse_mode='HTML')
    from handlers import get_start_menu
    welcome_message, reply_markup = get_start_menu()
    await get_effective_message(update).reply_text(welcome_message, reply_markup=reply_markup)
    return ConversationHandler.END

# --- Delete Discount Flow ---
async def delete_discount_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        resp = requests.get(DISCOUNTS_URL)
        if resp.status_code == 200:
            discounts = resp.json()
        else:
            await get_effective_message(update).reply_text(f"Failed to fetch discounts: {resp.text}")
            from handlers import get_start_menu
            welcome_message, reply_markup = get_start_menu()
            await get_effective_message(update).reply_text(welcome_message, reply_markup=reply_markup)
            return ConversationHandler.END
    except Exception as e:
        await get_effective_message(update).reply_text(f"Error fetching discounts: {e}")
        from handlers import get_start_menu
        welcome_message, reply_markup = get_start_menu()
        await get_effective_message(update).reply_text(welcome_message, reply_markup=reply_markup)
        return ConversationHandler.END
    if not discounts:
        await get_effective_message(update).reply_text("No discounts to delete.")
        from handlers import get_start_menu
        welcome_message, reply_markup = get_start_menu()
        await get_effective_message(update).reply_text(welcome_message, reply_markup=reply_markup)
        return ConversationHandler.END
    context.user_data['discounts'] = discounts
    chunk_size = 10
    for i in range(0, len(discounts), chunk_size):
        chunk = discounts[i:i + chunk_size]
        msg = f"Which discount do you want to delete? (Part {i//chunk_size + 1})\nReply with the number.\n"
        for j, discount in enumerate(chunk):
            msg += f"\n{i+j+1}. {discount.get('title')}"
        await get_effective_message(update).reply_text(msg)
    return DELETE_DISCOUNT_CHOOSE

async def delete_discount_choose(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    if not text.isdigit():
        await get_effective_message(update).reply_text("Please reply with a valid number.")
        return DELETE_DISCOUNT_CHOOSE
    idx = int(text) - 1
    discounts = context.user_data.get('discounts', [])
    if idx < 0 or idx >= len(discounts):
        await get_effective_message(update).reply_text("Number out of range. Try again.")
        return DELETE_DISCOUNT_CHOOSE
    context.user_data['delete_discount'] = idx
    name = discounts[idx].get('title')
    msg = f"Are you sure you want to delete {name}? Reply YES to confirm, or /cancel."
    await get_effective_message(update).reply_text(msg)
    return DELETE_DISCOUNT_CONFIRM

async def delete_discount_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message.text.strip().upper() != 'YES':
        await get_effective_message(update).reply_text("Deletion cancelled.")
        from handlers import get_start_menu
        welcome_message, reply_markup = get_start_menu()
        await get_effective_message(update).reply_text(welcome_message, reply_markup=reply_markup)
        return ConversationHandler.END
    idx = context.user_data.get('delete_discount')
    discounts = context.user_data.get('discounts', [])
    # Delete images from server
    if 0 <= idx < len(discounts):
        images = discounts[idx].get('images', [])
        import os
        for rel_path in images:
            if rel_path.startswith('/images/discounts/'):
                abs_path = os.path.join(os.path.dirname(__file__), '../Website', rel_path.lstrip('/'))
                try:
                    if os.path.exists(abs_path):
                        os.remove(abs_path)
                except Exception as e:
                    pass  # Ignore errors
    try:
        resp = requests.delete(
            f"{DISCOUNTS_URL}/{idx}",
            json={'secret': API_SECRET}
        )
        if resp.status_code in [200, 204]:
            await get_effective_message(update).reply_text("Discount deleted successfully!")
        else:
            await get_effective_message(update).reply_text(f"Failed to delete discount: {resp.text}")
    except Exception as e:
        await get_effective_message(update).reply_text(f"Error deleting discount: {e}")
    from handlers import get_start_menu
    welcome_message, reply_markup = get_start_menu()
    await get_effective_message(update).reply_text(welcome_message, reply_markup=reply_markup)
    return ConversationHandler.END

# --- Toggle Discount Visibility ---
async def toggle_discount_visibility(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        resp = requests.get(DISCOUNTS_URL)
        if resp.status_code != 200:
            await get_effective_message(update).reply_text(f"Failed to fetch discounts: {resp.text}")
            from handlers import get_start_menu
            welcome_message, reply_markup = get_start_menu()
            await get_effective_message(update).reply_text(welcome_message, reply_markup=reply_markup)
            return ConversationHandler.END
        discounts = resp.json()
        if not discounts:
            await get_effective_message(update).reply_text("No discounts to toggle.")
            from handlers import get_start_menu
            welcome_message, reply_markup = get_start_menu()
            await get_effective_message(update).reply_text(welcome_message, reply_markup=reply_markup)
            return ConversationHandler.END
        context.user_data['discounts'] = discounts
        chunk_size = 10
        for i in range(0, len(discounts), chunk_size):
            chunk = discounts[i:i + chunk_size]
            msg = f"Which discount's visibility do you want to toggle? (Part {i//chunk_size + 1})\nReply with the number.\n"
            for j, discount in enumerate(chunk):
                status = "👁️ Hidden" if discount.get('visibility') == 'hidden' else "👁️ Visible"
                msg += f"\n{i+j+1}. {discount.get('title')} - {status}"
            await get_effective_message(update).reply_text(msg)
        return TOGGLE_DISCOUNT_CHOOSE
    except Exception as e:
        await get_effective_message(update).reply_text(f"Error fetching discounts: {e}")
        from handlers import get_start_menu
        welcome_message, reply_markup = get_start_menu()
        await get_effective_message(update).reply_text(welcome_message, reply_markup=reply_markup)
        return ConversationHandler.END

async def toggle_discount_choose(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    if not text.isdigit():
        await get_effective_message(update).reply_text("Please reply with a valid number.")
        return TOGGLE_DISCOUNT_CHOOSE
    idx = int(text) - 1
    discounts = context.user_data.get('discounts', [])
    if idx < 0 or idx >= len(discounts):
        await get_effective_message(update).reply_text("Number out of range. Try again.")
        return TOGGLE_DISCOUNT_CHOOSE
    current_visibility = discounts[idx].get('visibility', 'visible')
    await get_effective_message(update).reply_text("Processing visibility toggle...")
    try:
        resp = requests.post(
            f"{DISCOUNTS_URL}/{idx}/toggle-visibility",
            json={'secret': API_SECRET}
        )
        if resp.status_code == 200:
            new_status = "hidden" if current_visibility == 'visible' else "visible"
            await get_effective_message(update).reply_text(f"Discount is now {new_status}!")
        else:
            await get_effective_message(update).reply_text(f"Failed to toggle visibility: {resp.text}")
    except Exception as e:
        await get_effective_message(update).reply_text(f"Error toggling visibility: {e}")
    from handlers import get_start_menu
    welcome_message, reply_markup = get_start_menu()
    await get_effective_message(update).reply_text(welcome_message, reply_markup=reply_markup)
    return ConversationHandler.END

__all__ = [
    'discounts',
    'add_discount_start', 'add_discount_title', 'add_discount_desc', 'add_discount_occurrence',
    'add_discount_image_upload', 'add_discount_done_images',
    'list_discounts',
    'delete_discount_start', 'delete_discount_choose', 'delete_discount_confirm',
    'toggle_discount_visibility', 'toggle_discount_choose',
]

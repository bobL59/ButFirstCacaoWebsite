from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler
from telegram.constants import ParseMode
from desserts import desserts
from common import get_start_menu

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Send a message when the command /start is issued or when called from a callback query. Also ends any active conversation."""
    welcome_message, reply_markup = get_start_menu()
    if update.message:
        # Always use edit_message_text if possible to avoid duplicate menus
        try:
            await update.message.edit_text(welcome_message, reply_markup=reply_markup)
        except Exception:
            await update.message.reply_text(welcome_message, reply_markup=reply_markup)
    elif update.callback_query:
        await update.callback_query.edit_message_text(welcome_message, reply_markup=reply_markup)
    return ConversationHandler.END

async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Action cancelled.")
    return ConversationHandler.END 
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.constants import ParseMode
from telegram.ext import ContextTypes, ConversationHandler
from common import get_go_back_button, go_back_handler, get_env_vars
import requests
from handlers import start, get_start_menu
from constants import ADD_CATEGORY_NAME, EDIT_CATEGORY_CHOOSE, EDIT_CATEGORY_NAME, DELETE_CATEGORY_CHOOSE, DELETE_CATEGORY_CONFIRM, TOGGLE_CATEGORY_CHOOSE, TOGGLE_PRODUCT_CHOOSE, ADD_PRODUCT_NAME, ADD_PRODUCT_CATEGORY, ADD_PRODUCT_FLAVOUR_NAME, ADD_PRODUCT_FLAVOUR_DESC, ADD_PRODUCT_FLAVOUR_PRICE, ADD_PRODUCT_FLAVOUR_IMAGE, EDIT_PRODUCT_CHOOSE, EDIT_PRODUCT_FIELD, EDIT_PRODUCT_VALUE, LIST_FLAVOUR_CHOOSE_PRODUCT, ADD_FLAVOUR_CHOOSE_PRODUCT, ADD_FLAVOUR_NAME, ADD_FLAVOUR_DESC, ADD_FLAVOUR_PRICE, ADD_FLAVOUR_IMAGE, EDIT_FLAVOUR_CHOOSE_PRODUCT, EDIT_FLAVOUR_CHOOSE_FLAVOUR, EDIT_FLAVOUR_FIELD, EDIT_FLAVOUR_VALUE, DELETE_FLAVOUR_CHOOSE_PRODUCT, DELETE_FLAVOUR_CHOOSE_FLAVOUR, TOGGLE_FLAVOUR_CHOOSE_PRODUCT, TOGGLE_FLAVOUR_CHOOSE_FLAVOUR

# Helper to generate the others message
OTHERS_MESSAGE = (
    "📦 <b>Others</b>\n"
    "Select an action below:"
)

# Inline keyboard for others actions
OTHERS_KEYBOARD = [
    [InlineKeyboardButton("List categories", callback_data="listcategories")],
    [InlineKeyboardButton("Add category", callback_data="addcategory")],
    [InlineKeyboardButton("Edit category", callback_data="editcategory")],
    [InlineKeyboardButton("Delete category", callback_data="deletecategory")],
    [InlineKeyboardButton("Toggle category visibility", callback_data="hidecategory")],
    [InlineKeyboardButton("List products", callback_data="listproducts")],
    [InlineKeyboardButton("Add product", callback_data="addproduct")],
    [InlineKeyboardButton("Edit product", callback_data="editproduct")],
    [InlineKeyboardButton("Delete product", callback_data="deleteproduct")],
    [InlineKeyboardButton("Toggle product visibility", callback_data="hideproduct")],
    [InlineKeyboardButton("List flavours", callback_data="listflavours")],
    [InlineKeyboardButton("Add flavour", callback_data="addflavour")],
    [InlineKeyboardButton("Edit flavour", callback_data="editflavour")],
    [InlineKeyboardButton("Delete flavour", callback_data="deleteflavour")],
    [InlineKeyboardButton("Hide flavour", callback_data="hideflavour")],
    get_go_back_button(),
]
OTHERS_REPLY_MARKUP = InlineKeyboardMarkup(OTHERS_KEYBOARD)

# Get env vars for API usage
env = get_env_vars()
CATEGORIES_URL = env['CATEGORIES_URL']

async def others(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Handles both command and callback
    if update.message:
        await update.message.reply_text(
            OTHERS_MESSAGE,
            parse_mode=ParseMode.HTML,
            reply_markup=OTHERS_REPLY_MARKUP
        )
    elif update.callback_query:
        query = update.callback_query
        await query.answer()
        if query.data == "go_back":
            await go_back_handler(update, context)
            return
        # Handle all others actions
        if query.data == "listcategories":
            await listcategories(update, context, query=query)
            return
        if query.data == "addcategory":
            await addcategory_start(update, context)
            return
        if query.data == "editcategory":
            await editcategory_start(update, context)
            return
        if query.data == "deletecategory":
            await deletecategory_start(update, context)
            return
        if query.data == "hidecategory":
            await hidecategory_start(update, context)
            return
        if query.data == "listproducts":
            await listproducts(update, context, query=query)
            return
        if query.data == "addproduct":
            await addproduct_start(update, context)
            return
        if query.data == "editproduct":
            await editproduct_start(update, context)
            return
        if query.data == "deleteproduct":
            await deleteproduct_start(update, context)
            return
        if query.data == "hideproduct":
            await hideproduct_start(update, context)
            return
        action_map = {
            "addcategory": "adding a category",
            "editcategory": "editing a category",
            "deletecategory": "deleting a category",
            "hidecategory": "hiding a category",
            "listproducts": "listing the products",
            "addproduct": "adding a product",
            "editproduct": "editing a product",
            "deleteproduct": "deleting a product",
            "hideproduct": "hiding a product",
            "listflavours": "listing the flavours",
            "addflavour": "adding a flavour",
            "editflavour": "editing a flavour",
            "deleteflavour": "deleting a flavour",
            "hideflavour": "hiding a flavour",
        }
        if query.data in action_map:
            await query.edit_message_text(
                f"You pressed {action_map[query.data]}",
                parse_mode=ParseMode.HTML
            )
            # Show the main menu again
            await query.message.reply_text(
                OTHERS_MESSAGE,
                parse_mode=ParseMode.HTML,
                reply_markup=OTHERS_REPLY_MARKUP
            )
        else:
            await query.edit_message_text(
                OTHERS_MESSAGE,
                parse_mode=ParseMode.HTML,
                reply_markup=OTHERS_REPLY_MARKUP
            )

async def listcategories(update: Update, context: ContextTypes.DEFAULT_TYPE, query=None):
    if query is None:
        # Called from a command
        try:
            resp = requests.get(CATEGORIES_URL)
            if resp.status_code == 200:
                categories = resp.json()
            else:
                if update.effective_message:
                    await update.effective_message.reply_text(f"Failed to fetch categories: {resp.text}")
                return
        except Exception as e:
            if update.effective_message:
                await update.effective_message.reply_text(f"Error fetching categories: {e}")
            return
        if not categories:
            msg = "No categories found."
        else:
            msg = "<b>Categories:</b>\n\n"
            for cat in categories:
                status = "👁️ Visible" if cat.get('visible', True) else "🙈 Hidden"
                msg += f"<b>{cat['name']}</b> ({cat['id']}) - {status}\n"
        if update.effective_message:
            await update.effective_message.reply_text(msg, parse_mode=ParseMode.HTML)
            welcome_message, reply_markup = get_start_menu()
            await update.effective_message.reply_text(welcome_message, reply_markup=reply_markup)
    else:
        # Called from a callback query
        try:
            resp = requests.get(CATEGORIES_URL)
            if resp.status_code == 200:
                categories = resp.json()
            else:
                await query.edit_message_text(f"Failed to fetch categories: {resp.text}")
                return
        except Exception as e:
            await query.edit_message_text(f"Error fetching categories: {e}")
            return
        if not categories:
            msg = "No categories found."
        else:
            msg = "<b>Categories:</b>\n\n"
            for cat in categories:
                status = "👁️ Visible" if cat.get('visible', True) else "🙈 Hidden"
                msg += f"<b>{cat['name']}</b> ({cat['id']}) - {status}\n"
        await query.edit_message_text(msg, parse_mode=ParseMode.HTML)
        welcome_message, reply_markup = get_start_menu()
        await context.bot.send_message(
            chat_id=query.message.chat_id,
            text=welcome_message,
            reply_markup=reply_markup
        )

async def addcategory_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Handles both command and callback
    if update.message:
        await update.message.reply_text("Please enter the name of the new category:")
    elif update.callback_query:
        await update.callback_query.answer()
        await update.callback_query.message.reply_text("Please enter the name of the new category:")
    return ADD_CATEGORY_NAME

async def addcategory_name(update: Update, context: ContextTypes.DEFAULT_TYPE):
    name = update.message.text.strip()
    env = get_env_vars()
    CATEGORIES_URL = env['CATEGORIES_URL']
    API_SECRET = env['API_SECRET']
    try:
        resp = requests.post(CATEGORIES_URL, json={"name": name, "secret": API_SECRET})
        if resp.status_code == 200:
            await update.message.reply_text(f"Category '{name}' added successfully!")
        else:
            await update.message.reply_text(f"Failed to add category: {resp.text}")
    except Exception as e:
        await update.message.reply_text(f"Error adding category: {e}")
    # Show main menu
    from handlers import start
    welcome_message, reply_markup = get_start_menu()
    await update.effective_message.reply_text(welcome_message, reply_markup=reply_markup)
    return ConversationHandler.END

async def editcategory_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    env = get_env_vars()
    CATEGORIES_URL = env['CATEGORIES_URL']
    try:
        resp = requests.get(CATEGORIES_URL)
        if resp.status_code == 200:
            categories = resp.json()
        else:
            await update.effective_message.reply_text(f"Failed to fetch categories: {resp.text}")
            from handlers import start
            await start(update, context)
            return ConversationHandler.END
    except Exception as e:
        await update.effective_message.reply_text(f"Error fetching categories: {e}")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    if not categories:
        await update.effective_message.reply_text("No categories to edit.")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    context.user_data['categories'] = categories
    msg = "Which category do you want to edit? Reply with the number.\n"
    for i, cat in enumerate(categories):
        msg += f"\n{i+1}. {cat['name']} ({cat['id']})"
    await update.effective_message.reply_text(msg)
    return EDIT_CATEGORY_CHOOSE

async def editcategory_choose(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    if not text.isdigit():
        await update.message.reply_text("Please reply with a valid number.")
        return EDIT_CATEGORY_CHOOSE
    idx = int(text) - 1
    categories = context.user_data.get('categories', [])
    if idx < 0 or idx >= len(categories):
        await update.message.reply_text("Number out of range. Try again.")
        return EDIT_CATEGORY_CHOOSE
    context.user_data['edit_category'] = categories[idx]
    await update.message.reply_text("Please enter the new name for the category:")
    return EDIT_CATEGORY_NAME

async def editcategory_name(update: Update, context: ContextTypes.DEFAULT_TYPE):
    new_name = update.message.text.strip()
    category = context.user_data.get('edit_category')
    env = get_env_vars()
    CATEGORIES_URL = env['CATEGORIES_URL']
    API_SECRET = env['API_SECRET']
    try:
        resp = requests.put(f"{CATEGORIES_URL}/{category['id']}", json={"name": new_name, "secret": API_SECRET})
        if resp.status_code == 200:
            await update.message.reply_text(f"Category renamed to '{new_name}' successfully!")
        else:
            await update.message.reply_text(f"Failed to rename category: {resp.text}")
    except Exception as e:
        await update.message.reply_text(f"Error renaming category: {e}")
    from handlers import start
    welcome_message, reply_markup = get_start_menu()
    await update.effective_message.reply_text(welcome_message, reply_markup=reply_markup)
    return ConversationHandler.END

async def deletecategory_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    env = get_env_vars()
    CATEGORIES_URL = env['CATEGORIES_URL']
    try:
        resp = requests.get(CATEGORIES_URL)
        if resp.status_code == 200:
            categories = resp.json()
        else:
            await update.effective_message.reply_text(f"Failed to fetch categories: {resp.text}")
            from handlers import start
            await start(update, context)
            return ConversationHandler.END
    except Exception as e:
        await update.effective_message.reply_text(f"Error fetching categories: {e}")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    if not categories:
        await update.effective_message.reply_text("No categories to delete.")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    context.user_data['categories'] = categories
    msg = "Which category do you want to delete? Reply with the number.\n"
    for i, cat in enumerate(categories):
        msg += f"\n{i+1}. {cat['name']} ({cat['id']})"
    await update.effective_message.reply_text(msg)
    return DELETE_CATEGORY_CHOOSE

async def deletecategory_choose(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    if not text.isdigit():
        await update.message.reply_text("Please reply with a valid number.")
        return DELETE_CATEGORY_CHOOSE
    idx = int(text) - 1
    categories = context.user_data.get('categories', [])
    if idx < 0 or idx >= len(categories):
        await update.message.reply_text("Number out of range. Try again.")
        return DELETE_CATEGORY_CHOOSE
    context.user_data['delete_category'] = categories[idx]
    name = categories[idx]['name']
    await update.message.reply_text(f"Are you sure you want to delete '{name}'? Reply YES to confirm, or /cancel.")
    return DELETE_CATEGORY_CONFIRM

async def deletecategory_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message.text.strip().upper() != 'YES':
        await update.message.reply_text("Deletion cancelled.")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    category = context.user_data.get('delete_category')
    env = get_env_vars()
    CATEGORIES_URL = env['CATEGORIES_URL']
    API_SECRET = env['API_SECRET']
    try:
        resp = requests.delete(f"{CATEGORIES_URL}/{category['id']}", json={"secret": API_SECRET})
        if resp.status_code == 200:
            await update.message.reply_text(f"Category '{category['name']}' deleted successfully!")
        else:
            await update.message.reply_text(f"Failed to delete category: {resp.text}")
    except Exception as e:
        await update.message.reply_text(f"Error deleting category: {e}")
    from handlers import start
    welcome_message, reply_markup = get_start_menu()
    await update.effective_message.reply_text(welcome_message, reply_markup=reply_markup)
    return ConversationHandler.END

async def hidecategory_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    env = get_env_vars()
    CATEGORIES_URL = env['CATEGORIES_URL']
    try:
        resp = requests.get(CATEGORIES_URL)
        if resp.status_code == 200:
            categories = resp.json()
        else:
            await update.effective_message.reply_text(f"Failed to fetch categories: {resp.text}")
            from handlers import start
            await start(update, context)
            return ConversationHandler.END
    except Exception as e:
        await update.effective_message.reply_text(f"Error fetching categories: {e}")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    if not categories:
        await update.effective_message.reply_text("No categories to hide.")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    context.user_data['categories'] = categories
    msg = "Which category do you want to toggle visibility? Reply with the number.\n"
    for i, cat in enumerate(categories):
        status = "👁️ Visible" if cat.get('visible', True) else "🙈 Hidden"
        msg += f"\n{i+1}. {cat['name']} ({cat['id']}) - {status}"
    await update.effective_message.reply_text(msg)
    return TOGGLE_CATEGORY_CHOOSE

async def hidecategory_choose(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    if not text.isdigit():
        await update.message.reply_text("Please reply with a valid number.")
        return TOGGLE_CATEGORY_CHOOSE
    idx = int(text) - 1
    categories = context.user_data.get('categories', [])
    if idx < 0 or idx >= len(categories):
        await update.message.reply_text("Number out of range. Try again.")
        return TOGGLE_CATEGORY_CHOOSE
    category = categories[idx]
    env = get_env_vars()
    CATEGORIES_URL = env['CATEGORIES_URL']
    API_SECRET = env['API_SECRET']
    try:
        resp = requests.post(f"{CATEGORIES_URL}/{category['id']}/hide", json={"secret": API_SECRET})
        if resp.status_code == 200:
            data = resp.json()
            new_status = "👁️ Visible" if data.get('visible', True) else "🙈 Hidden"
            await update.message.reply_text(f"Category '{category['name']}' is now {new_status}!")
        else:
            await update.message.reply_text(f"Failed to toggle visibility: {resp.text}")
    except Exception as e:
        await update.message.reply_text(f"Error toggling visibility: {e}")
    from handlers import start
    welcome_message, reply_markup = get_start_menu()
    await update.effective_message.reply_text(welcome_message, reply_markup=reply_markup)
    return ConversationHandler.END

async def listproducts(update: Update, context: ContextTypes.DEFAULT_TYPE, query=None):
    env = get_env_vars()
    PRODUCTS_URL = env['API_BASE_URL'].rstrip('/') + '/api/products'
    try:
        resp = requests.get(PRODUCTS_URL)
        if resp.status_code == 200:
            products = resp.json()
        else:
            msg = f"Failed to fetch products: {resp.text}"
            if query:
                await query.edit_message_text(msg)
            elif update.effective_message:
                await update.effective_message.reply_text(msg)
            return
    except Exception as e:
        msg = f"Error fetching products: {e}"
        if query:
            await query.edit_message_text(msg)
        elif update.effective_message:
            await update.effective_message.reply_text(msg)
        return
    if not products:
        msg = "No products found."
    else:
        msg = "<b>Products:</b>\n\n"
        for prod in products:
            status = "👁️ Visible" if prod.get('visible', True) else "🙈 Hidden"
            msg += f"<b>{prod['name']}</b> ({prod['id']}) - {status} | Category: {prod.get('categoryId','?')}\n"
    if query:
        await query.edit_message_text(msg, parse_mode=ParseMode.HTML)
        welcome_message, reply_markup = get_start_menu()
        await context.bot.send_message(
            chat_id=query.message.chat_id,
            text=welcome_message,
            reply_markup=reply_markup
        )
    elif update.effective_message:
        await update.effective_message.reply_text(msg, parse_mode=ParseMode.HTML)
        welcome_message, reply_markup = get_start_menu()
        await update.effective_message.reply_text(welcome_message, reply_markup=reply_markup)

async def hideproduct_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    env = get_env_vars()
    PRODUCTS_URL = env['API_BASE_URL'].rstrip('/') + '/api/products'
    try:
        resp = requests.get(PRODUCTS_URL)
        if resp.status_code == 200:
            products = resp.json()
        else:
            await update.effective_message.reply_text(f"Failed to fetch products: {resp.text}")
            from handlers import start
            await start(update, context)
            return ConversationHandler.END
    except Exception as e:
        await update.effective_message.reply_text(f"Error fetching products: {e}")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    if not products:
        await update.effective_message.reply_text("No products to toggle.")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    context.user_data['products'] = products
    msg = "Which product do you want to toggle visibility? Reply with the number.\n"
    for i, prod in enumerate(products):
        status = "👁️ Visible" if prod.get('visible', True) else "🙈 Hidden"
        msg += f"\n{i+1}. {prod['name']} ({prod['id']}) - {status}"
    await update.effective_message.reply_text(msg)
    return TOGGLE_PRODUCT_CHOOSE

async def hideproduct_choose(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    if not text.isdigit():
        await update.message.reply_text("Please reply with a valid number.")
        return TOGGLE_PRODUCT_CHOOSE
    idx = int(text) - 1
    products = context.user_data.get('products', [])
    if idx < 0 or idx >= len(products):
        await update.message.reply_text("Number out of range. Try again.")
        return TOGGLE_PRODUCT_CHOOSE
    product = products[idx]
    env = get_env_vars()
    PRODUCTS_URL = env['API_BASE_URL'].rstrip('/') + '/api/products'
    API_SECRET = env['API_SECRET']
    try:
        resp = requests.post(f"{PRODUCTS_URL}/{product['id']}/hide", json={"secret": API_SECRET})
        if resp.status_code == 200:
            data = resp.json()
            new_status = "👁️ Visible" if data.get('visible', True) else "🙈 Hidden"
            await update.message.reply_text(f"Product '{product['name']}' is now {new_status}!")
        else:
            await update.message.reply_text(f"Failed to toggle visibility: {resp.text}")
    except Exception as e:
        await update.message.reply_text(f"Error toggling visibility: {e}")
    from handlers import start
    welcome_message, reply_markup = get_start_menu()
    await update.effective_message.reply_text(welcome_message, reply_markup=reply_markup)
    return ConversationHandler.END

async def addproduct_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.callback_query:
        await update.callback_query.answer()
        await update.callback_query.message.reply_text("Please enter the name of the new product:")
    elif update.message:
        await update.message.reply_text("Please enter the name of the new product:")
    return ADD_PRODUCT_NAME

async def addproduct_name(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['product_name'] = update.message.text.strip()
    # Fetch categories
    env = get_env_vars()
    CATEGORIES_URL = env['API_BASE_URL'].rstrip('/') + '/api/categories'
    try:
        resp = requests.get(CATEGORIES_URL)
        if resp.status_code == 200:
            categories = resp.json()
        else:
            await update.message.reply_text(f"Failed to fetch categories: {resp.text}")
            from handlers import start
            await start(update, context)
            return ConversationHandler.END
    except Exception as e:
        await update.message.reply_text(f"Error fetching categories: {e}")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    if not categories:
        await update.message.reply_text("No categories available. Please add a category first.")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    context.user_data['categories'] = categories
    msg = "Which category does this product belong to? Reply with the number.\n"
    for i, cat in enumerate(categories):
        msg += f"\n{i+1}. {cat['name']} ({cat['id']})"
    await update.message.reply_text(msg)
    return ADD_PRODUCT_CATEGORY

async def addproduct_category(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    categories = context.user_data.get('categories', [])
    if not text.isdigit() or int(text) < 1 or int(text) > len(categories):
        await update.message.reply_text("Please reply with a valid number.")
        return ADD_PRODUCT_CATEGORY
    idx = int(text) - 1
    context.user_data['product_category_id'] = categories[idx]['id']
    await update.message.reply_text("Please enter the main flavour name:")
    return ADD_PRODUCT_FLAVOUR_NAME

async def addproduct_flavour_name(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['flavour_name'] = update.message.text.strip()
    await update.message.reply_text("Please enter the main flavour description:")
    return ADD_PRODUCT_FLAVOUR_DESC

async def addproduct_flavour_desc(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['flavour_desc'] = update.message.text.strip()
    await update.message.reply_text("Please enter the main flavour price:")
    return ADD_PRODUCT_FLAVOUR_PRICE

async def addproduct_flavour_price(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    try:
        price = float(text)
    except ValueError:
        await update.message.reply_text("Invalid price. Please enter a valid number:")
        return ADD_PRODUCT_FLAVOUR_PRICE
    context.user_data['flavour_price'] = price
    await update.message.reply_text("Please send the main flavour image (photo or image URL):")
    return ADD_PRODUCT_FLAVOUR_IMAGE

async def addproduct_flavour_image(update: Update, context: ContextTypes.DEFAULT_TYPE):
    image_url = None
    if update.message.photo:
        photo = update.message.photo[-1]
        file = await update.message.get_bot().get_file(photo.file_id)
        file_path = file.file_path
        if file_path.startswith('http'):
            image_url = file_path
        else:
            bot_token = context.bot.token
            image_url = f"https://api.telegram.org/file/bot{bot_token}/{file_path}"
    elif update.message.text and update.message.text.startswith('http'):
        image_url = update.message.text.strip()
    else:
        await update.message.reply_text("Please send a photo or a valid image URL.")
        return ADD_PRODUCT_FLAVOUR_IMAGE
    # Call backend to add product
    env = get_env_vars()
    PRODUCTS_URL = env['API_BASE_URL'].rstrip('/') + '/api/products'
    API_SECRET = env['API_SECRET']
    data = {
        'name': context.user_data['product_name'],
        'categoryId': context.user_data['product_category_id'],
        'flavour': {
            'name': context.user_data['flavour_name'],
            'description': context.user_data['flavour_desc'],
            'price': context.user_data['flavour_price'],
            'image_url': image_url
        },
        'secret': API_SECRET
    }
    try:
        resp = requests.post(PRODUCTS_URL, json=data)
        if resp.status_code == 200:
            await update.message.reply_text("Product added successfully!")
        else:
            await update.message.reply_text(f"Failed to add product: {resp.text}")
    except Exception as e:
        await update.message.reply_text(f"Error adding product: {e}")
    from handlers import start
    welcome_message, reply_markup = get_start_menu()
    await update.effective_message.reply_text(welcome_message, reply_markup=reply_markup)
    return ConversationHandler.END

async def editproduct_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    env = get_env_vars()
    PRODUCTS_URL = env['API_BASE_URL'].rstrip('/') + '/api/products'
    try:
        resp = requests.get(PRODUCTS_URL)
        if resp.status_code == 200:
            products = resp.json()
        else:
            await update.effective_message.reply_text(f"Failed to fetch products: {resp.text}")
            from handlers import start
            await start(update, context)
            return ConversationHandler.END
    except Exception as e:
        await update.effective_message.reply_text(f"Error fetching products: {e}")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    if not products:
        await update.effective_message.reply_text("No products to edit.")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    context.user_data['products'] = products
    msg = "Which product do you want to edit? Reply with the number.\n"
    for i, prod in enumerate(products):
        msg += f"\n{i+1}. {prod['name']} ({prod['id']})"
    await update.effective_message.reply_text(msg)
    return EDIT_PRODUCT_CHOOSE

async def editproduct_choose(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    if not text.isdigit():
        await update.message.reply_text("Please reply with a valid number.")
        return EDIT_PRODUCT_CHOOSE
    idx = int(text) - 1
    products = context.user_data.get('products', [])
    if idx < 0 or idx >= len(products):
        await update.message.reply_text("Number out of range. Try again.")
        return EDIT_PRODUCT_CHOOSE
    context.user_data['edit_product'] = products[idx]
    # Inline keyboard for field selection
    keyboard = [
        [InlineKeyboardButton("Edit name", callback_data="editfield_name")],
        [InlineKeyboardButton("Edit category", callback_data="editfield_category")],
        get_go_back_button()
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(
        "What would you like to edit?",
        reply_markup=reply_markup
    )
    return EDIT_PRODUCT_FIELD

async def editproduct_field(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Now expects a callback query
    if update.callback_query:
        data = update.callback_query.data
        if data == "go_back":
            await go_back_handler(update, context)
            return ConversationHandler.END
        if data.startswith("editfield_"):
            field = data.replace("editfield_", "")
        else:
            await update.callback_query.answer()
            await update.callback_query.message.reply_text("Invalid field selection.")
            return EDIT_PRODUCT_FIELD
        await update.callback_query.answer()
        context.user_data['edit_field'] = field
        if field == 'category':
            # Fetch categories for selection
            env = get_env_vars()
            CATEGORIES_URL = env['API_BASE_URL'].rstrip('/') + '/api/categories'
            try:
                resp = requests.get(CATEGORIES_URL)
                if resp.status_code == 200:
                    categories = resp.json()
                else:
                    await update.callback_query.message.reply_text(f"Failed to fetch categories: {resp.text}")
                    from handlers import start
                    await start(update, context)
                    return ConversationHandler.END
            except Exception as e:
                await update.callback_query.message.reply_text(f"Error fetching categories: {e}")
                from handlers import start
                await start(update, context)
                return ConversationHandler.END
            if not categories:
                await update.callback_query.message.reply_text("No categories available.")
                from handlers import start
                await start(update, context)
                return ConversationHandler.END
            context.user_data['categories'] = categories
            msg = "Which category should this product belong to? Reply with the number.\n"
            for i, cat in enumerate(categories):
                msg += f"\n{i+1}. {cat['name']} ({cat['id']})"
            await update.callback_query.message.reply_text(msg)
            return EDIT_PRODUCT_VALUE
        else:
            await update.callback_query.message.reply_text(f"Please enter the new {field}:")
            return EDIT_PRODUCT_VALUE
    else:
        await update.message.reply_text("Please use the buttons to select a field.")
        return EDIT_PRODUCT_FIELD

async def editproduct_value(update: Update, context: ContextTypes.DEFAULT_TYPE):
    field = context.user_data.get('edit_field')
    product = context.user_data.get('edit_product')
    env = get_env_vars()
    PRODUCTS_URL = env['API_BASE_URL'].rstrip('/') + '/api/products'
    API_SECRET = env['API_SECRET']
    payload = {'secret': API_SECRET}
    if field == 'name':
        payload['name'] = update.message.text.strip()
    elif field == 'category':
        text = update.message.text.strip()
        categories = context.user_data.get('categories', [])
        if not text.isdigit() or int(text) < 1 or int(text) > len(categories):
            await update.message.reply_text("Please reply with a valid number.")
            return EDIT_PRODUCT_VALUE
        idx = int(text) - 1
        payload['categoryId'] = categories[idx]['id']
    try:
        resp = requests.put(f"{PRODUCTS_URL}/{product['id']}", json=payload)
        if resp.status_code == 200:
            await update.message.reply_text("Product updated successfully!")
        else:
            await update.message.reply_text(f"Failed to update product: {resp.text}")
    except Exception as e:
        await update.message.reply_text(f"Error updating product: {e}")
    from handlers import start
    welcome_message, reply_markup = get_start_menu()
    await update.effective_message.reply_text(welcome_message, reply_markup=reply_markup)
    return ConversationHandler.END

async def deleteproduct_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.callback_query:
        await update.callback_query.answer()
        await update.callback_query.message.reply_text("Delete product feature is coming soon!")
    elif update.message:
        await update.message.reply_text("Delete product feature is coming soon!")
    from handlers import start
    welcome_message, reply_markup = get_start_menu()
    await update.effective_message.reply_text(welcome_message, reply_markup=reply_markup)
    return ConversationHandler.END

# --- FLAVOUR MANAGEMENT HANDLERS ---

async def listflavours(update: Update, context: ContextTypes.DEFAULT_TYPE):
    env = get_env_vars()
    PRODUCTS_URL = env['API_BASE_URL'].rstrip('/') + '/api/products'
    try:
        resp = requests.get(PRODUCTS_URL)
        if resp.status_code == 200:
            products = resp.json()
        else:
            await update.effective_message.reply_text(f"Failed to fetch products: {resp.text}")
            return
    except Exception as e:
        await update.effective_message.reply_text(f"Error fetching products: {e}")
        return
    if not products:
        await update.effective_message.reply_text("No products found.")
        return
    msg = "<b>Flavours by Product:</b>\n\n"
    for prod in products:
        msg += f"<b>{prod['name']}</b> ({prod['id']}):\n"
        if not prod.get('flavors'):
            msg += "  - No flavours\n"
        else:
            for flav in prod['flavors']:
                status = "👁️ Visible" if flav.get('visible', True) else "🙈 Hidden"
                avail = "✅ Available" if flav.get('available', True) else "⏳ Not Available"
                msg += f"  - <b>{flav['name']}</b> ({flav['id']}) - {status}, {avail}, {flav['price']}₾\n"
    await update.effective_message.reply_text(msg, parse_mode=ParseMode.HTML)
    from handlers import start
    welcome_message, reply_markup = get_start_menu()
    await update.effective_message.reply_text(welcome_message, reply_markup=reply_markup)

async def addflavour_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    env = get_env_vars()
    PRODUCTS_URL = env['API_BASE_URL'].rstrip('/') + '/api/products'
    try:
        resp = requests.get(PRODUCTS_URL)
        if resp.status_code == 200:
            products = resp.json()
        else:
            await update.effective_message.reply_text(f"Failed to fetch products: {resp.text}")
            from handlers import start
            await start(update, context)
            return ConversationHandler.END
    except Exception as e:
        await update.effective_message.reply_text(f"Error fetching products: {e}")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    if not products:
        await update.effective_message.reply_text("No products available.")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    context.user_data['products'] = products
    msg = "Which product do you want to add a flavour to? Reply with the number.\n"
    for i, prod in enumerate(products):
        msg += f"\n{i+1}. {prod['name']} ({prod['id']})"
    await update.effective_message.reply_text(msg)
    return ADD_FLAVOUR_CHOOSE_PRODUCT

async def addflavour_choose_product(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    products = context.user_data.get('products', [])
    if not text.isdigit() or int(text) < 1 or int(text) > len(products):
        await update.message.reply_text("Please reply with a valid number.")
        return ADD_FLAVOUR_CHOOSE_PRODUCT
    idx = int(text) - 1
    context.user_data['add_flavour_product_id'] = products[idx]['id']
    await update.message.reply_text("Enter the new flavour name:")
    return ADD_FLAVOUR_NAME

async def addflavour_name(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['add_flavour_name'] = update.message.text.strip()
    await update.message.reply_text("Enter the flavour description:")
    return ADD_FLAVOUR_DESC

async def addflavour_desc(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['add_flavour_desc'] = update.message.text.strip()
    await update.message.reply_text("Enter the flavour price:")
    return ADD_FLAVOUR_PRICE

async def addflavour_price(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    try:
        price = float(text)
    except ValueError:
        await update.message.reply_text("Invalid price. Please enter a valid number:")
        return ADD_FLAVOUR_PRICE
    context.user_data['add_flavour_price'] = price
    await update.message.reply_text("Please send the flavour image (photo or image URL):")
    return ADD_FLAVOUR_IMAGE

async def addflavour_image(update: Update, context: ContextTypes.DEFAULT_TYPE):
    image_url = None
    if update.message.photo:
        photo = update.message.photo[-1]
        file = await update.message.get_bot().get_file(photo.file_id)
        file_path = file.file_path
        if file_path.startswith('http'):
            image_url = file_path
        else:
            bot_token = context.bot.token
            image_url = f"https://api.telegram.org/file/bot{bot_token}/{file_path}"
    elif update.message.text and update.message.text.startswith('http'):
        image_url = update.message.text.strip()
    else:
        await update.message.reply_text("Please send a photo or a valid image URL.")
        return ADD_FLAVOUR_IMAGE
    # Call backend to add flavour
    env = get_env_vars()
    PRODUCTS_URL = env['API_BASE_URL'].rstrip('/') + '/api/products'
    API_SECRET = env['API_SECRET']
    product_id = context.user_data['add_flavour_product_id']
    data = {
        'name': context.user_data['add_flavour_name'],
        'description': context.user_data['add_flavour_desc'],
        'price': context.user_data['add_flavour_price'],
        'image_url': image_url,
        'secret': API_SECRET
    }
    try:
        resp = requests.post(f"{PRODUCTS_URL}/{product_id}/flavours", json=data)
        if resp.status_code == 200:
            await update.message.reply_text("Flavour added successfully!")
        else:
            await update.message.reply_text(f"Failed to add flavour: {resp.text}")
    except Exception as e:
        await update.message.reply_text(f"Error adding flavour: {e}")
    from handlers import start
    welcome_message, reply_markup = get_start_menu()
    await update.effective_message.reply_text(welcome_message, reply_markup=reply_markup)
    return ConversationHandler.END

async def editflavour_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    env = get_env_vars()
    PRODUCTS_URL = env['API_BASE_URL'].rstrip('/') + '/api/products'
    try:
        resp = requests.get(PRODUCTS_URL)
        if resp.status_code == 200:
            products = resp.json()
        else:
            await update.effective_message.reply_text(f"Failed to fetch products: {resp.text}")
            welcome_message, reply_markup = get_start_menu()
            await update.effective_message.reply_text(welcome_message, reply_markup=reply_markup)
            return ConversationHandler.END
    except Exception as e:
        await update.effective_message.reply_text(f"Error fetching products: {e}")
        welcome_message, reply_markup = get_start_menu()
        await update.effective_message.reply_text(welcome_message, reply_markup=reply_markup)
        return ConversationHandler.END
    if not products:
        await update.effective_message.reply_text("No products available.")
        welcome_message, reply_markup = get_start_menu()
        await update.effective_message.reply_text(welcome_message, reply_markup=reply_markup)
        return ConversationHandler.END
    context.user_data['products'] = products
    msg = "Which product's flavour do you want to edit? Reply with the number.\n"
    for i, prod in enumerate(products):
        msg += f"\n{i+1}. {prod['name']} ({prod['id']})"
    await update.effective_message.reply_text(msg)
    return EDIT_FLAVOUR_CHOOSE_PRODUCT

async def editflavour_choose_product(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    products = context.user_data.get('products', [])
    if not text.isdigit() or int(text) < 1 or int(text) > len(products):
        await update.message.reply_text("Please reply with a valid number.")
        return EDIT_FLAVOUR_CHOOSE_PRODUCT
    idx = int(text) - 1
    product = products[idx]
    context.user_data['edit_flavour_product'] = product
    flavours = product.get('flavors', [])
    if not flavours:
        await update.message.reply_text("This product has no flavours to edit.")
        welcome_message, reply_markup = get_start_menu()
        await update.effective_message.reply_text(welcome_message, reply_markup=reply_markup)
        return ConversationHandler.END
    context.user_data['flavours'] = flavours
    msg = "Which flavour do you want to edit? Reply with the number.\n"
    for i, flav in enumerate(flavours):
        msg += f"\n{i+1}. {flav['name']} ({flav['id']})"
    await update.message.reply_text(msg)
    return EDIT_FLAVOUR_CHOOSE_FLAVOUR

async def editflavour_choose_flavour(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    flavours = context.user_data.get('flavours', [])
    if not text.isdigit() or int(text) < 1 or int(text) > len(flavours):
        await update.message.reply_text("Please reply with a valid number.")
        return EDIT_FLAVOUR_CHOOSE_FLAVOUR
    idx = int(text) - 1
    flavour = flavours[idx]
    context.user_data['edit_flavour'] = flavour
    # Inline keyboard for field selection
    keyboard = [
        [InlineKeyboardButton("Edit name", callback_data="editflavourfield_name")],
        [InlineKeyboardButton("Edit description", callback_data="editflavourfield_description")],
        [InlineKeyboardButton("Edit price", callback_data="editflavourfield_price")],
        [InlineKeyboardButton("Edit image", callback_data="editflavourfield_image")],
        *[ [btn] for btn in get_go_back_button() ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(
        "What would you like to edit?",
        reply_markup=reply_markup
    )
    return EDIT_FLAVOUR_FIELD

async def editflavour_field(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.callback_query:
        data = update.callback_query.data
        if data == "go_back":
            await go_back_handler(update, context)
            return ConversationHandler.END
        if data.startswith("editflavourfield_"):
            field = data.replace("editflavourfield_", "")
        else:
            await update.callback_query.answer()
            await update.callback_query.message.reply_text("Invalid field selection.")
            return EDIT_FLAVOUR_FIELD
        await update.callback_query.answer()
        context.user_data['edit_flavour_field'] = field
        if field == 'available':
            # Toggle available
            await update.callback_query.message.reply_text("Type YES to toggle availability (currently: {}):".format(
                'Available' if context.user_data['edit_flavour'].get('available', True) else 'Not Available'))
            return EDIT_FLAVOUR_VALUE
        elif field == 'visible':
            # Toggle visible
            await update.callback_query.message.reply_text("Type YES to toggle visibility (currently: {}):".format(
                'Visible' if context.user_data['edit_flavour'].get('visible', True) else 'Hidden'))
            return EDIT_FLAVOUR_VALUE
        elif field == 'image':
            await update.callback_query.message.reply_text("Please send the new image (photo or image URL):")
            return EDIT_FLAVOUR_VALUE
        else:
            await update.callback_query.message.reply_text(f"Please enter the new {field}:")
            return EDIT_FLAVOUR_VALUE
    else:
        await update.message.reply_text("Please use the buttons to select a field.")
        return EDIT_FLAVOUR_FIELD

async def editflavour_value(update: Update, context: ContextTypes.DEFAULT_TYPE):
    field = context.user_data.get('edit_flavour_field')
    product = context.user_data.get('edit_flavour_product')
    flavour = context.user_data.get('edit_flavour')
    env = get_env_vars()
    PRODUCTS_URL = env['API_BASE_URL'].rstrip('/') + '/api/products'
    API_SECRET = env['API_SECRET']
    payload = {'secret': API_SECRET}
    if field == 'name':
        payload['name'] = update.message.text.strip()
    elif field == 'description':
        payload['description'] = update.message.text.strip()
    elif field == 'price':
        text = update.message.text.strip()
        try:
            payload['price'] = float(text)
        except ValueError:
            await update.message.reply_text("Invalid price. Please enter a valid number:")
            return EDIT_FLAVOUR_VALUE
    elif field == 'available':
        if update.message.text.strip().upper() == 'YES':
            payload['available'] = not flavour.get('available', True)
        else:
            await update.message.reply_text("Type YES to toggle availability or /cancel.")
            return EDIT_FLAVOUR_VALUE
    elif field == 'visible':
        if update.message.text.strip().upper() == 'YES':
            payload['visible'] = not flavour.get('visible', True)
        else:
            await update.message.reply_text("Type YES to toggle visibility or /cancel.")
            return EDIT_FLAVOUR_VALUE
    elif field == 'image':
        image_url = None
        if update.message.photo:
            photo = update.message.photo[-1]
            file = await update.message.get_bot().get_file(photo.file_id)
            file_path = file.file_path
            if file_path.startswith('http'):
                image_url = file_path
            else:
                bot_token = context.bot.token
                image_url = f"https://api.telegram.org/file/bot{bot_token}/{file_path}"
        elif update.message.text and update.message.text.startswith('http'):
            image_url = update.message.text.strip()
        else:
            await update.message.reply_text("Please send a photo or a valid image URL.")
            return EDIT_FLAVOUR_VALUE
        payload['image_url'] = image_url
    try:
        resp = requests.put(f"{PRODUCTS_URL}/{product['id']}/flavours/{flavour['id']}", json=payload)
        if resp.status_code == 200:
            await update.message.reply_text("Flavour updated successfully!")
        else:
            await update.message.reply_text(f"Failed to update flavour: {resp.text}")
    except Exception as e:
        await update.message.reply_text(f"Error updating flavour: {e}")
    welcome_message, reply_markup = get_start_menu()
    await update.effective_message.reply_text(welcome_message, reply_markup=reply_markup)
    return ConversationHandler.END

async def deleteflavour_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    env = get_env_vars()
    PRODUCTS_URL = env['API_BASE_URL'].rstrip('/') + '/api/products'
    try:
        resp = requests.get(PRODUCTS_URL)
        if resp.status_code == 200:
            products = resp.json()
        else:
            await update.effective_message.reply_text(f"Failed to fetch products: {resp.text}")
            welcome_message, reply_markup = get_start_menu()
            await update.effective_message.reply_text(welcome_message, reply_markup=reply_markup)
            return ConversationHandler.END
    except Exception as e:
        await update.effective_message.reply_text(f"Error fetching products: {e}")
        welcome_message, reply_markup = get_start_menu()
        await update.effective_message.reply_text(welcome_message, reply_markup=reply_markup)
        return ConversationHandler.END
    if not products:
        await update.effective_message.reply_text("No products available.")
        welcome_message, reply_markup = get_start_menu()
        await update.effective_message.reply_text(welcome_message, reply_markup=reply_markup)
        return ConversationHandler.END
    context.user_data['products'] = products
    msg = "Which product's flavour do you want to delete? Reply with the number.\n"
    for i, prod in enumerate(products):
        msg += f"\n{i+1}. {prod['name']} ({prod['id']})"
    await update.effective_message.reply_text(msg)
    return DELETE_FLAVOUR_CHOOSE_PRODUCT

async def deleteflavour_choose_product(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    products = context.user_data.get('products', [])
    if not text.isdigit() or int(text) < 1 or int(text) > len(products):
        await update.message.reply_text("Please reply with a valid number.")
        return DELETE_FLAVOUR_CHOOSE_PRODUCT
    idx = int(text) - 1
    product = products[idx]
    context.user_data['delete_flavour_product'] = product
    flavours = product.get('flavors', [])
    if not flavours:
        await update.message.reply_text("This product has no flavours to delete.")
        welcome_message, reply_markup = get_start_menu()
        await update.effective_message.reply_text(welcome_message, reply_markup=reply_markup)
        return ConversationHandler.END
    context.user_data['flavours'] = flavours
    msg = "Which flavour do you want to delete? Reply with the number.\n"
    for i, flav in enumerate(flavours):
        msg += f"\n{i+1}. {flav['name']} ({flav['id']})"
    await update.message.reply_text(msg)
    return DELETE_FLAVOUR_CHOOSE_FLAVOUR

async def deleteflavour_choose_flavour(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    flavours = context.user_data.get('flavours', [])
    if not text.isdigit() or int(text) < 1 or int(text) > len(flavours):
        await update.message.reply_text("Please reply with a valid number.")
        return DELETE_FLAVOUR_CHOOSE_FLAVOUR
    idx = int(text) - 1
    flavour = flavours[idx]
    context.user_data['delete_flavour'] = flavour
    await update.message.reply_text(f"Are you sure you want to delete flavour '{flavour['name']}'? Reply YES to confirm, or /cancel.")
    return DELETE_FLAVOUR_CHOOSE_FLAVOUR + 1  # Use next state for confirmation

async def deleteflavour_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message.text.strip().upper() != 'YES':
        await update.message.reply_text("Deletion cancelled.")
        welcome_message, reply_markup = get_start_menu()
        await update.effective_message.reply_text(welcome_message, reply_markup=reply_markup)
        return ConversationHandler.END
    product = context.user_data.get('delete_flavour_product')
    flavour = context.user_data.get('delete_flavour')
    env = get_env_vars()
    PRODUCTS_URL = env['API_BASE_URL'].rstrip('/') + '/api/products'
    API_SECRET = env['API_SECRET']
    try:
        resp = requests.delete(f"{PRODUCTS_URL}/{product['id']}/flavours/{flavour['id']}", json={"secret": API_SECRET})
        if resp.status_code == 200:
            await update.message.reply_text(f"Flavour '{flavour['name']}' deleted successfully!")
        else:
            await update.message.reply_text(f"Failed to delete flavour: {resp.text}")
    except Exception as e:
        await update.message.reply_text(f"Error deleting flavour: {e}")
    welcome_message, reply_markup = get_start_menu()
    await update.effective_message.reply_text(welcome_message, reply_markup=reply_markup)
    return ConversationHandler.END

async def hideflavour_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    env = get_env_vars()
    PRODUCTS_URL = env['API_BASE_URL'].rstrip('/') + '/api/products'
    try:
        resp = requests.get(PRODUCTS_URL)
        if resp.status_code == 200:
            products = resp.json()
        else:
            await update.effective_message.reply_text(f"Failed to fetch products: {resp.text}")
            welcome_message, reply_markup = get_start_menu()
            await update.effective_message.reply_text(welcome_message, reply_markup=reply_markup)
            return ConversationHandler.END
    except Exception as e:
        await update.effective_message.reply_text(f"Error fetching products: {e}")
        welcome_message, reply_markup = get_start_menu()
        await update.effective_message.reply_text(welcome_message, reply_markup=reply_markup)
        return ConversationHandler.END
    if not products:
        await update.effective_message.reply_text("No products available.")
        welcome_message, reply_markup = get_start_menu()
        await update.effective_message.reply_text(welcome_message, reply_markup=reply_markup)
        return ConversationHandler.END
    context.user_data['products'] = products
    msg = "Which product's flavour do you want to hide/show? Reply with the number.\n"
    for i, prod in enumerate(products):
        msg += f"\n{i+1}. {prod['name']} ({prod['id']})"
    await update.effective_message.reply_text(msg)
    return TOGGLE_FLAVOUR_CHOOSE_PRODUCT

async def hideflavour_choose_product(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    products = context.user_data.get('products', [])
    if not text.isdigit() or int(text) < 1 or int(text) > len(products):
        await update.message.reply_text("Please reply with a valid number.")
        return TOGGLE_FLAVOUR_CHOOSE_PRODUCT
    idx = int(text) - 1
    product = products[idx]
    context.user_data['hide_flavour_product'] = product
    flavours = product.get('flavors', [])
    if not flavours:
        await update.message.reply_text("This product has no flavours to hide/show.")
        welcome_message, reply_markup = get_start_menu()
        await update.effective_message.reply_text(welcome_message, reply_markup=reply_markup)
        return ConversationHandler.END
    context.user_data['flavours'] = flavours
    msg = "Which flavour do you want to hide/show? Reply with the number.\n"
    for i, flav in enumerate(flavours):
        status = "👁️ Visible" if flav.get('visible', True) else "🙈 Hidden"
        msg += f"\n{i+1}. {flav['name']} ({flav['id']}) - {status}"
    await update.message.reply_text(msg)
    return TOGGLE_FLAVOUR_CHOOSE_FLAVOUR

async def hideflavour_choose_flavour(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    flavours = context.user_data.get('flavours', [])
    if not text.isdigit() or int(text) < 1 or int(text) > len(flavours):
        await update.message.reply_text("Please reply with a valid number.")
        return TOGGLE_FLAVOUR_CHOOSE_FLAVOUR
    idx = int(text) - 1
    flavour = flavours[idx]
    product = context.user_data.get('hide_flavour_product')
    env = get_env_vars()
    PRODUCTS_URL = env['API_BASE_URL'].rstrip('/') + '/api/products'
    API_SECRET = env['API_SECRET']
    try:
        resp = requests.post(f"{PRODUCTS_URL}/{product['id']}/flavours/{flavour['id']}/hide", json={"secret": API_SECRET})
        if resp.status_code == 200:
            data = resp.json()
            new_status = "👁️ Visible" if data.get('visible', True) else "🙈 Hidden"
            await update.message.reply_text(f"Flavour '{flavour['name']}' is now {new_status}!")
        else:
            await update.message.reply_text(f"Failed to toggle visibility: {resp.text}")
    except Exception as e:
        await update.message.reply_text(f"Error toggling visibility: {e}")
    welcome_message, reply_markup = get_start_menu()
    await update.effective_message.reply_text(welcome_message, reply_markup=reply_markup)
    return ConversationHandler.END

# Export for bot_app.py
__all__ = [
    'others',
    'listcategories',
    'addcategory_start',
    'addcategory_name',
    'editcategory_start',
    'editcategory_choose',
    'editcategory_name',
    'deletecategory_start',
    'deletecategory_choose',
    'deletecategory_confirm',
]
__all__ += [
    'hidecategory_start',
    'hidecategory_choose',
]
__all__ += [
    'listproducts',
    'hideproduct_start',
    'hideproduct_choose',
]
__all__ += [
    'addproduct_start',
    'addproduct_name',
    'addproduct_category',
    'addproduct_flavour_name',
    'addproduct_flavour_desc',
    'addproduct_flavour_price',
    'addproduct_flavour_image',
]
__all__ += [
    'editproduct_start',
    'editproduct_choose',
    'editproduct_field',
    'editproduct_value',
    'deleteproduct_start',
]
__all__ += [
    'listflavours',
    'addflavour_start', 'addflavour_choose_product', 'addflavour_name', 'addflavour_desc', 'addflavour_price', 'addflavour_image',
    'editflavour_start',
    'editflavour_choose_product',
    'editflavour_choose_flavour',
    'editflavour_field',
    'editflavour_value',
    'deleteflavour_start',
    'deleteflavour_choose_product',
    'deleteflavour_choose_flavour',
    'deleteflavour_confirm',
    'hideflavour_start',
    'hideflavour_choose_product',
    'hideflavour_choose_flavour',
]

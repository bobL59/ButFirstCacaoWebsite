from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.constants import ParseMode
from telegram.ext import ContextTypes, ConversationHandler
from common import get_go_back_button, go_back_handler
import requests
from constants import (
    ADD_DESERT_NAME, ADD_DESERT_DESC, ADD_DESERT_PRICE, ADD_DESERT_IMAGE,
    EDIT_DESERT_CHOOSE, EDIT_DESERT_FIELD, EDIT_DESERT_VALUE,
    DELETE_DESERT_CHOOSE, DELETE_DESERT_CONFIRM,
    TOGGLE_DESERT_VISIBILITY_CHOOSE, TOGGLE_DESERT_AVAILABILITY_CHOOSE,
    ADD_DESERT_IMAGE_CHOOSE, DELETE_DESERT_IMAGE_CHOOSE, DELETE_DESERT_IMAGE_CONFIRM
)
from common import get_env_vars

# Helper to generate the desserts message
DESSERTS_MESSAGE = (
    "🍰 <b>Desserts</b>\n"
    "Select an action below:"
)

# Inline keyboard for dessert actions
DESSERTS_KEYBOARD = [
    [InlineKeyboardButton("Add a new dessert", callback_data="adddesert")],
    [InlineKeyboardButton("View all desserts", callback_data="listdesserts")],
    [InlineKeyboardButton("Modify a dessert", callback_data="editdesert")],
    [InlineKeyboardButton("Remove a dessert", callback_data="deletedessert")],
    [InlineKeyboardButton("Toggle dessert visibility", callback_data="toggledessert")],
    [InlineKeyboardButton("Update dessert availability", callback_data="toggleavailability")],
    [InlineKeyboardButton("Add dessert photo", callback_data="adddessertimage")],
    [InlineKeyboardButton("Remove dessert photo", callback_data="deletedessertimage")],
    get_go_back_button(),
]
DESSERTS_REPLY_MARKUP = InlineKeyboardMarkup(DESSERTS_KEYBOARD)

# Get env vars for API usage
env = get_env_vars()
DESERTS_URL = env['DESERTS_URL']
API_SECRET = env['API_SECRET']

# Utility to get the correct message object
def get_effective_message(update):
    if update.callback_query:
        return update.callback_query.message
    return update.message

async def desserts(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Handles both command and callback
    if update.message:
        await get_effective_message(update).reply_text(
            DESSERTS_MESSAGE,
            parse_mode=ParseMode.HTML,
            reply_markup=DESSERTS_REPLY_MARKUP
        )
    elif update.callback_query:
        query = update.callback_query
        await query.answer()
        # Always show desserts menu for category_desserts
        if query.data == "category_desserts":
            await query.edit_message_text(
                DESSERTS_MESSAGE,
                parse_mode=ParseMode.HTML,
                reply_markup=DESSERTS_REPLY_MARKUP
            )
            return
        # Handle go back button
        if query.data == "go_back":
            from handlers import start  # Import here to avoid circular import
            await go_back_handler(update, context, start)
            return
        # You can add more button handlers here as needed
        await query.edit_message_text(
            DESSERTS_MESSAGE,
            parse_mode=ParseMode.HTML,
            reply_markup=DESSERTS_REPLY_MARKUP
        )

async def add_desert_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Handle both command and callback
    if update.message:
        await get_effective_message(update).reply_text("Please enter the name of the new dessert:")
    elif update.callback_query:
        await update.callback_query.answer()
        await get_effective_message(update).reply_text("Please enter the name of the new dessert:")
    return ADD_DESERT_NAME

async def add_desert_name(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['dessert_name'] = update.message.text
    await get_effective_message(update).reply_text("Please enter the dessert description:")
    return ADD_DESERT_DESC

async def add_desert_desc(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['dessert_desc'] = update.message.text
    await get_effective_message(update).reply_text("Please enter the dessert price in Lari:")
    return ADD_DESERT_PRICE

async def add_desert_price(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        price = float(update.message.text)
        context.user_data['dessert_price'] = price
        await get_effective_message(update).reply_text(
            "Please send an image for the dessert.\n"
            "You can add more images later using /add_dessert_image command."
        )
        return ADD_DESERT_IMAGE
    except ValueError:
        await get_effective_message(update).reply_text("Invalid price. Please enter a valid number:")
        return ADD_DESERT_PRICE

async def add_desert_image(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # This handler is ONLY for new dessert creation
    image_url = None
    file_id = None

    if update.message.photo:
        photo = update.message.photo[-1]
        file_id = photo.file_id
        file = await update.message.get_bot().get_file(file_id)
        file_path = file.file_path
        if file_path.startswith('http'):
            image_url = file_path
        else:
            bot_token = context.bot.token
            image_url = f"https://api.telegram.org/file/bot{bot_token}/{file_path}"
    elif update.message.text and update.message.text.startswith('http'):
        image_url = update.message.text
    else:
        await get_effective_message(update).reply_text("Please send a photo or a valid image URL.")
        return ADD_DESERT_IMAGE

    try:
        # Create new dessert
        dessert_data = {
            'name': context.user_data['dessert_name'],
            'description': context.user_data['dessert_desc'],
            'price': context.user_data['dessert_price'],
            'secret': API_SECRET
        }

        resp = requests.post(DESERTS_URL, json=dessert_data)
        if resp.status_code != 200:
            await get_effective_message(update).reply_text(f"Failed to create dessert: {resp.text}")
            from handlers import start
            await start(update, context)
            return ConversationHandler.END

        # Parse the response to get the dessert data
        response_data = resp.json()
        print("DEBUG: Dessert creation response:", response_data)  # Debug print
        if isinstance(response_data, dict) and 'dessert' in response_data:
            dessert = response_data['dessert']
        elif isinstance(response_data, dict) and 'id' in response_data:
            dessert = response_data
        else:
            await get_effective_message(update).reply_text("Invalid response from server when creating dessert.")
            from handlers import start
            await start(update, context)
            return ConversationHandler.END

        # Add the image
        image_data = {
            'image_url': image_url,
            'secret': API_SECRET
        }

        resp = requests.post(f"{DESERTS_URL}/{dessert['id']}/images", json=image_data)
        if resp.status_code != 200:
            await get_effective_message(update).reply_text("Dessert created, but failed to add image.")
            from handlers import start
            await start(update, context)
            return ConversationHandler.END

        await get_effective_message(update).reply_text("Dessert added successfully!")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    except Exception as e:
        await get_effective_message(update).reply_text(f"Error adding dessert/image: {e}")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END

# New handler for uploading an image to an existing dessert
async def add_dessert_image_upload(update: Update, context: ContextTypes.DEFAULT_TYPE):
    image_url = None
    file_id = None
    dessert = context.user_data.get('selected_dessert')
    if not dessert:
        await get_effective_message(update).reply_text("No dessert selected. Please start again.")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END

    if update.message.photo:
        photo = update.message.photo[-1]
        file_id = photo.file_id
        file = await update.message.get_bot().get_file(file_id)
        file_path = file.file_path
        if file_path.startswith('http'):
            image_url = file_path
        else:
            bot_token = context.bot.token
            image_url = f"https://api.telegram.org/file/bot{bot_token}/{file_path}"
    elif update.message.text and update.message.text.startswith('http'):
        image_url = update.message.text
    else:
        await get_effective_message(update).reply_text("Please send a photo or a valid image URL.")
        return ADD_DESERT_IMAGE

    try:
        image_data = {
            'image_url': image_url,
            'secret': API_SECRET
        }
        resp = requests.post(f"{DESERTS_URL}/{dessert['id']}/images", json=image_data)
        if resp.status_code == 200:
            await get_effective_message(update).reply_text("Image added successfully!")
        else:
            await get_effective_message(update).reply_text(f"Failed to add image: {resp.text}")
    except Exception as e:
        await get_effective_message(update).reply_text(f"Error adding image: {e}")
    from handlers import start
    await start(update, context)
    return ConversationHandler.END

# List desserts
async def list_desserts(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Handle both command and callback
    if update.callback_query:
        await update.callback_query.answer()
        message = update.callback_query.message
    else:
        message = update.message
    try:
        resp = requests.get(DESERTS_URL)
        if resp.status_code == 200:
            desserts = resp.json()
        else:
            await message.reply_text(f"Failed to fetch desserts: {resp.text}")
            from handlers import start
            await start(update, context)
            return ConversationHandler.END
    except Exception as e:
        await message.reply_text(f"Error fetching desserts: {e}")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END

    if not desserts:
        await message.reply_text("No desserts found.")
        return

    chunk_size = 5
    for i in range(0, len(desserts), chunk_size):
        chunk = desserts[i:i + chunk_size]
        msg = f"Desserts (Part {i//chunk_size + 1}):\n\n"
        for dessert in chunk:
            status_stickers = []
            if not dessert.get('visible', True):
                status_stickers.append("👁️ Hidden")
            if not dessert.get('available', True):
                status_stickers.append("⏳ Not Available Now")
            elif dessert.get('available', True):
                status_stickers.append("✅ Available Now")
            msg += f"<b>{dessert['name']}</b>"
            if status_stickers:
                msg += f" {' '.join(status_stickers)}"
            msg += f"\nPrice: {dessert['price']} Lari\nDescription: {dessert['description']}\nImages: {len(dessert['images'])} 📸\n\n"
        await message.reply_text(msg, parse_mode='HTML')

# Edit dessert (step 1: choose)
async def edit_dessert_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        resp = requests.get(DESERTS_URL)
        if resp.status_code == 200:
            desserts = resp.json()
        else:
            await get_effective_message(update).reply_text(f"Failed to fetch desserts: {resp.text}")
            from handlers import start
            await start(update, context)
            return ConversationHandler.END
    except Exception as e:
        await get_effective_message(update).reply_text(f"Error fetching desserts: {e}")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    if not desserts:
        await get_effective_message(update).reply_text("No desserts to edit.")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    context.user_data['desserts'] = desserts
    chunk_size = 10
    for i in range(0, len(desserts), chunk_size):
        chunk = desserts[i:i + chunk_size]
        msg = f"Which dessert do you want to edit? (Part {i//chunk_size + 1})\nReply with the number.\n"
        for j, dessert in enumerate(chunk):
            msg += f"\n{i+j+1}. {dessert['name']} ({dessert['price']} Lari)"
        await get_effective_message(update).reply_text(msg)
    return EDIT_DESERT_CHOOSE

async def edit_dessert_choose(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    if not text.isdigit():
        await get_effective_message(update).reply_text("Please reply with a valid number.")
        return EDIT_DESERT_CHOOSE
    idx = int(text) - 1
    desserts = context.user_data.get('desserts', [])
    if idx < 0 or idx >= len(desserts):
        await get_effective_message(update).reply_text("Number out of range. Try again.")
        return EDIT_DESERT_CHOOSE
    context.user_data['edit_dessert'] = desserts[idx]
    await get_effective_message(update).reply_text(
        "What would you like to edit?\n• name - Dessert name\n• description - Dessert description\n• price - Dessert price"
    )
    return EDIT_DESERT_FIELD

async def edit_dessert_field(update: Update, context: ContextTypes.DEFAULT_TYPE):
    field = update.message.text.strip().lower()
    valid_fields = ['name', 'description', 'price']
    if field not in valid_fields:
        await get_effective_message(update).reply_text("Invalid field. Please choose from: name, description, price")
        return EDIT_DESERT_FIELD
    context.user_data['edit_field'] = field
    if field == 'price':
        await get_effective_message(update).reply_text("Please enter the new price in Lari:")
    else:
        await get_effective_message(update).reply_text(f"Please enter the new {field}:")
    return EDIT_DESERT_VALUE

async def edit_dessert_value(update: Update, context: ContextTypes.DEFAULT_TYPE):
    value = update.message.text.strip()
    field = context.user_data.get('edit_field')
    dessert = context.user_data.get('edit_dessert')
    if field == 'price':
        try:
            value = float(value)
        except ValueError:
            await get_effective_message(update).reply_text("Invalid price. Please enter a valid number:")
            return EDIT_DESERT_VALUE
    try:
        updates = {field: value}
        if field == 'name':
            updates['id'] = value.lower().replace(' ', '-')
        resp = requests.put(
            f"{DESERTS_URL}/{dessert['id']}",
            json={**updates, 'secret': API_SECRET}
        )
        if resp.status_code == 200:
            await get_effective_message(update).reply_text("Dessert updated successfully!")
        else:
            await get_effective_message(update).reply_text(f"Failed to update dessert: {resp.text}")
    except Exception as e:
        await get_effective_message(update).reply_text(f"Error updating dessert: {e}")
    from handlers import start
    await start(update, context)
    return ConversationHandler.END

# Delete dessert
async def delete_dessert_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        resp = requests.get(DESERTS_URL)
        if resp.status_code == 200:
            desserts = resp.json()
        else:
            await get_effective_message(update).reply_text(f"Failed to fetch desserts: {resp.text}")
            from handlers import start
            await start(update, context)
            return ConversationHandler.END
    except Exception as e:
        await get_effective_message(update).reply_text(f"Error fetching desserts: {e}")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    if not desserts:
        await get_effective_message(update).reply_text("No desserts to delete.")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    context.user_data['desserts'] = desserts
    chunk_size = 10
    for i in range(0, len(desserts), chunk_size):
        chunk = desserts[i:i + chunk_size]
        msg = f"Which dessert do you want to delete? (Part {i//chunk_size + 1})\nReply with the number.\n"
        for j, dessert in enumerate(chunk):
            msg += f"\n{i+j+1}. {dessert['name']} ({dessert['price']} Lari)"
        await get_effective_message(update).reply_text(msg)
    return DELETE_DESERT_CHOOSE

async def delete_dessert_choose(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    if not text.isdigit():
        await get_effective_message(update).reply_text("Please reply with a valid number.")
        return DELETE_DESERT_CHOOSE
    idx = int(text) - 1
    desserts = context.user_data.get('desserts', [])
    if idx < 0 or idx >= len(desserts):
        await get_effective_message(update).reply_text("Number out of range. Try again.")
        return DELETE_DESERT_CHOOSE
    context.user_data['delete_dessert'] = desserts[idx]
    msg = f"Are you sure you want to delete {desserts[idx]['name']}? Reply YES to confirm, or /cancel."
    await get_effective_message(update).reply_text(msg)
    return DELETE_DESERT_CONFIRM

async def delete_dessert_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message.text.strip().upper() != 'YES':
        await get_effective_message(update).reply_text("Deletion cancelled.")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    dessert = context.user_data.get('delete_dessert')
    if not dessert:
        await get_effective_message(update).reply_text("No dessert selected.")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    try:
        resp = requests.delete(
            f"{DESERTS_URL}/{dessert['id']}",
            json={'secret': API_SECRET}
        )
        if resp.status_code in [200, 204]:
            await get_effective_message(update).reply_text("Dessert deleted successfully!")
        else:
            await get_effective_message(update).reply_text(f"Failed to delete dessert: {resp.text}")
    except Exception as e:
        await get_effective_message(update).reply_text(f"Error deleting dessert: {e}")
    from handlers import start
    await start(update, context)
    return ConversationHandler.END

# Toggle dessert visibility
async def toggle_dessert_visibility_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        resp = requests.get(DESERTS_URL)
        if resp.status_code != 200:
            await get_effective_message(update).reply_text(f"Failed to fetch desserts: {resp.text}")
            from handlers import start
            await start(update, context)
            return ConversationHandler.END
        desserts = resp.json()
        if not desserts:
            await get_effective_message(update).reply_text("No desserts to toggle.")
            from handlers import start
            await start(update, context)
            return ConversationHandler.END
        context.user_data['desserts'] = desserts
        chunk_size = 10
        for i in range(0, len(desserts), chunk_size):
            chunk = desserts[i:i + chunk_size]
            msg = f"Which dessert's visibility do you want to toggle? (Part {i//chunk_size + 1})\nReply with the number.\n"
            for j, dessert in enumerate(chunk):
                status = "👁️ Hidden" if not dessert.get('visible', True) else "👁️ Visible"
                msg += f"\n{i+j+1}. {dessert['name']} - {status}"
            await get_effective_message(update).reply_text(msg)
        return TOGGLE_DESERT_VISIBILITY_CHOOSE
    except Exception as e:
        await get_effective_message(update).reply_text(f"Error fetching desserts: {e}")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END

async def toggle_dessert_visibility_choose(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        text = update.message.text.strip()
        if not text.isdigit():
            await get_effective_message(update).reply_text("Please reply with a valid number.")
            return TOGGLE_DESERT_VISIBILITY_CHOOSE
        idx = int(text) - 1
        desserts = context.user_data.get('desserts', [])
        if idx < 0 or idx >= len(desserts):
            await get_effective_message(update).reply_text("Number out of range. Try again.")
            return TOGGLE_DESERT_VISIBILITY_CHOOSE
        dessert = desserts[idx]
        current_visibility = dessert.get('visible', True)
        await get_effective_message(update).reply_text("Processing visibility toggle...")
        try:
            resp = requests.put(
                f"{DESERTS_URL}/{dessert['id']}",
                json={
                    'visible': not current_visibility,
                    'secret': API_SECRET
                },
                timeout=10
            )
            if resp.status_code == 200:
                new_status = "hidden" if current_visibility else "visible"
                await get_effective_message(update).reply_text(f"Dessert is now {new_status}!")
            else:
                await get_effective_message(update).reply_text(f"Failed to toggle visibility: {resp.text}")
        except requests.Timeout:
            await get_effective_message(update).reply_text("Request timed out. Please try again.")
        except requests.RequestException as e:
            await get_effective_message(update).reply_text(f"Error toggling visibility: {str(e)}")
        except Exception as e:
            await get_effective_message(update).reply_text(f"Unexpected error: {str(e)}")
    except Exception as e:
        await get_effective_message(update).reply_text(f"Error processing request: {e}")
    from handlers import start
    await start(update, context)
    return ConversationHandler.END

# Toggle dessert availability
async def toggle_dessert_availability_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        resp = requests.get(DESERTS_URL)
        if resp.status_code == 200:
            desserts = resp.json()
        else:
            await get_effective_message(update).reply_text(f"Failed to fetch desserts: {resp.text}")
            from handlers import start
            await start(update, context)
            return ConversationHandler.END
    except Exception as e:
        await get_effective_message(update).reply_text(f"Error fetching desserts: {e}")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    if not desserts:
        await get_effective_message(update).reply_text("No desserts to toggle.")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    context.user_data['desserts'] = desserts
    chunk_size = 10
    for i in range(0, len(desserts), chunk_size):
        chunk = desserts[i:i + chunk_size]
        msg = f"Which dessert's availability do you want to toggle? (Part {i//chunk_size + 1})\nReply with the number.\n"
        for j, dessert in enumerate(chunk):
            status = "⏳ Not Available Now" if not dessert.get('available', True) else "✅ Available Now"
            msg += f"\n{i+j+1}. {dessert['name']} - {status}"
        await get_effective_message(update).reply_text(msg)
    return TOGGLE_DESERT_AVAILABILITY_CHOOSE

async def toggle_dessert_availability_choose(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    if not text.isdigit():
        await get_effective_message(update).reply_text("Please reply with a valid number.")
        return TOGGLE_DESERT_AVAILABILITY_CHOOSE
    idx = int(text) - 1
    desserts = context.user_data.get('desserts', [])
    if idx < 0 or idx >= len(desserts):
        await get_effective_message(update).reply_text("Number out of range. Try again.")
        return TOGGLE_DESERT_AVAILABILITY_CHOOSE
    dessert = desserts[idx]
    try:
        resp = requests.put(
            f"{DESERTS_URL}/{dessert['id']}",
            json={
                'available': not dessert.get('available', True),
                'secret': API_SECRET
            }
        )
        if resp.status_code == 200:
            new_status = "not available" if dessert.get('available', True) else "available"
            await get_effective_message(update).reply_text(f"Dessert is now {new_status}!")
        else:
            await get_effective_message(update).reply_text(f"Failed to toggle availability: {resp.text}")
    except Exception as e:
        await get_effective_message(update).reply_text(f"Error toggling availability: {e}")
    from handlers import start
    await start(update, context)
    return ConversationHandler.END

# Add dessert image
async def add_dessert_image_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        resp = requests.get(DESERTS_URL)
        if resp.status_code == 200:
            desserts = resp.json()
        else:
            await get_effective_message(update).reply_text(f"Failed to fetch desserts: {resp.text}")
            from handlers import start
            await start(update, context)
            return ConversationHandler.END
    except Exception as e:
        await get_effective_message(update).reply_text(f"Error fetching desserts: {e}")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    if not desserts:
        await get_effective_message(update).reply_text("No desserts to add images to.")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    context.user_data['desserts'] = desserts
    chunk_size = 10
    for i in range(0, len(desserts), chunk_size):
        chunk = desserts[i:i + chunk_size]
        msg = f"Which dessert do you want to add an image to? (Part {i//chunk_size + 1})\nReply with the number.\n"
        for j, dessert in enumerate(chunk):
            msg += f"\n{i+j+1}. {dessert['name']} ({len(dessert['images'])} images)"
        await get_effective_message(update).reply_text(msg)
    return ADD_DESERT_IMAGE_CHOOSE

async def add_dessert_image_choose(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    if not text.isdigit():
        await get_effective_message(update).reply_text("Please reply with a valid number.")
        return ADD_DESERT_IMAGE_CHOOSE
    idx = int(text) - 1
    desserts = context.user_data.get('desserts', [])
    if idx < 0 or idx >= len(desserts):
        await get_effective_message(update).reply_text("Number out of range. Try again.")
        return ADD_DESERT_IMAGE_CHOOSE
    context.user_data['selected_dessert'] = desserts[idx]
    await get_effective_message(update).reply_text(
        "Please send an image for the dessert (send a photo or paste an image URL)."
    )
    return ADD_DESERT_IMAGE

async def delete_dessert_image_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        resp = requests.get(DESERTS_URL)
        if resp.status_code == 200:
            desserts = resp.json()
        else:
            await get_effective_message(update).reply_text(f"Failed to fetch desserts: {resp.text}")
            from handlers import start
            await start(update, context)
            return ConversationHandler.END
    except Exception as e:
        await get_effective_message(update).reply_text(f"Error fetching desserts: {e}")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    if not desserts:
        await get_effective_message(update).reply_text("No desserts to delete images from.")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    context.user_data['desserts'] = desserts
    chunk_size = 10
    for i in range(0, len(desserts), chunk_size):
        chunk = desserts[i:i + chunk_size]
        msg = f"Which dessert's image do you want to delete? (Part {i//chunk_size + 1})\nReply with the number.\n"
        for j, dessert in enumerate(chunk):
            if dessert['images']:
                msg += f"\n{i+j+1}. {dessert['name']} ({len(dessert['images'])} images)"
        await get_effective_message(update).reply_text(msg)
    return DELETE_DESERT_IMAGE_CHOOSE

async def delete_dessert_image_choose(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    if not text.isdigit():
        await get_effective_message(update).reply_text("Please reply with a valid number.")
        return DELETE_DESERT_IMAGE_CHOOSE
    idx = int(text) - 1
    desserts = context.user_data.get('desserts', [])
    if idx < 0 or idx >= len(desserts):
        await get_effective_message(update).reply_text("Number out of range. Try again.")
        return DELETE_DESERT_IMAGE_CHOOSE
    dessert = desserts[idx]
    if not dessert['images']:
        await get_effective_message(update).reply_text("This dessert has no images to delete.")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    context.user_data['selected_dessert'] = dessert
    msg = "Which image do you want to delete? Reply with the number.\n"
    for i, image in enumerate(dessert['images']):
        msg += f"\n{i+1}. {image}"
    await get_effective_message(update).reply_text(msg)
    return DELETE_DESERT_IMAGE_CONFIRM

async def delete_dessert_image_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    if not text.isdigit():
        await get_effective_message(update).reply_text("Please reply with a valid number.")
        return DELETE_DESERT_IMAGE_CONFIRM
    idx = int(text) - 1
    dessert = context.user_data.get('selected_dessert')
    if not dessert or idx < 0 or idx >= len(dessert['images']):
        await get_effective_message(update).reply_text("Invalid image selection.")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    image_filename = dessert['images'][idx]
    try:
        response = requests.delete(
            f"{DESERTS_URL}/{dessert['id']}/images/{image_filename}",
            json={'secret': API_SECRET}
        )
        if response.ok:
            await get_effective_message(update).reply_text("✅ Image deleted successfully!")
        else:
            await get_effective_message(update).reply_text(f"Failed to delete image: {response.text}")
    except Exception as e:
        await get_effective_message(update).reply_text(f"Error deleting image: {e}")
    from handlers import start
    await start(update, context)
    return ConversationHandler.END

# Export for bot_app.py
__all__ = [
    'desserts',
    'add_desert_start', 'add_desert_name', 'add_desert_desc', 'add_desert_price', 'add_desert_image',
    'list_desserts', 'edit_dessert_start', 'edit_dessert_choose', 'edit_dessert_field', 'edit_dessert_value',
    'delete_dessert_start', 'delete_dessert_choose', 'delete_dessert_confirm',
    'toggle_dessert_visibility_start', 'toggle_dessert_visibility_choose',
    'toggle_dessert_availability_start', 'toggle_dessert_availability_choose',
    'add_dessert_image_start', 'add_dessert_image_choose',
    'delete_dessert_image_start', 'delete_dessert_image_choose', 'delete_dessert_image_confirm',
]

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.constants import ParseMode
from telegram.ext import ContextTypes, ConversationHandler
from common import get_go_back_button, go_back_handler
from constants import ADD_DISH_NAME, ADD_DISH_DESC, ADD_DISH_PRICE, ADD_DISH_IMAGE, EDIT_DISH_CHOOSE, EDIT_DISH_FIELD, EDIT_DISH_VALUE, DELETE_DISH_CHOOSE, DELETE_DISH_CONFIRM, ADD_DISH_IMAGE_CHOOSE, DELETE_DISH_IMAGE_CHOOSE, DELETE_DISH_IMAGE_CONFIRM
import requests
from common import get_env_vars
import io

# Helper to generate the dishes message
DISHES_MESSAGE = (
    "🍽️ <b>Dishes</b>\n"
    "Select an action below:"
)

# Inline keyboard for dishes actions
DISHES_KEYBOARD = [
    [InlineKeyboardButton("Add a new dish", callback_data="adddish")],
    [InlineKeyboardButton("Edit a dish", callback_data="editdish")],
    [InlineKeyboardButton("Remove a dish", callback_data="removedish")],
    [InlineKeyboardButton("Add dish image", callback_data="adddishimage")],
    [InlineKeyboardButton("Remove dish image", callback_data="removedishimage")],
    [InlineKeyboardButton("List all dishes", callback_data="listdishes")],
    [InlineKeyboardButton("Toggle dish visibility", callback_data="toggledishvisibility")],
    [InlineKeyboardButton("Toggle dish storage", callback_data="toggledishstorage")],
    get_go_back_button(),
]
DISHES_REPLY_MARKUP = InlineKeyboardMarkup(DISHES_KEYBOARD)

# Inline keyboard for editing dish fields
EDIT_DISH_FIELDS_KEYBOARD = InlineKeyboardMarkup([
    [InlineKeyboardButton("Name", callback_data="editfield_name")],
    [InlineKeyboardButton("Description", callback_data="editfield_description")],
    [InlineKeyboardButton("Price", callback_data="editfield_price")],
])

# Get env vars for API usage
env = get_env_vars()
DISHES_URL = env.get('DISHES_URL', 'http://localhost:3001/api/dishes')
API_SECRET = env['API_SECRET']

def get_effective_message(update):
    if update.callback_query:
        return update.callback_query.message
    return update.message

async def dishes(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message:
        await update.message.reply_text(
            DISHES_MESSAGE,
            parse_mode=ParseMode.HTML,
            reply_markup=DISHES_REPLY_MARKUP
        )
    elif update.callback_query:
        query = update.callback_query
        await query.answer()
        data = query.data
        if data == "go_back":
            await go_back_handler(update, context)
            return
        elif data == "adddish":
            await add_dish_start(update, context)
            return
        elif data == "editdish":
            await edit_dish(update, context)
            return
        elif data == "removedish":
            await remove_dish(update, context)
            return
        elif data == "adddishimage":
            await add_dish_image_start(update, context)
            return
        elif data == "removedishimage":
            await delete_dish_image_start(update, context)
            return
        elif data == "listdishes":
            await list_dishes(update, context)
            return
        elif data == "toggledishvisibility":
            await toggle_dish_visibility(update, context)
            return
        elif data == "toggledishstorage":
            await toggle_dish_stock(update, context)
            return
        # Default: re-show the menu
        await query.edit_message_text(
            DISHES_MESSAGE,
            parse_mode=ParseMode.HTML,
            reply_markup=DISHES_REPLY_MARKUP
        )

async def add_dish_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message:
        await get_effective_message(update).reply_text("Please enter the name of the new dish:")
    elif update.callback_query:
        await update.callback_query.answer()
        await get_effective_message(update).reply_text("Please enter the name of the new dish:")
    return ADD_DISH_NAME

async def add_dish_name(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['dish_name'] = update.message.text
    await get_effective_message(update).reply_text("Please enter the dish description:")
    return ADD_DISH_DESC

async def add_dish_desc(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['dish_desc'] = update.message.text
    await get_effective_message(update).reply_text("Please enter the dish price in Lari:")
    return ADD_DISH_PRICE

async def add_dish_price(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        price = float(update.message.text)
        context.user_data['dish_price'] = price
        await get_effective_message(update).reply_text(
            "Please send an image for the dish.\nYou can add more images later using the menu."
        )
        return ADD_DISH_IMAGE
    except ValueError:
        await get_effective_message(update).reply_text("Invalid price. Please enter a valid number:")
        return ADD_DISH_PRICE

async def add_dish_image(update: Update, context: ContextTypes.DEFAULT_TYPE):
    image_url = None
    file_id = None

    if update.message.photo:
        photo = update.message.photo[-1]
        file_id = photo.file_id
        file = await update.message.get_bot().get_file(file_id)
        file_path = file.file_path
        if file_path.startswith('http'):
            image_url = file_path
        else:
            bot_token = context.bot.token
            image_url = f"https://api.telegram.org/file/bot{bot_token}/{file_path}"
    elif update.message.text and update.message.text.startswith('http'):
        image_url = update.message.text
    else:
        await get_effective_message(update).reply_text("Please send a photo or a valid image URL.")
        return ADD_DISH_IMAGE

    try:
        # Step 1: Create the dish (without image)
        dish_data = {
            'name': context.user_data['dish_name'],
            'description': context.user_data['dish_desc'],
            'price': context.user_data['dish_price'],
            'secret': API_SECRET
        }
        resp = requests.post(DISHES_URL, json=dish_data)
        if resp.status_code != 200:
            await get_effective_message(update).reply_text(f"Failed to create dish: {resp.text}")
            from handlers import start
            await start(update, context)
            return ConversationHandler.END
        response_data = resp.json()
        dish_id = response_data.get('id')
        if not dish_id:
            await get_effective_message(update).reply_text("Invalid response from server when creating dish.")
            from handlers import start
            await start(update, context)
            return ConversationHandler.END
        # Step 2: Upload the image
        image_data = {
            'image_url': image_url,
            'secret': API_SECRET
        }
        resp = requests.post(f"{DISHES_URL}/{dish_id}/images", json=image_data)
        if resp.status_code != 200:
            await get_effective_message(update).reply_text("Dish created, but failed to add image.")
            from handlers import start
            await start(update, context)
            return ConversationHandler.END
        await get_effective_message(update).reply_text("Dish added successfully!")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    except Exception as e:
        await get_effective_message(update).reply_text(f"Error adding dish/image: {e}")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END

async def edit_dish(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Start the edit workflow
    try:
        resp = requests.get(f"{DISHES_URL}/all")
        if resp.status_code == 200:
            dishes = resp.json()
        else:
            await update.callback_query.message.reply_text(f"Failed to fetch dishes: {resp.text}")
            from handlers import start
            await start(update, context)
            return ConversationHandler.END
    except Exception as e:
        await update.callback_query.message.reply_text(f"Error fetching dishes: {e}")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    if not dishes:
        await update.callback_query.message.reply_text("No dishes to edit.")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    context.user_data['dishes'] = dishes
    chunk_size = 10
    for i in range(0, len(dishes), chunk_size):
        chunk = dishes[i:i + chunk_size]
        msg = f"Which dish do you want to edit? (Part {i//chunk_size + 1})\nReply with the number.\n"
        for j, dish in enumerate(chunk):
            name = dish.get('titleKey') or dish.get('name')
            msg += f"\n{i+j+1}. {name} ({dish.get('price', '?')} Lari)"
        await update.callback_query.message.reply_text(msg)
    return EDIT_DISH_CHOOSE

async def edit_dish_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # For ConversationHandler entry point (not used directly here)
    return await edit_dish(update, context)

async def edit_dish_choose(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    if not text.isdigit():
        await get_effective_message(update).reply_text("Please reply with a valid number.")
        return EDIT_DISH_CHOOSE
    idx = int(text) - 1
    dishes = context.user_data.get('dishes', [])
    if idx < 0 or idx >= len(dishes):
        await get_effective_message(update).reply_text("Number out of range. Try again.")
        return EDIT_DISH_CHOOSE
    context.user_data['edit_dish'] = dishes[idx]
    await get_effective_message(update).reply_text(
        "What would you like to edit?",
        reply_markup=EDIT_DISH_FIELDS_KEYBOARD
    )
    return EDIT_DISH_FIELD

async def edit_dish_field(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.callback_query:
        data = update.callback_query.data
        if data.startswith("editfield_"):
            field = data.replace("editfield_", "")
        else:
            await update.callback_query.answer()
            await get_effective_message(update).reply_text("Invalid field selection.")
            return EDIT_DISH_FIELD
        await update.callback_query.answer()
    else:
        field = update.message.text.strip().lower()
    valid_fields = ['name', 'description', 'price']
    if field not in valid_fields:
        await get_effective_message(update).reply_text("Invalid field. Please choose from: name, description, price")
        return EDIT_DISH_FIELD
    context.user_data['edit_field'] = field
    if field == 'price':
        await get_effective_message(update).reply_text("Please enter the new price in Lari:")
    else:
        await get_effective_message(update).reply_text(f"Please enter the new {field}:")
    return EDIT_DISH_VALUE

async def edit_dish_value(update: Update, context: ContextTypes.DEFAULT_TYPE):
    value = update.message.text.strip()
    field = context.user_data.get('edit_field')
    dish = context.user_data.get('edit_dish')
    payload = {'secret': API_SECRET}
    if field == 'price':
        try:
            value = float(value)
        except ValueError:
            await get_effective_message(update).reply_text("Invalid price. Please enter a valid number:")
            return EDIT_DISH_VALUE
        payload['price'] = value
    elif field == 'name':
        payload['name'] = value
    elif field == 'description':
        payload['description'] = value
    try:
        resp = requests.put(
            f"{DISHES_URL}/{dish['id']}",
            json=payload
        )
        if resp.status_code == 200:
            await get_effective_message(update).reply_text("Dish updated successfully!")
        else:
            await get_effective_message(update).reply_text(f"Failed to update dish: {resp.text}")
    except Exception as e:
        await get_effective_message(update).reply_text(f"Error updating dish: {e}")
    from handlers import start
    await start(update, context)
    return ConversationHandler.END

async def remove_dish(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        resp = requests.get(f"{DISHES_URL}/all")
        if resp.status_code == 200:
            dishes = resp.json()
        else:
            await update.callback_query.message.reply_text(f"Failed to fetch dishes: {resp.text}")
            from handlers import start
            await start(update, context)
            return ConversationHandler.END
    except Exception as e:
        await update.callback_query.message.reply_text(f"Error fetching dishes: {e}")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    if not dishes:
        await update.callback_query.message.reply_text("No dishes to delete.")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    context.user_data['dishes'] = dishes
    chunk_size = 10
    for i in range(0, len(dishes), chunk_size):
        chunk = dishes[i:i + chunk_size]
        msg = f"Which dish do you want to delete? (Part {i//chunk_size + 1})\nReply with the number.\n"
        for j, dish in enumerate(chunk):
            name = dish.get('titleKey') or dish.get('name')
            msg += f"\n{i+j+1}. {name} ({dish.get('price', '?')} Lari)"
        await update.callback_query.message.reply_text(msg)
    return DELETE_DISH_CHOOSE

async def delete_dish_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # For ConversationHandler entry point (not used directly here)
    return await remove_dish(update, context)

async def delete_dish_choose(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    if not text.isdigit():
        await get_effective_message(update).reply_text("Please reply with a valid number.")
        return DELETE_DISH_CHOOSE
    idx = int(text) - 1
    dishes = context.user_data.get('dishes', [])
    if idx < 0 or idx >= len(dishes):
        await get_effective_message(update).reply_text("Number out of range. Try again.")
        return DELETE_DISH_CHOOSE
    context.user_data['delete_dish'] = dishes[idx]
    name = dishes[idx].get('titleKey') or dishes[idx].get('name')
    msg = f"Are you sure you want to delete {name}? Reply YES to confirm, or /cancel."
    await get_effective_message(update).reply_text(msg)
    return DELETE_DISH_CONFIRM

async def delete_dish_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message.text.strip().upper() != 'YES':
        await get_effective_message(update).reply_text("Deletion cancelled.")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    dish = context.user_data.get('delete_dish')
    if not dish:
        await get_effective_message(update).reply_text("No dish selected.")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    try:
        resp = requests.delete(
            f"{DISHES_URL}/{dish['id']}",
            json={'secret': API_SECRET}
        )
        if resp.status_code in [200, 204]:
            await get_effective_message(update).reply_text("Dish deleted successfully!")
        else:
            await get_effective_message(update).reply_text(f"Failed to delete dish: {resp.text}")
    except Exception as e:
        await get_effective_message(update).reply_text(f"Error deleting dish: {e}")
    from handlers import start
    await start(update, context)
    return ConversationHandler.END

async def add_dish_image_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        resp = requests.get(f"{DISHES_URL}/all")
        if resp.status_code == 200:
            dishes = resp.json()
        else:
            await get_effective_message(update).reply_text(f"Failed to fetch dishes: {resp.text}")
            from handlers import start
            await start(update, context)
            return ConversationHandler.END
    except Exception as e:
        await get_effective_message(update).reply_text(f"Error fetching dishes: {e}")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    if not dishes:
        await get_effective_message(update).reply_text("No dishes to add images to.")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    context.user_data['dishes'] = dishes
    chunk_size = 10
    for i in range(0, len(dishes), chunk_size):
        chunk = dishes[i:i + chunk_size]
        msg = f"Which dish do you want to add an image to? (Part {i//chunk_size + 1})\nReply with the number.\n"
        for j, dish in enumerate(chunk):
            name = dish.get('titleKey') or dish.get('name')
            num_images = len(dish.get('images', []))
            msg += f"\n{i+j+1}. {name} ({num_images} images)"
        await get_effective_message(update).reply_text(msg)
    return ADD_DISH_IMAGE_CHOOSE

async def add_dish_image_choose(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    if not text.isdigit():
        await get_effective_message(update).reply_text("Please reply with a valid number.")
        return ADD_DISH_IMAGE_CHOOSE
    idx = int(text) - 1
    dishes = context.user_data.get('dishes', [])
    if idx < 0 or idx >= len(dishes):
        await get_effective_message(update).reply_text("Number out of range. Try again.")
        return ADD_DISH_IMAGE_CHOOSE
    context.user_data['selected_dish'] = dishes[idx]
    await get_effective_message(update).reply_text(
        "Please send a photo for the dish."
    )
    return ADD_DISH_IMAGE

async def add_dish_image_upload(update: Update, context: ContextTypes.DEFAULT_TYPE):
    dish = context.user_data.get('selected_dish')
    if not dish:
        await get_effective_message(update).reply_text("No dish selected. Please start again.")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    if update.message.photo:
        photo = update.message.photo[-1]
        file = await update.message.get_bot().get_file(photo.file_id)
        file_path = file.file_path
        if file_path.startswith('http'):
            image_url = file_path
        else:
            bot_token = context.bot.token
            image_url = f"https://api.telegram.org/file/bot{bot_token}/{file_path}"
        image_data = {
            'image_url': image_url,
            'secret': API_SECRET
        }
        resp = requests.post(f"{DISHES_URL}/{dish['id']}/images", json=image_data)
        if resp.status_code == 200:
            await get_effective_message(update).reply_text("Image added successfully!")
        else:
            await get_effective_message(update).reply_text(f"Failed to add image: {resp.text}")
    else:
        await get_effective_message(update).reply_text("Please send a photo (not a URL or text).")
        return ADD_DISH_IMAGE
    from handlers import start
    await start(update, context)
    return ConversationHandler.END

async def delete_dish_image_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        resp = requests.get(f"{DISHES_URL}/all")
        if resp.status_code == 200:
            dishes = resp.json()
        else:
            await get_effective_message(update).reply_text(f"Failed to fetch dishes: {resp.text}")
            from handlers import start
            await start(update, context)
            return ConversationHandler.END
    except Exception as e:
        await get_effective_message(update).reply_text(f"Error fetching dishes: {e}")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    if not dishes:
        await get_effective_message(update).reply_text("No dishes to delete images from.")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    context.user_data['dishes'] = dishes
    chunk_size = 10
    for i in range(0, len(dishes), chunk_size):
        chunk = dishes[i:i + chunk_size]
        msg = f"Which dish's image do you want to delete? (Part {i//chunk_size + 1})\nReply with the number.\n"
        for j, dish in enumerate(chunk):
            name = dish.get('titleKey') or dish.get('name')
            num_images = len(dish.get('images', []))
            if num_images > 0:
                msg += f"\n{i+j+1}. {name} ({num_images} images)"
        await get_effective_message(update).reply_text(msg)
    return DELETE_DISH_IMAGE_CHOOSE

async def delete_dish_image_choose(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    if not text.isdigit():
        await get_effective_message(update).reply_text("Please reply with a valid number.")
        return DELETE_DISH_IMAGE_CHOOSE
    idx = int(text) - 1
    dishes = context.user_data.get('dishes', [])
    if idx < 0 or idx >= len(dishes):
        await get_effective_message(update).reply_text("Number out of range. Try again.")
        return DELETE_DISH_IMAGE_CHOOSE
    dish = dishes[idx]
    if not dish.get('images'):
        await get_effective_message(update).reply_text("This dish has no images to delete.")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    context.user_data['selected_dish'] = dish
    msg = "Which image do you want to delete? Reply with the number.\n"
    for i, image in enumerate(dish['images']):
        msg += f"\n{i+1}. {image}"
    await get_effective_message(update).reply_text(msg)
    return DELETE_DISH_IMAGE_CONFIRM

async def delete_dish_image_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    if not text.isdigit():
        await get_effective_message(update).reply_text("Please reply with a valid number.")
        return DELETE_DISH_IMAGE_CONFIRM
    idx = int(text) - 1
    dish = context.user_data.get('selected_dish')
    if not dish or idx < 0 or idx >= len(dish['images']):
        await get_effective_message(update).reply_text("Invalid image selection.")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END
    image_filename = dish['images'][idx]
    try:
        response = requests.delete(
            f"{DISHES_URL}/{dish['id']}/images/{image_filename}",
            json={'secret': API_SECRET}
        )
        if response.ok:
            await get_effective_message(update).reply_text("✅ Image deleted successfully!")
        else:
            await get_effective_message(update).reply_text(f"Failed to delete image: {response.text}")
    except Exception as e:
        await get_effective_message(update).reply_text(f"Error deleting image: {e}")
    from handlers import start
    await start(update, context)
    return ConversationHandler.END

async def remove_dish_image(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.message.reply_text("[Placeholder] Remove dish image feature coming soon!")

async def list_dishes(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Handle both command and callback
    if update.callback_query:
        await update.callback_query.answer()
        message = update.callback_query.message
    else:
        message = update.message
    try:
        resp = requests.get(f"{DISHES_URL}/all")
        if resp.status_code == 200:
            dishes = resp.json()
        else:
            await message.reply_text(f"Failed to fetch dishes: {resp.text}")
            from handlers import start
            await start(update, context)
            return ConversationHandler.END
    except Exception as e:
        await message.reply_text(f"Error fetching dishes: {e}")
        from handlers import start
        await start(update, context)
        return ConversationHandler.END

    if not dishes:
        await message.reply_text("No dishes found.")
        return

    chunk_size = 5
    for i in range(0, len(dishes), chunk_size):
        chunk = dishes[i:i + chunk_size]
        msg = f"Dishes (Part {i//chunk_size + 1}):\n\n"
        for dish in chunk:
            status_stickers = []
            if not dish.get('visible', True):
                status_stickers.append("👁️ Hidden")
            if not dish.get('inStock', True):
                status_stickers.append("⏳ Not In Stock")
            elif dish.get('inStock', True):
                status_stickers.append("✅ In Stock")
            name = dish.get('titleKey') or dish.get('name')
            msg += f"<b>{name}</b>"
            if status_stickers:
                msg += f" {' '.join(status_stickers)}"
            msg += f"\nPrice: {dish.get('price', '?')} Lari\nDescription: {dish.get('description', '')}\nImages: {len(dish.get('images', []))} 📸\n\n"
        await message.reply_text(msg, parse_mode='HTML')
    # Send the /start message as a new message (never edit)
    from handlers import get_start_menu
    welcome_message, reply_markup = get_start_menu()
    await message.reply_text(welcome_message, reply_markup=reply_markup)


async def toggle_dish_visibility(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        resp = requests.get(f"{DISHES_URL}/all")
        if resp.status_code != 200:
            await get_effective_message(update).reply_text(f"Failed to fetch dishes: {resp.text}")
            from handlers import get_start_menu
            welcome_message, reply_markup = get_start_menu()
            await get_effective_message(update).reply_text(welcome_message, reply_markup=reply_markup)
            return ConversationHandler.END
        dishes = resp.json()
        if not dishes:
            await get_effective_message(update).reply_text("No dishes to toggle.")
            from handlers import get_start_menu
            welcome_message, reply_markup = get_start_menu()
            await get_effective_message(update).reply_text(welcome_message, reply_markup=reply_markup)
            return ConversationHandler.END
        context.user_data['dishes'] = dishes
        chunk_size = 10
        for i in range(0, len(dishes), chunk_size):
            chunk = dishes[i:i + chunk_size]
            msg = f"Which dish's visibility do you want to toggle? (Part {i//chunk_size + 1})\nReply with the number.\n"
            for j, dish in enumerate(chunk):
                status = "👁️ Hidden" if not dish.get('visible', True) else "👁️ Visible"
                name = dish.get('titleKey') or dish.get('name')
                msg += f"\n{i+j+1}. {name} - {status}"
            await get_effective_message(update).reply_text(msg)
        context.user_data['toggle_type'] = 'visibility'
        return 0  # Use a temporary state, will handle below
    except Exception as e:
        await get_effective_message(update).reply_text(f"Error fetching dishes: {e}")
        from handlers import get_start_menu
        welcome_message, reply_markup = get_start_menu()
        await get_effective_message(update).reply_text(welcome_message, reply_markup=reply_markup)
        return ConversationHandler.END

async def toggle_dish_visibility_choose(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    if not text.isdigit():
        await get_effective_message(update).reply_text("Please reply with a valid number.")
        return 0
    idx = int(text) - 1
    dishes = context.user_data.get('dishes', [])
    if idx < 0 or idx >= len(dishes):
        await get_effective_message(update).reply_text("Number out of range. Try again.")
        return 0
    dish = dishes[idx]
    current_visibility = dish.get('visible', True)
    await get_effective_message(update).reply_text("Processing visibility toggle...")
    try:
        resp = requests.post(
            f"{DISHES_URL}/{dish['id']}/toggle-visibility",
            json={'secret': API_SECRET}
        )
        if resp.status_code == 200:
            new_status = "hidden" if current_visibility else "visible"
            await get_effective_message(update).reply_text(f"Dish is now {new_status}!")
        else:
            await get_effective_message(update).reply_text(f"Failed to toggle visibility: {resp.text}")
    except Exception as e:
        await get_effective_message(update).reply_text(f"Error toggling visibility: {e}")
    from handlers import get_start_menu
    welcome_message, reply_markup = get_start_menu()
    await get_effective_message(update).reply_text(welcome_message, reply_markup=reply_markup)
    return ConversationHandler.END

async def toggle_dish_stock(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        resp = requests.get(f"{DISHES_URL}/all")
        if resp.status_code != 200:
            await get_effective_message(update).reply_text(f"Failed to fetch dishes: {resp.text}")
            from handlers import get_start_menu
            welcome_message, reply_markup = get_start_menu()
            await get_effective_message(update).reply_text(welcome_message, reply_markup=reply_markup)
            return ConversationHandler.END
        dishes = resp.json()
        if not dishes:
            await get_effective_message(update).reply_text("No dishes to toggle.")
            from handlers import get_start_menu
            welcome_message, reply_markup = get_start_menu()
            await get_effective_message(update).reply_text(welcome_message, reply_markup=reply_markup)
            return ConversationHandler.END
        context.user_data['dishes'] = dishes
        chunk_size = 10
        for i in range(0, len(dishes), chunk_size):
            chunk = dishes[i:i + chunk_size]
            msg = f"Which dish's stock do you want to toggle? (Part {i//chunk_size + 1})\nReply with the number.\n"
            for j, dish in enumerate(chunk):
                status = "⏳ Not In Stock" if not dish.get('inStock', True) else "✅ In Stock"
                name = dish.get('titleKey') or dish.get('name')
                msg += f"\n{i+j+1}. {name} - {status}"
            await get_effective_message(update).reply_text(msg)
        context.user_data['toggle_type'] = 'stock'
        return 1  # Use a temporary state, will handle below
    except Exception as e:
        await get_effective_message(update).reply_text(f"Error fetching dishes: {e}")
        from handlers import get_start_menu
        welcome_message, reply_markup = get_start_menu()
        await get_effective_message(update).reply_text(welcome_message, reply_markup=reply_markup)
        return ConversationHandler.END

async def toggle_dish_stock_choose(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    if not text.isdigit():
        await get_effective_message(update).reply_text("Please reply with a valid number.")
        return 1
    idx = int(text) - 1
    dishes = context.user_data.get('dishes', [])
    if idx < 0 or idx >= len(dishes):
        await get_effective_message(update).reply_text("Number out of range. Try again.")
        return 1
    dish = dishes[idx]
    current_stock = dish.get('inStock', True)
    await get_effective_message(update).reply_text("Processing stock toggle...")
    try:
        resp = requests.post(
            f"{DISHES_URL}/{dish['id']}/toggle-stock",
            json={'secret': API_SECRET}
        )
        if resp.status_code == 200:
            new_status = "not in stock" if current_stock else "in stock"
            await get_effective_message(update).reply_text(f"Dish is now {new_status}!")
        else:
            await get_effective_message(update).reply_text(f"Failed to toggle stock: {resp.text}")
    except Exception as e:
        await get_effective_message(update).reply_text(f"Error toggling stock: {e}")
    from handlers import get_start_menu
    welcome_message, reply_markup = get_start_menu()
    await get_effective_message(update).reply_text(welcome_message, reply_markup=reply_markup)
    return ConversationHandler.END

__all__ = [
    'dishes',
    'add_dish_start', 'add_dish_name', 'add_dish_desc', 'add_dish_price', 'add_dish_image',
    'edit_dish_start', 'edit_dish_choose', 'edit_dish_field', 'edit_dish_value',
    'delete_dish_start', 'delete_dish_choose', 'delete_dish_confirm',
    'add_dish_image_start', 'add_dish_image_choose', 'add_dish_image_upload',
    'delete_dish_image_start', 'delete_dish_image_choose', 'delete_dish_image_confirm',
    'list_dishes',
    'toggle_dish_visibility', 'toggle_dish_visibility_choose',
    'toggle_dish_stock', 'toggle_dish_stock_choose',
]

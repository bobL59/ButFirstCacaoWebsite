import requests
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.constants import ParseMode
from telegram.ext import ContextTypes, ConversationHandler
from common import get_go_back_button, go_back_handler, get_env_vars, get_start_menu
from constants import (
    ADD_MENU_CATEGORY, ADD_MENU_LANGUAGES, ADD_MENU_FILE,
    DELETE_MENU_CHOOSE, DELETE_MENU_CONFIRM,
    SUPPORTED_LANGUAGES
)

# Get environment variables
env = get_env_vars()
API_SECRET = env['API_SECRET']
SETTINGS_URL = env['SETTINGS_URL']
MENU_URL = env['MENU_URL']

# Helper to generate the menu message
MENU_MESSAGE = (
    "🍽️ <b>Menu</b>\n"
    "Select an action below:"
)

# Inline keyboard for menu actions
MENU_KEYBOARD = [
    [InlineKeyboardButton("Add a new menu", callback_data="addmenu")],
    [InlineKeyboardButton("View all menus", callback_data="listmenus")],
    [InlineKeyboardButton("Remove a menu", callback_data="deletemenu")],
    [InlineKeyboardButton("Check special menu status", callback_data="checkmenu")],
    [InlineKeyboardButton("Toggle special menu visibility", callback_data="togglemenu")],
    get_go_back_button(),
]
MENU_REPLY_MARKUP = InlineKeyboardMarkup(MENU_KEYBOARD)

MENU_CATEGORIES = [
    ("Special Menu", "special"),
    ("Hot Drinks", "hot_drinks"),
    ("Cold Drinks", "cold_drinks"),
    ("Food", "food"),
]

CATEGORY_KEYBOARD = InlineKeyboardMarkup([
    [InlineKeyboardButton(name, callback_data=f"menu_category_{cb}")] for name, cb in MENU_CATEGORIES
])

# Helper to build the language selection keyboard
def build_language_keyboard(selected=None):
    if selected is None:
        selected = []
    keyboard = []
    for code, name in SUPPORTED_LANGUAGES.items():
        label = f"{'✅ ' if code in selected else ''}{name} ({code})"
        keyboard.append([InlineKeyboardButton(label, callback_data=f"menu_lang_{code}")])
    keyboard.append([InlineKeyboardButton("Done", callback_data="menu_lang_done")])
    return InlineKeyboardMarkup(keyboard)

async def menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Handles both command and callback
    if update.message:
        await update.message.reply_text(
            MENU_MESSAGE,
            parse_mode=ParseMode.HTML,
            reply_markup=MENU_REPLY_MARKUP
        )
    elif update.callback_query:
        query = update.callback_query
        await query.answer()
        if query.data == "go_back":
            await go_back_handler(update, context)
            return
        elif query.data == "addmenu":
            await add_menu_start(update, context)
            return ADD_MENU_CATEGORY
        elif query.data == "listmenus":
            await list_menus(update, context)
        elif query.data == "deletemenu":
            await delete_menu_start(update, context)
            return DELETE_MENU_CHOOSE
        elif query.data == "checkmenu":
            await check_menu_status(update, context)
        elif query.data == "togglemenu":
            await toggle_menu(update, context)
        else:
            await query.edit_message_text(
                MENU_MESSAGE,
                parse_mode=ParseMode.HTML,
                reply_markup=MENU_REPLY_MARKUP
            )

async def check_menu_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        resp = requests.get(SETTINGS_URL)
        if resp.status_code == 200:
            settings = resp.json()
            status = "enabled" if settings.get('specialMenuEnabled', True) else "disabled"
            await update.callback_query.edit_message_text(f"Special Menu is currently {status}.")
        else:
            await update.callback_query.edit_message_text(f"Failed to fetch special menu status: {resp.text}")
    except Exception as e:
        await update.callback_query.edit_message_text(f"Error checking special menu status: {e}")
    # Always send the main menu at the end
    welcome_message, reply_markup = get_start_menu()
    await update.callback_query.message.reply_text(welcome_message, reply_markup=reply_markup)

async def toggle_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        # Toggle the menu status
        resp = requests.post(
            f"{SETTINGS_URL}/special-menu",
            json={
                'secret': API_SECRET
            }
        )
        
        if resp.status_code == 200:
            result = resp.json()
            await update.callback_query.edit_message_text(result['message'].replace('menu', 'special menu'))
        else:
            await update.callback_query.edit_message_text(f"Failed to toggle special menu status: {resp.text}")
    except Exception as e:
        await update.callback_query.edit_message_text(f"Error toggling special menu status: {e}")
    # Always send the main menu at the end
    welcome_message, reply_markup = get_start_menu()
    await update.callback_query.message.reply_text(welcome_message, reply_markup=reply_markup)

async def add_menu_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.edit_message_text(
        "Please choose the menu category:",
        reply_markup=CATEGORY_KEYBOARD
    )
    return ADD_MENU_CATEGORY

async def add_menu_category(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Now expects a callback query, not a text message
    query = update.callback_query
    await query.answer()
    if not query.data.startswith("menu_category_"):
        await query.edit_message_text(
            "Invalid selection. Please choose a category:",
            reply_markup=CATEGORY_KEYBOARD
        )
        return ADD_MENU_CATEGORY
    category = query.data.replace("menu_category_", "")
    valid_categories = [cb for _, cb in MENU_CATEGORIES]
    if category not in valid_categories:
        await query.edit_message_text(
            "Invalid category. Please choose:",
            reply_markup=CATEGORY_KEYBOARD
        )
        return ADD_MENU_CATEGORY
    context.user_data['menu_category'] = category
    # Start language selection with no languages selected
    context.user_data['menu_languages'] = []
    await query.edit_message_text(
        "Please select the languages for this menu. You can select multiple. Press 'Done' when finished:",
        reply_markup=build_language_keyboard([])
    )
    return ADD_MENU_LANGUAGES

async def add_menu_languages(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    selected = context.user_data.get('menu_languages', [])
    if query.data == 'menu_lang_done':
        if not selected:
            await query.edit_message_text(
                "Please select at least one language:",
                reply_markup=build_language_keyboard(selected)
            )
            return ADD_MENU_LANGUAGES
        await query.edit_message_text(
            "Please send the PDF file for the menu.\nNote: The file will be automatically renamed based on the category and language."
        )
        return ADD_MENU_FILE
    elif query.data.startswith('menu_lang_'):
        lang = query.data.replace('menu_lang_', '')
        if lang in SUPPORTED_LANGUAGES:
            if lang in selected:
                selected.remove(lang)
            else:
                selected.append(lang)
            context.user_data['menu_languages'] = selected
        await query.edit_message_text(
            "Please select the languages for this menu. You can select multiple. Press 'Done' when finished:",
            reply_markup=build_language_keyboard(selected)
        )
        return ADD_MENU_LANGUAGES
    else:
        await query.edit_message_text(
            "Invalid selection. Please select languages:",
            reply_markup=build_language_keyboard(selected)
        )
        return ADD_MENU_LANGUAGES

async def add_menu_file(update: Update, context: ContextTypes.DEFAULT_TYPE):
    file_url = None
    file_id = None

    if update.message.document and update.message.document.mime_type == 'application/pdf':
        file_id = update.message.document.file_id
        file = await update.message.get_bot().get_file(file_id)
        file_url = file.file_path
    elif update.message.text and update.message.text.startswith('http'):
        file_url = update.message.text
    else:
        await update.message.reply_text(
            "Please send a PDF file or a valid URL to a PDF file."
        )
        return ADD_MENU_FILE

    try:
        # Send the file to the API
        resp = requests.post(
            MENU_URL,
            json={
                'category': context.user_data['menu_category'],
                'languages': context.user_data['menu_languages'],
                'file_url': file_url,
                'secret': API_SECRET
            }
        )
        
        if resp.status_code == 200:
            await update.message.reply_text(
                "Menu file(s) added successfully!\n\n"
                f"Category: {context.user_data['menu_category']}\n"
                f"Languages: {', '.join(context.user_data['menu_languages'])}"
            )
        else:
            await update.message.reply_text(f"Failed to add menu file(s): {resp.text}")
    except Exception as e:
        await update.message.reply_text(f"Error adding menu file(s): {e}")
    # Always send the main menu at the end
    welcome_message, reply_markup = get_start_menu()
    await update.message.reply_text(welcome_message, reply_markup=reply_markup)
    return ConversationHandler.END

async def list_menus(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        resp = requests.get(MENU_URL)
        if resp.status_code == 200:
            menu_files = resp.json()
            # Only keep languages with at least one menu file
            non_empty_languages = {lang: cats for lang, cats in menu_files.items() if cats}
            if not non_empty_languages:
                await update.callback_query.edit_message_text("No menu files found.")
                # Send /start message after listing
                welcome_message, reply_markup = get_start_menu()
                await update.callback_query.message.reply_text(welcome_message, reply_markup=reply_markup)
                return
            
            languages = list(non_empty_languages.keys())
            chunk_size = 3  # Number of languages per message
            for i in range(0, len(languages), chunk_size):
                chunk = languages[i:i + chunk_size]
                msg = f"Available Menu Files (Part {i//chunk_size + 1}):\n\n"
                for lang in chunk:
                    msg += f"Language: {lang}\n"
                    for category in non_empty_languages[lang]:
                        msg += f"• {category}\n"
                    msg += "\n"
                if i == 0:
                    await update.callback_query.edit_message_text(msg)
                else:
                    await update.callback_query.message.reply_text(msg)
            # After listing, send /start message
            welcome_message, reply_markup = get_start_menu()
            await update.callback_query.message.reply_text(welcome_message, reply_markup=reply_markup)
        else:
            await update.callback_query.edit_message_text(f"Failed to fetch menu files: {resp.text}")
            # After listing, send /start message
            welcome_message, reply_markup = get_start_menu()
            await update.callback_query.message.reply_text(welcome_message, reply_markup=reply_markup)
    except Exception as e:
        await update.callback_query.edit_message_text(f"Error fetching menu files: {e}")
        # After listing, send /start message
        welcome_message, reply_markup = get_start_menu()
        await update.callback_query.message.reply_text(welcome_message, reply_markup=reply_markup)

async def delete_menu_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        resp = requests.get(MENU_URL)
        if resp.status_code == 200:
            menu_files = resp.json()
            if not menu_files:
                await update.callback_query.edit_message_text("No menu files to delete.")
                return ConversationHandler.END
            
            # Helper to get friendly name for category key
            def get_category_friendly_name(key):
                for name, k in MENU_CATEGORIES:
                    if k == key:
                        return name
                return key
            
            # Get all available menu files with their languages
            menu_items = []
            for lang, categories in menu_files.items():
                for category in categories:
                    menu_items.append((category, lang))  # category is the key, e.g., 'cold_drinks'
            
            context.user_data['menu_items'] = menu_items
            
            # Split menu items into chunks
            chunk_size = 10  # Number of items per message
            for i in range(0, len(menu_items), chunk_size):
                chunk = menu_items[i:i + chunk_size]
                msg = f"Which menu do you want to delete? (Part {i//chunk_size + 1})\nReply with the number.\n"
                for j, (category, lang) in enumerate(chunk):
                    friendly = get_category_friendly_name(category)
                    msg += f"\n{i+j+1}. {friendly} [{category}] ({SUPPORTED_LANGUAGES[lang]})"
                if i == 0:
                    await update.callback_query.edit_message_text(msg)
                else:
                    await update.callback_query.message.reply_text(msg)
            return DELETE_MENU_CHOOSE
        else:
            await update.callback_query.edit_message_text(f"Failed to fetch menu files: {resp.text}")
            return ConversationHandler.END
    except Exception as e:
        await update.callback_query.edit_message_text(f"Error fetching menu files: {e}")
        return ConversationHandler.END

async def delete_menu_choose(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    if not text.isdigit():
        await update.message.reply_text("Please reply with a valid number.")
        return DELETE_MENU_CHOOSE
    
    idx = int(text) - 1
    menu_items = context.user_data.get('menu_items', [])
    if idx < 0 or idx >= len(menu_items):
        await update.message.reply_text("Number out of range. Try again.")
        return DELETE_MENU_CHOOSE
    
    category, lang = menu_items[idx]
    context.user_data['delete_menu_category'] = category
    context.user_data['delete_menu_language'] = lang
    msg = f"Are you sure you want to delete the {category} menu in {SUPPORTED_LANGUAGES[lang]}? Reply YES to confirm, or /cancel."
    await update.message.reply_text(msg)
    return DELETE_MENU_CONFIRM

async def delete_menu_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message.text.strip().upper() != 'YES':
        await update.message.reply_text("Deletion cancelled.")
        # Always send the main menu at the end
        welcome_message, reply_markup = get_start_menu()
        await update.message.reply_text(welcome_message, reply_markup=reply_markup)
        return ConversationHandler.END
    
    category = context.user_data.get('delete_menu_category')
    language = context.user_data.get('delete_menu_language')
    print(f"[DEBUG] Deleting menu: category={category}, language={language}")
    if not category or not language:
        await update.message.reply_text("No menu selected.")
        # Always send the main menu at the end
        welcome_message, reply_markup = get_start_menu()
        await update.message.reply_text(welcome_message, reply_markup=reply_markup)
        return ConversationHandler.END
    
    # Use category as-is (should match the filename exactly)
    try:
        resp = requests.delete(
            f"{MENU_URL}/{category}/{language}",
            json={'secret': API_SECRET}
        )
        
        if resp.status_code == 200:
            await update.message.reply_text(f"Menu file deleted successfully!")
        else:
            await update.message.reply_text(f"Failed to delete menu file: {resp.text}")
    except Exception as e:
        await update.message.reply_text(f"Error deleting menu file: {e}")
    # Always send the main menu at the end
    welcome_message, reply_markup = get_start_menu()
    await update.message.reply_text(welcome_message, reply_markup=reply_markup)
    return ConversationHandler.END

# Legacy function names for compatibility
def addmenu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    return add_menu_start(update, context)

def listmenus(update: Update, context: ContextTypes.DEFAULT_TYPE):
    return list_menus(update, context)

def deletemenu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    return delete_menu_start(update, context)

def checkmenu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    return check_menu_status(update, context)

def togglemenu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    return toggle_menu(update, context)

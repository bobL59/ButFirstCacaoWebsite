def run_bot():
    from common import suppress_ptb_warnings
    suppress_ptb_warnings()
    import asyncio
    from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ConversationHandler, MessageHandler, filters
    from handlers import start, cancel, desserts
    from common import get_env_vars, restricted_access
    from desserts import (
        desserts,
        list_desserts,
        add_desert_start, add_desert_name, add_desert_desc, add_desert_price, add_desert_image,
        edit_dessert_start, edit_dessert_choose, edit_dessert_field, edit_dessert_value,
        delete_dessert_start, delete_dessert_choose, delete_dessert_confirm,
        toggle_dessert_visibility_start, toggle_dessert_visibility_choose,
        toggle_dessert_availability_start, toggle_dessert_availability_choose,
        add_dessert_image_start, add_dessert_image_choose, add_dessert_image_upload,
        delete_dessert_image_start, delete_dessert_image_choose, delete_dessert_image_confirm
    )
    from events import (
        events, list_events, add_event_start, add_event_title, add_event_date, add_event_start_time, add_event_end_time, add_event_desc, add_event_image, add_event_visibility,
        delete_event_start, delete_event_choose, delete_event_confirm, delete_event_conv,
        done_adding_images, skip_start_time, skip_end_time, visibility_choice
    )
    from funfacts import funfacts, addfact, add_fact_title, add_fact_text, listfacts, deletefact, delete_fact_choose, delete_fact_confirm
    from menu import (
        menu, add_menu_start, add_menu_category, add_menu_languages, add_menu_file,
        delete_menu_start, delete_menu_choose, delete_menu_confirm
    )
    from drinks import (
        drinks,
        check_seasonal_status, toggle_summer_drinks, toggle_winter_drinks, list_drinks,
        add_drink_start, add_drink_name, add_drink_type, add_drink_desc, add_drink_category, add_drink_price, add_drink_image,
        edit_drink_start, edit_drink_choose, edit_drink_field, edit_drink_value,
        delete_drink_start, delete_drink_choose, delete_drink_confirm,
        toggle_drink_visibility_start, toggle_drink_visibility_choose,
        toggle_drink_stock_start, toggle_drink_stock_choose,
        add_drink_image_start, add_drink_image_choose,
        delete_drink_image_start, delete_drink_image_choose, delete_drink_image_confirm
    )
    from others import (others, listcategories, addcategory_start, addcategory_name, editcategory_start, 
        editcategory_choose, editcategory_name, deletecategory_start, deletecategory_choose, deletecategory_confirm, 
        hidecategory_start, hidecategory_choose, listproducts, hideproduct_start, hideproduct_choose, addproduct_start, 
        addproduct_name, addproduct_category, addproduct_flavour_name, addproduct_flavour_desc, addproduct_flavour_price, 
        addproduct_flavour_image, editproduct_start, editproduct_choose, editproduct_field, editproduct_value, 
        deleteproduct_start, addflavour_start, addflavour_choose_product, addflavour_name, addflavour_desc, addflavour_price, 
        addflavour_image, editflavour_start, deleteflavour_start, hideflavour_start, listflavours, editflavour_choose_flavour,
        editflavour_choose_product, editflavour_field, editflavour_value, deleteflavour_choose_flavour, deleteflavour_choose_product, 
        deleteflavour_confirm, hideflavour_choose_flavour, hideflavour_choose_product
    )
    from miscellaneous import (
        miscellaneous,
        add_bar_image_title, add_bar_image_url,
        list_bar_images,
        delete_bar_image_start, delete_bar_image_choose, delete_bar_image_confirm
    )
    from constants import (
        ADD_EVENT_TITLE, ADD_EVENT_DATE, ADD_EVENT_START_TIME, ADD_EVENT_END_TIME, ADD_EVENT_DESC, ADD_EVENT_IMAGE, ADD_EVENT_VISIBILITY,
        DELETE_EVENT_CHOOSE, DELETE_EVENT_CONFIRM,
        ADD_FACT_TITLE, ADD_FACT_TEXT, DELETE_FACT_CHOOSE, DELETE_FACT_CONFIRM,
        ADD_MENU_CATEGORY, ADD_MENU_LANGUAGES, ADD_MENU_FILE,
        DELETE_MENU_CHOOSE, DELETE_MENU_CONFIRM,
        ADD_DRINK_NAME, ADD_DRINK_TYPE, ADD_DRINK_DESC, ADD_DRINK_CATEGORY, ADD_DRINK_IMAGE,
        EDIT_DRINK_CHOOSE, EDIT_DRINK_FIELD, EDIT_DRINK_VALUE,
        DELETE_DRINK_CHOOSE, DELETE_DRINK_CONFIRM,
        TOGGLE_DRINK_VISIBILITY_CHOOSE, TOGGLE_DRINK_STOCK_CHOOSE,
        ADD_DRINK_IMAGE_CHOOSE, DELETE_DRINK_IMAGE_CHOOSE, DELETE_DRINK_IMAGE_CONFIRM,
        ADD_DESERT_NAME, ADD_DESERT_DESC, ADD_DESERT_PRICE, ADD_DESERT_IMAGE,
        EDIT_DESERT_CHOOSE, EDIT_DESERT_FIELD, EDIT_DESERT_VALUE,
        DELETE_DESERT_CHOOSE, DELETE_DESERT_CONFIRM,
        TOGGLE_DESERT_VISIBILITY_CHOOSE, TOGGLE_DESERT_AVAILABILITY_CHOOSE,
        ADD_DESERT_IMAGE_CHOOSE, DELETE_DESERT_IMAGE_CHOOSE, DELETE_DESERT_IMAGE_CONFIRM,
        ADD_DISH_NAME, ADD_DISH_DESC, ADD_DISH_PRICE, ADD_DISH_IMAGE,
        EDIT_DISH_CHOOSE, EDIT_DISH_FIELD, EDIT_DISH_VALUE,
        DELETE_DISH_CHOOSE, DELETE_DISH_CONFIRM,
        ADD_DISH_IMAGE_CHOOSE, DELETE_DISH_IMAGE_CHOOSE, DELETE_DISH_IMAGE_CONFIRM,
        ADD_BAR_IMAGE_TITLE, ADD_BAR_IMAGE_URL, DELETE_BAR_IMAGE_CHOOSE, DELETE_BAR_IMAGE_CONFIRM,
        ADD_CATEGORY_NAME, EDIT_CATEGORY_CHOOSE, EDIT_CATEGORY_NAME, DELETE_CATEGORY_CHOOSE, DELETE_CATEGORY_CONFIRM, 
        TOGGLE_CATEGORY_CHOOSE, TOGGLE_PRODUCT_CHOOSE, ADD_PRODUCT_NAME, ADD_PRODUCT_CATEGORY, ADD_PRODUCT_FLAVOUR_NAME, 
        ADD_PRODUCT_FLAVOUR_DESC, ADD_PRODUCT_FLAVOUR_PRICE, ADD_PRODUCT_FLAVOUR_IMAGE, EDIT_PRODUCT_CHOOSE, 
        EDIT_PRODUCT_FIELD, EDIT_PRODUCT_VALUE, ADD_FLAVOUR_CHOOSE_PRODUCT, ADD_FLAVOUR_NAME, ADD_FLAVOUR_DESC, 
        ADD_FLAVOUR_PRICE, ADD_FLAVOUR_IMAGE, EDIT_FLAVOUR_CHOOSE_FLAVOUR, EDIT_FLAVOUR_CHOOSE_PRODUCT, EDIT_FLAVOUR_FIELD,
        EDIT_FLAVOUR_VALUE, DELETE_FLAVOUR_CHOOSE_FLAVOUR, DELETE_FLAVOUR_CHOOSE_PRODUCT, TOGGLE_FLAVOUR_CHOOSE_FLAVOUR, 
        TOGGLE_FLAVOUR_CHOOSE_PRODUCT, ADD_DISCOUNT_TITLE, ADD_DISCOUNT_DESC, ADD_DISCOUNT_OCCURRENCE, ADD_DISCOUNT_IMAGES,
        DELETE_DISCOUNT_CHOOSE, DELETE_DISCOUNT_CONFIRM, TOGGLE_DISCOUNT_CHOOSE, ADD_DISCOUNT_IMAGE_UPLOAD, ADD_DISCOUNT_DONE_IMAGES,
        ADD_DRINK_PRICE
    )
    from dishes import (
        dishes,
        add_dish_start, add_dish_name, add_dish_desc, add_dish_price, add_dish_image,
        edit_dish_start, edit_dish_choose, edit_dish_field, edit_dish_value,
        delete_dish_start, delete_dish_choose, delete_dish_confirm,
        add_dish_image_start, add_dish_image_choose, add_dish_image_upload,
        delete_dish_image_start, delete_dish_image_choose, delete_dish_image_confirm,
        list_dishes,
        toggle_dish_visibility, toggle_dish_visibility_choose,
        toggle_dish_stock, toggle_dish_stock_choose
    )
    from discounts import (
        discounts,
        add_discount_start, add_discount_title, add_discount_desc, add_discount_occurrence,
        add_discount_image_upload, add_discount_done_images,
        list_discounts,
        delete_discount_start, delete_discount_choose, delete_discount_confirm,
        toggle_discount_visibility, toggle_discount_choose
    )

    env = get_env_vars()
    application = Application.builder().token(env['TELEGRAM_TOKEN']).build()

    # Decorate handlers with restricted_access
    start = restricted_access(start)

    # Conversation handler for adding events
    add_event_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(add_event_start, pattern=r'^addevent$')],
        states={
            ADD_EVENT_TITLE: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_event_title)],
            ADD_EVENT_DATE: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_event_date)],
            ADD_EVENT_START_TIME: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, add_event_start_time),
                CallbackQueryHandler(skip_start_time, pattern=r'^skip_time$'),
            ],
            ADD_EVENT_END_TIME: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, add_event_end_time),
                CallbackQueryHandler(skip_end_time, pattern=r'^skip_time$'),
            ],
            ADD_EVENT_DESC: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_event_desc)],
            ADD_EVENT_IMAGE: [
                MessageHandler((filters.PHOTO | (filters.TEXT & ~filters.COMMAND)), add_event_image),
                CallbackQueryHandler(done_adding_images, pattern=r'^done_adding_images$'),
            ],
            ADD_EVENT_VISIBILITY: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, add_event_visibility),
                CallbackQueryHandler(visibility_choice, pattern=r'^visibility_'),
            ],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )

    # Conversation handler for deleting events is now imported from events.py
    
    # Conversation handler for adding fun facts
    add_fact_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(addfact, pattern=r'^addfact$')],
        states={
            ADD_FACT_TITLE: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_fact_title)],
            ADD_FACT_TEXT: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_fact_text)],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )

    # Conversation handler for deleting fun facts
    delete_fact_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(deletefact, pattern=r'^deletefact$')],
        states={
            DELETE_FACT_CHOOSE: [MessageHandler(filters.TEXT & ~filters.COMMAND, delete_fact_choose)],
            DELETE_FACT_CONFIRM: [MessageHandler(filters.TEXT & ~filters.COMMAND, delete_fact_confirm)],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )

    # Conversation handler for adding menus
    add_menu_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(add_menu_start, pattern=r'^addmenu$')],
        states={
            ADD_MENU_CATEGORY: [CallbackQueryHandler(add_menu_category, pattern=r'^menu_category_')],
            ADD_MENU_LANGUAGES: [CallbackQueryHandler(add_menu_languages, pattern=r'^menu_lang_.*|menu_lang_done$')],
            ADD_MENU_FILE: [
                MessageHandler((filters.Document.ALL | (filters.TEXT & ~filters.COMMAND)), add_menu_file),
            ],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )

    # Conversation handler for deleting menus
    delete_menu_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(delete_menu_start, pattern=r'^deletemenu$')],
        states={
            DELETE_MENU_CHOOSE: [MessageHandler(filters.TEXT & ~filters.COMMAND, delete_menu_choose)],
            DELETE_MENU_CONFIRM: [MessageHandler(filters.TEXT & ~filters.COMMAND, delete_menu_confirm)],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )

    # Conversation handler for adding drinks
    add_drink_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(add_drink_start, pattern=r'^adddrink$')],
        states={
            ADD_DRINK_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_drink_name)],
            ADD_DRINK_TYPE: [CallbackQueryHandler(add_drink_type, pattern=r'^drinktype_')],
            ADD_DRINK_DESC: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_drink_desc)],
            ADD_DRINK_CATEGORY: [CallbackQueryHandler(add_drink_category, pattern=r'^drinkcat_')],
            ADD_DRINK_PRICE: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_drink_price)],
            ADD_DRINK_IMAGE: [MessageHandler((filters.PHOTO | (filters.TEXT & ~filters.COMMAND)), add_drink_image)],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )

    # Conversation handler for editing drinks
    edit_drink_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(edit_drink_start, pattern=r'^editdrink$')],
        states={
            EDIT_DRINK_CHOOSE: [MessageHandler(filters.TEXT & ~filters.COMMAND, edit_drink_choose)],
            EDIT_DRINK_FIELD: [CallbackQueryHandler(edit_drink_field, pattern=r'^editfield_')],
            EDIT_DRINK_VALUE: [
                CallbackQueryHandler(edit_drink_value, pattern=r'^drinktype_|^drinkcat_'),
                MessageHandler(filters.TEXT & ~filters.COMMAND, edit_drink_value),
            ],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )

    # Conversation handler for deleting drinks
    delete_drink_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(delete_drink_start, pattern=r'^deletedrink$')],
        states={
            DELETE_DRINK_CHOOSE: [MessageHandler(filters.TEXT & ~filters.COMMAND, delete_drink_choose)],
            DELETE_DRINK_CONFIRM: [MessageHandler(filters.TEXT & ~filters.COMMAND, delete_drink_confirm)],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )

    # Conversation handler for toggling drink visibility
    toggle_drink_visibility_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(toggle_drink_visibility_start, pattern=r'^toggledrink$')],
        states={
            TOGGLE_DRINK_VISIBILITY_CHOOSE: [MessageHandler(filters.TEXT & ~filters.COMMAND, toggle_drink_visibility_choose)],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )

    # Conversation handler for toggling drink stock
    toggle_drink_stock_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(toggle_drink_stock_start, pattern=r'^togglestock$')],
        states={
            TOGGLE_DRINK_STOCK_CHOOSE: [MessageHandler(filters.TEXT & ~filters.COMMAND, toggle_drink_stock_choose)],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )

    # Conversation handler for adding drink images
    add_drink_image_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(add_drink_image_start, pattern=r'^adddrinkimage$')],
        states={
            ADD_DRINK_IMAGE_CHOOSE: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_drink_image_choose)],
            ADD_DRINK_IMAGE: [MessageHandler((filters.PHOTO | (filters.TEXT & ~filters.COMMAND)), add_drink_image)],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )

    # Conversation handler for deleting drink images
    delete_drink_image_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(delete_drink_image_start, pattern=r'^deletedrinkimage$')],
        states={
            DELETE_DRINK_IMAGE_CHOOSE: [MessageHandler(filters.TEXT & ~filters.COMMAND, delete_drink_image_choose)],
            DELETE_DRINK_IMAGE_CONFIRM: [MessageHandler(filters.TEXT & ~filters.COMMAND, delete_drink_image_confirm)],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )

    # --- DESSERTS Conversation Handlers ---
    add_desert_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(add_desert_start, pattern=r'^adddesert$')],
        states={
            ADD_DESERT_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_desert_name)],
            ADD_DESERT_DESC: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_desert_desc)],
            ADD_DESERT_PRICE: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_desert_price)],
            ADD_DESERT_IMAGE: [MessageHandler((filters.PHOTO | (filters.TEXT & ~filters.COMMAND)), add_desert_image)],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )

    edit_dessert_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(edit_dessert_start, pattern=r'^editdesert$')],
        states={
            EDIT_DESERT_CHOOSE: [MessageHandler(filters.TEXT & ~filters.COMMAND, edit_dessert_choose)],
            EDIT_DESERT_FIELD: [MessageHandler(filters.TEXT & ~filters.COMMAND, edit_dessert_field)],
            EDIT_DESERT_VALUE: [MessageHandler(filters.TEXT & ~filters.COMMAND, edit_dessert_value)],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )

    delete_dessert_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(delete_dessert_start, pattern=r'^deletedessert$')],
        states={
            DELETE_DESERT_CHOOSE: [MessageHandler(filters.TEXT & ~filters.COMMAND, delete_dessert_choose)],
            DELETE_DESERT_CONFIRM: [MessageHandler(filters.TEXT & ~filters.COMMAND, delete_dessert_confirm)],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )

    toggle_dessert_visibility_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(toggle_dessert_visibility_start, pattern=r'^toggledessert$')],
        states={
            TOGGLE_DESERT_VISIBILITY_CHOOSE: [MessageHandler(filters.TEXT & ~filters.COMMAND, toggle_dessert_visibility_choose)],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )

    toggle_dessert_availability_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(toggle_dessert_availability_start, pattern=r'^toggleavailability$')],
        states={
            TOGGLE_DESERT_AVAILABILITY_CHOOSE: [MessageHandler(filters.TEXT & ~filters.COMMAND, toggle_dessert_availability_choose)],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )

    add_dessert_image_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(add_dessert_image_start, pattern=r'^adddessertimage$')],
        states={
            ADD_DESERT_IMAGE_CHOOSE: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_dessert_image_choose)],
            ADD_DESERT_IMAGE: [MessageHandler((filters.PHOTO | (filters.TEXT & ~filters.COMMAND)), add_dessert_image_upload)],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )

    delete_dessert_image_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(delete_dessert_image_start, pattern=r'^deletedessertimage$')],
        states={
            DELETE_DESERT_IMAGE_CHOOSE: [MessageHandler(filters.TEXT & ~filters.COMMAND, delete_dessert_image_choose)],
            DELETE_DESERT_IMAGE_CONFIRM: [MessageHandler(filters.TEXT & ~filters.COMMAND, delete_dessert_image_confirm)],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )

    # --- DISHES Conversation Handler ---
    add_dish_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(add_dish_start, pattern=r'^adddish$')],
        states={
            ADD_DISH_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_dish_name)],
            ADD_DISH_DESC: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_dish_desc)],
            ADD_DISH_PRICE: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_dish_price)],
            ADD_DISH_IMAGE: [MessageHandler((filters.PHOTO | (filters.TEXT & ~filters.COMMAND)), add_dish_image)],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )

    edit_dish_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(edit_dish_start, pattern=r'^editdish$')],
        states={
            EDIT_DISH_CHOOSE: [MessageHandler(filters.TEXT & ~filters.COMMAND, edit_dish_choose)],
            EDIT_DISH_FIELD: [CallbackQueryHandler(edit_dish_field, pattern=r'^editfield_')],
            EDIT_DISH_VALUE: [MessageHandler(filters.TEXT & ~filters.COMMAND, edit_dish_value)],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )

    delete_dish_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(delete_dish_start, pattern=r'^removedish$')],
        states={
            DELETE_DISH_CHOOSE: [MessageHandler(filters.TEXT & ~filters.COMMAND, delete_dish_choose)],
            DELETE_DISH_CONFIRM: [MessageHandler(filters.TEXT & ~filters.COMMAND, delete_dish_confirm)],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )

    add_dish_image_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(add_dish_image_start, pattern=r'^adddishimage$')],
        states={
            ADD_DISH_IMAGE_CHOOSE: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_dish_image_choose)],
            ADD_DISH_IMAGE: [MessageHandler((filters.PHOTO | (filters.TEXT & ~filters.COMMAND)), add_dish_image_upload)],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )

    delete_dish_image_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(delete_dish_image_start, pattern=r'^removedishimage$')],
        states={
            DELETE_DISH_IMAGE_CHOOSE: [MessageHandler(filters.TEXT & ~filters.COMMAND, delete_dish_image_choose)],
            DELETE_DISH_IMAGE_CONFIRM: [MessageHandler(filters.TEXT & ~filters.COMMAND, delete_dish_image_confirm)],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )

    toggle_dish_visibility_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(toggle_dish_visibility, pattern=r'^toggledishvisibility$')],
        states={
            0: [MessageHandler(filters.TEXT & ~filters.COMMAND, toggle_dish_visibility_choose)],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )

    toggle_dish_stock_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(toggle_dish_stock, pattern=r'^toggledishstorage$')],
        states={
            1: [MessageHandler(filters.TEXT & ~filters.COMMAND, toggle_dish_stock_choose)],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )

    # --- DISCOUNTS Conversation Handlers ---
    add_discount_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(add_discount_start, pattern=r'^adddiscount$')],
        states={
            ADD_DISCOUNT_TITLE: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_discount_title)],
            ADD_DISCOUNT_DESC: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_discount_desc)],
            ADD_DISCOUNT_OCCURRENCE: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_discount_occurrence)],
            ADD_DISCOUNT_IMAGE_UPLOAD: [MessageHandler(filters.PHOTO, add_discount_image_upload), CallbackQueryHandler(add_discount_done_images, pattern=r'^done_adding_discount_images$')],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )

    delete_discount_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(delete_discount_start, pattern=r'^deletediscount$')],
        states={
            DELETE_DISCOUNT_CHOOSE: [MessageHandler(filters.TEXT & ~filters.COMMAND, delete_discount_choose)],
            DELETE_DISCOUNT_CONFIRM: [MessageHandler(filters.TEXT & ~filters.COMMAND, delete_discount_confirm)],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )

    toggle_discount_visibility_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(toggle_discount_visibility, pattern=r'^togglediscount$')],
        states={
            TOGGLE_DISCOUNT_CHOOSE: [MessageHandler(filters.TEXT & ~filters.COMMAND, toggle_discount_choose)],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )

    # --- MISCELLANEOUS Bar Image Conversation Handlers ---
    add_bar_image_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(miscellaneous, pattern=r'^add_bar_image$')],
        states={
            ADD_BAR_IMAGE_TITLE: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_bar_image_title)],
            ADD_BAR_IMAGE_URL: [MessageHandler(filters.PHOTO | filters.Document.IMAGE, add_bar_image_url)],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )

    delete_bar_image_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(miscellaneous, pattern=r'^delete_bar_image$')],
        states={
            DELETE_BAR_IMAGE_CHOOSE: [MessageHandler(filters.TEXT & ~filters.COMMAND, delete_bar_image_choose)],
            DELETE_BAR_IMAGE_CONFIRM: [MessageHandler(filters.TEXT & ~filters.COMMAND, delete_bar_image_confirm)],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )

    add_category_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(addcategory_start, pattern=r'^addcategory$')],
        states={
            ADD_CATEGORY_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, addcategory_name)],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )

    edit_category_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(editcategory_start, pattern=r'^editcategory$')],
        states={
            EDIT_CATEGORY_CHOOSE: [MessageHandler(filters.TEXT & ~filters.COMMAND, editcategory_choose)],
            EDIT_CATEGORY_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, editcategory_name)],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )
    delete_category_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(deletecategory_start, pattern=r'^deletecategory$')],
        states={
            DELETE_CATEGORY_CHOOSE: [MessageHandler(filters.TEXT & ~filters.COMMAND, deletecategory_choose)],
            DELETE_CATEGORY_CONFIRM: [MessageHandler(filters.TEXT & ~filters.COMMAND, deletecategory_confirm)],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )

    hide_category_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(hidecategory_start, pattern=r'^hidecategory$')],
        states={
            TOGGLE_CATEGORY_CHOOSE: [MessageHandler(filters.TEXT & ~filters.COMMAND, hidecategory_choose)],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )

    hide_product_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(hideproduct_start, pattern=r'^hideproduct$')],
        states={
            TOGGLE_PRODUCT_CHOOSE: [MessageHandler(filters.TEXT & ~filters.COMMAND, hideproduct_choose)],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )

    add_product_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(addproduct_start, pattern=r'^addproduct$')],
        states={
            ADD_PRODUCT_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, addproduct_name)],
            ADD_PRODUCT_CATEGORY: [MessageHandler(filters.TEXT & ~filters.COMMAND, addproduct_category)],
            ADD_PRODUCT_FLAVOUR_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, addproduct_flavour_name)],
            ADD_PRODUCT_FLAVOUR_DESC: [MessageHandler(filters.TEXT & ~filters.COMMAND, addproduct_flavour_desc)],
            ADD_PRODUCT_FLAVOUR_PRICE: [MessageHandler(filters.TEXT & ~filters.COMMAND, addproduct_flavour_price)],
            ADD_PRODUCT_FLAVOUR_IMAGE: [MessageHandler((filters.PHOTO | (filters.TEXT & ~filters.COMMAND)), addproduct_flavour_image)],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )

    edit_product_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(editproduct_start, pattern=r'^editproduct$')],
        states={
            EDIT_PRODUCT_CHOOSE: [MessageHandler(filters.TEXT & ~filters.COMMAND, editproduct_choose)],
            EDIT_PRODUCT_FIELD: [CallbackQueryHandler(editproduct_field, pattern=r'^editfield_')],
            EDIT_PRODUCT_VALUE: [MessageHandler(filters.TEXT & ~filters.COMMAND, editproduct_value)],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )

    add_flavour_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(addflavour_start, pattern=r'^addflavour$')],
        states={
            ADD_FLAVOUR_CHOOSE_PRODUCT: [MessageHandler(filters.TEXT & ~filters.COMMAND, addflavour_choose_product)],
            ADD_FLAVOUR_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, addflavour_name)],
            ADD_FLAVOUR_DESC: [MessageHandler(filters.TEXT & ~filters.COMMAND, addflavour_desc)],
            ADD_FLAVOUR_PRICE: [MessageHandler(filters.TEXT & ~filters.COMMAND, addflavour_price)],
            ADD_FLAVOUR_IMAGE: [MessageHandler((filters.PHOTO | (filters.TEXT & ~filters.COMMAND)), addflavour_image)],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )
    edit_flavour_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(editflavour_start, pattern=r'^editflavour$')],
        states={
            EDIT_FLAVOUR_CHOOSE_PRODUCT: [MessageHandler(filters.TEXT & ~filters.COMMAND, editflavour_choose_product)],
            EDIT_FLAVOUR_CHOOSE_FLAVOUR: [MessageHandler(filters.TEXT & ~filters.COMMAND, editflavour_choose_flavour)],
            EDIT_FLAVOUR_FIELD: [CallbackQueryHandler(editflavour_field, pattern=r'^editflavourfield_')],
            EDIT_FLAVOUR_VALUE: [MessageHandler((filters.PHOTO | (filters.TEXT & ~filters.COMMAND)), editflavour_value)],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )
    delete_flavour_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(deleteflavour_start, pattern=r'^deleteflavour$')],
        states={
            DELETE_FLAVOUR_CHOOSE_PRODUCT: [MessageHandler(filters.TEXT & ~filters.COMMAND, deleteflavour_choose_product)],
            DELETE_FLAVOUR_CHOOSE_FLAVOUR: [MessageHandler(filters.TEXT & ~filters.COMMAND, deleteflavour_choose_flavour)],
            DELETE_FLAVOUR_CHOOSE_FLAVOUR + 1: [MessageHandler(filters.TEXT & ~filters.COMMAND, deleteflavour_confirm)],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )
    hide_flavour_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(hideflavour_start, pattern=r'^hideflavour$')],
        states={
            TOGGLE_FLAVOUR_CHOOSE_PRODUCT: [MessageHandler(filters.TEXT & ~filters.COMMAND, hideflavour_choose_product)],
            TOGGLE_FLAVOUR_CHOOSE_FLAVOUR: [MessageHandler(filters.TEXT & ~filters.COMMAND, hideflavour_choose_flavour)],
        },
        fallbacks=[CommandHandler('cancel', cancel), CommandHandler('start', start)],
    )

    application.add_handler(CommandHandler('desserts', desserts))
    application.add_handler(CallbackQueryHandler(desserts, pattern=r'^category_desserts$'))
    application.add_handler(CallbackQueryHandler(desserts, pattern=r'^go_back$'))
    application.add_handler(CallbackQueryHandler(list_desserts, pattern=r'^listdesserts$'))

    # Now add ConversationHandlers
    application.add_handler(add_event_conv)
    application.add_handler(delete_event_conv)
    application.add_handler(add_fact_conv)
    application.add_handler(delete_fact_conv)
    application.add_handler(add_menu_conv)
    application.add_handler(delete_menu_conv)
    application.add_handler(add_drink_conv)
    application.add_handler(edit_drink_conv)
    application.add_handler(delete_drink_conv)
    application.add_handler(toggle_drink_visibility_conv)
    application.add_handler(toggle_drink_stock_conv)
    application.add_handler(add_drink_image_conv)
    application.add_handler(delete_drink_image_conv)
    application.add_handler(add_desert_conv)
    application.add_handler(edit_dessert_conv)
    application.add_handler(delete_dessert_conv)
    application.add_handler(toggle_dessert_visibility_conv)
    application.add_handler(toggle_dessert_availability_conv)
    application.add_handler(add_dessert_image_conv)
    application.add_handler(delete_dessert_image_conv)
    application.add_handler(add_dish_conv)
    application.add_handler(edit_dish_conv)
    application.add_handler(delete_dish_conv)
    application.add_handler(add_dish_image_conv)
    application.add_handler(delete_dish_image_conv)
    application.add_handler(toggle_dish_visibility_conv)
    application.add_handler(toggle_dish_stock_conv)
    application.add_handler(add_discount_conv)
    application.add_handler(delete_discount_conv)
    application.add_handler(toggle_discount_visibility_conv)
    application.add_handler(add_bar_image_conv)
    application.add_handler(delete_bar_image_conv)
    application.add_handler(add_category_conv)
    application.add_handler(edit_category_conv)
    application.add_handler(delete_category_conv)
    application.add_handler(hide_category_conv)
    application.add_handler(hide_product_conv)
    application.add_handler(add_product_conv)
    application.add_handler(edit_product_conv)
    application.add_handler(add_flavour_conv)
    application.add_handler(edit_flavour_conv)
    application.add_handler(delete_flavour_conv)
    application.add_handler(hide_flavour_conv)
    application.add_handler(CallbackQueryHandler(listflavours, pattern=r'^listflavours$'))
    application.add_handler(CallbackQueryHandler(list_bar_images, pattern=r'^list_bar_images$'))
    application.add_handler(CallbackQueryHandler(listproducts, pattern=r'^listproducts$'))
    application.add_handler(CallbackQueryHandler(deleteproduct_start, pattern=r'^deleteproduct$'))
    application.add_handler(CallbackQueryHandler(list_discounts, pattern=r'^listdiscounts$'))

    application.add_handler(CommandHandler('start', start))
    application.add_handler(CommandHandler('cancel', cancel))
    application.add_handler(CommandHandler('desserts', desserts))
    application.add_handler(CommandHandler('events', events))
    application.add_handler(CommandHandler('funfacts', funfacts))
    application.add_handler(CommandHandler('menu', menu))
    application.add_handler(CommandHandler('drinks', drinks))
    application.add_handler(CommandHandler('others', others))
    application.add_handler(CallbackQueryHandler(others, pattern=r'^category_others$'))
    application.add_handler(CallbackQueryHandler(listcategories, pattern=r'^listcategories$'))
    application.add_handler(CommandHandler('miscellaneous', miscellaneous))
    application.add_handler(CommandHandler('check_seasonal_status', check_seasonal_status))
    application.add_handler(CommandHandler('toggle_summer_drinks', toggle_summer_drinks))
    application.add_handler(CommandHandler('toggle_winter_drinks', toggle_winter_drinks))
    application.add_handler(CommandHandler('list_drinks', list_drinks))
    application.add_handler(CallbackQueryHandler(desserts, pattern=r'^category_desserts$'))
    application.add_handler(CallbackQueryHandler(events, pattern=r'^category_events$'))
    application.add_handler(CallbackQueryHandler(funfacts, pattern=r'^category_funfacts$'))
    application.add_handler(CallbackQueryHandler(menu, pattern=r'^category_menu$'))
    application.add_handler(CallbackQueryHandler(drinks, pattern=r'^category_drinks$'))
    application.add_handler(CallbackQueryHandler(others, pattern=r'^category_others$'))
    application.add_handler(CallbackQueryHandler(miscellaneous, pattern=r'^category_miscellaneous$'))
    application.add_handler(CallbackQueryHandler(desserts, pattern=r'^go_back$'))
    application.add_handler(CallbackQueryHandler(list_events, pattern=r'^listevents$'))
    application.add_handler(CallbackQueryHandler(listfacts, pattern=r'^listfacts$'))
    application.add_handler(CallbackQueryHandler(discounts, pattern=r'^category_discounts$'))
    
    # Menu callback handlers
    application.add_handler(CallbackQueryHandler(menu, pattern=r'^addmenu$'))
    application.add_handler(CallbackQueryHandler(menu, pattern=r'^listmenus$'))
    application.add_handler(CallbackQueryHandler(menu, pattern=r'^deletemenu$'))
    application.add_handler(CallbackQueryHandler(menu, pattern=r'^checkmenu$'))
    application.add_handler(CallbackQueryHandler(menu, pattern=r'^togglemenu$'))
    application.add_handler(CallbackQueryHandler(drinks, pattern=r'^listdrinks$'))
    application.add_handler(CallbackQueryHandler(dishes, pattern=r'^category_dishes$'))
    application.add_handler(CallbackQueryHandler(list_dishes, pattern=r'^listdishes$'))

    print("Bot is running...")
    application.run_polling() 
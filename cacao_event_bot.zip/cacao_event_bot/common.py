import os
import warnings
from dotenv import load_dotenv
from telegram import InlineKeyboardButton, InlineKeyboardMarkup

def suppress_ptb_warnings():
    warnings.filterwarnings(action='ignore', message=r'.*CallbackQueryHandler.*', category=UserWarning)

def get_env_vars():
    load_dotenv()
    env = {
        'TELEGRAM_TOKEN': os.getenv('TELEGRAM_BOT_TOKEN'),
        'API_BASE_URL': os.getenv('API_BASE_URL', 'http://localhost:3001'),
        'API_SECRET': os.getenv('EVENT_API_SECRET', 'changeme'),
        'API_URL': os.getenv('EVENT_API_URL', 'http://localhost:3001/api/events'),
        'FUN_FACTS_URL': os.getenv('EVENT_API_URL', 'http://localhost:3001/api/funfacts'),
        'SETTINGS_URL': os.getenv('EVENT_API_URL', 'http://localhost:3001/api/settings'),
        'MENU_URL': os.getenv('EVENT_API_URL', 'http://localhost:3001/api/menu'),
        'DRINKS_URL': os.getenv('EVENT_API_URL', 'http://localhost:3001/api/drinks'),
        'DESERTS_URL': os.getenv('EVENT_API_URL', 'http://localhost:3001/api/deserts'),
        'CATEGORIES_URL': os.getenv('EVENT_API_URL', 'http://localhost:3001/api/categories'),
        'CHANNEL_ID': os.getenv('TELEGRAM_CHANNEL_ID'),
    }
    if not env['TELEGRAM_TOKEN']:
        raise ValueError("TELEGRAM_BOT_TOKEN not found in environment variables. Please check your .env file.")
    return env

def get_go_back_button():
    """Returns a list with a single 'Go Back' button with emoji for inline keyboards."""
    return [InlineKeyboardButton("🔙 Go Back", callback_data="go_back")]

# Handler for 'go back' callback
async def go_back_handler(update, context, start_func=None):
    """Handles the 'go back' button by redirecting to the /start message."""
    query = update.callback_query
    await query.answer()
    from common import get_start_menu
    welcome_message, reply_markup = get_start_menu()
    await query.edit_message_text(welcome_message, reply_markup=reply_markup)

def get_start_menu():
    """Returns the welcome message and reply_markup for the start menu."""
    welcome_message = (
        "🌟 Welcome to the But First Cacao Bot! 🍫\n\n"
        "I'm here to help you manage your cacao business.\n\n"
        "Please choose the category you want to manage:"
    )
    categories = [
        ("Events", "events"),
        ("Fun Facts", "funfacts"),
        ("Menu", "menu"),
        ("Drinks", "drinks"),
        ("Desserts", "desserts"),
        ("Dishes", "dishes"),
        ("Discounts", "discounts"),
        ("Others", "others"),
        ("Miscellaneous", "miscellaneous"),
    ]
    keyboard = [[InlineKeyboardButton(name, callback_data=f"category_{cb}")] for name, cb in categories]
    reply_markup = InlineKeyboardMarkup(keyboard)
    return welcome_message, reply_markup

# Placeholder for more general helpers to be added as we refactor 

# Access control: Only allow certain user IDs
ALLOWED_USER_IDS = {6275380684, 5139369126, 343062175, 417146900}  # Add more IDs as needed
# Bob, Marina, Dimitri, Nastya


def restricted_access(handler):
    from functools import wraps
    @wraps(handler)
    async def wrapper(update, context, *args, **kwargs):
        user_id = update.effective_user.id if update.effective_user else None
        if user_id not in ALLOWED_USER_IDS:
            return  # Do nothing if not allowed
        return await handler(update, context, *args, **kwargs)
    return wrapper 
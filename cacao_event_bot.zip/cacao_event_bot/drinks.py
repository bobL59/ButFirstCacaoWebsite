from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.constants import ParseMode
from telegram.ext import ContextTypes
from common import get_go_back_button, go_back_handler, get_env_vars, get_start_menu
import requests
from telegram.ext import ConversationHandler
from constants import (
    ADD_DRINK_NAME, ADD_DRINK_TYPE, ADD_DRINK_DESC, ADD_DRINK_CATEGORY, ADD_DRINK_PRICE, ADD_DRINK_IMAGE,
    EDIT_DRINK_CHOOSE, EDIT_DRINK_FIELD, EDIT_DRINK_VALUE,
    DELETE_DRINK_CHOOSE, DELETE_DRINK_CONFIRM,
    TOGGLE_DRINK_VISIBILITY_CHOOSE, TOGGLE_DRINK_STOCK_CHOOSE,
    ADD_DRINK_IMAGE_CHOOSE, DELETE_DRINK_IMAGE_CHOOSE, DELETE_DRINK_IMAGE_CONFIRM
)

# Helper to generate the drinks message
DRINKS_MESSAGE = (
    "🥤 <b>Drinks</b>\n"
    "Select an action below:"
)

# Inline keyboard for drinks actions
DRINKS_KEYBOARD = [
    [InlineKeyboardButton("Add a new drink", callback_data="adddrink")],
    [InlineKeyboardButton("View all drinks", callback_data="listdrinks")],
    [InlineKeyboardButton("Modify a drink", callback_data="editdrink")],
    [InlineKeyboardButton("Remove a drink", callback_data="deletedrink")],
    [InlineKeyboardButton("Toggle drink visibility", callback_data="toggledrink")],
    [InlineKeyboardButton("Update drink stock", callback_data="togglestock")],
    [InlineKeyboardButton("Add drink photo", callback_data="adddrinkimage")],
    [InlineKeyboardButton("Remove drink photo", callback_data="deletedrinkimage")],
    get_go_back_button(),
]
DRINKS_REPLY_MARKUP = InlineKeyboardMarkup(DRINKS_KEYBOARD)

# Get environment variables
env = get_env_vars()
SETTINGS_URL = env['SETTINGS_URL']
DRINKS_URL = env['DRINKS_URL']
API_SECRET = env['API_SECRET']

# Inline keyboards for type and category
DRINK_TYPE_KEYBOARD = InlineKeyboardMarkup([
    [InlineKeyboardButton("☕ Hot", callback_data="drinktype_hot"), InlineKeyboardButton("🧊 Cold", callback_data="drinktype_cold")]
])
DRINK_CATEGORY_KEYBOARD = InlineKeyboardMarkup([
    [InlineKeyboardButton("Main", callback_data="drinkcat_main")],
    [InlineKeyboardButton("Summer", callback_data="drinkcat_summer")],
    [InlineKeyboardButton("Winter", callback_data="drinkcat_winter")]
])

EDIT_FIELD_KEYBOARD = InlineKeyboardMarkup([
    [InlineKeyboardButton("Name", callback_data="editfield_name")],
    [InlineKeyboardButton("Type", callback_data="editfield_type")],
    [InlineKeyboardButton("Description", callback_data="editfield_description")],
    [InlineKeyboardButton("Category", callback_data="editfield_category")],
    [InlineKeyboardButton("Price", callback_data="editfield_price")],
])

async def drinks(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Handles both command and callback
    if update.message:
        await update.message.reply_text(
            DRINKS_MESSAGE,
            parse_mode=ParseMode.HTML,
            reply_markup=DRINKS_REPLY_MARKUP
        )
    elif update.callback_query:
        query = update.callback_query
        await query.answer()
        data = query.data
        if data == "go_back":
            await go_back_handler(update, context)
            return
        elif data == "adddrink":
            await add_drink_start(update, context)
            return
        elif data == "listdrinks":
            await list_drinks(update, context)
            return
        elif data == "editdrink":
            await query.message.reply_text("[Placeholder] Edit drink feature coming soon!")
            return
        elif data == "deletedrink":
            await query.message.reply_text("[Placeholder] Delete drink feature coming soon!")
            return
        elif data == "toggledrink":
            await query.message.reply_text("[Placeholder] Toggle drink visibility feature coming soon!")
            return
        elif data == "togglestock":
            await query.message.reply_text("[Placeholder] Toggle drink stock feature coming soon!")
            return
        elif data == "adddrinkimage":
            await query.message.reply_text("[Placeholder] Add drink image feature coming soon!")
            return
        elif data == "deletedrinkimage":
            await query.message.reply_text("[Placeholder] Delete drink image feature coming soon!")
            return
        # Default: re-show the menu
        await query.edit_message_text(
            DRINKS_MESSAGE,
            parse_mode=ParseMode.HTML,
            reply_markup=DRINKS_REPLY_MARKUP
        )

def adddrink(update: Update, context: ContextTypes.DEFAULT_TYPE):
    pass

async def list_drinks(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Support both message and callback_query contexts
    if update.message:
        reply = update.message.reply_text
    elif update.callback_query:
        reply = update.callback_query.message.reply_text
    else:
        return
    try:
        resp = requests.get(DRINKS_URL)
        if resp.status_code == 200:
            drinks = resp.json()
        else:
            await reply(f"Failed to fetch drinks: {resp.text}")
            return
    except Exception as e:
        await reply(f"Error fetching drinks: {e}")
        return

    if not drinks:
        await reply("No drinks found.")
        # Show start menu
        welcome_message, reply_markup = get_start_menu()
        await reply(welcome_message, reply_markup=reply_markup)
        return

    # Split drinks into chunks to avoid message length limit
    chunk_size = 5  # Reduced chunk size to accommodate more details
    for i in range(0, len(drinks), chunk_size):
        chunk = drinks[i:i + chunk_size]
        msg = f"Drinks (Part {i//chunk_size + 1}):\n\n"
        
        for drink in chunk:
            # Add status stickers
            status_stickers = []
            if not drink.get('visible', True):
                status_stickers.append("👁️ Hidden")
            if not drink.get('inStock', True):
                status_stickers.append("❌ Out of Stock")
            
            # Format the drink entry
            msg += f"<b>{drink['name']}</b>"
            if status_stickers:
                msg += f" {' '.join(status_stickers)}"
            msg += f"\n"
            msg += f"Type: {'☕ Hot' if drink['type'] == 'hot' else '🧊 Cold'}\n"
            msg += f"Category: {drink['category'].title()}\n"
            msg += f"Price: ₾{drink.get('price', '?')}\n"
            msg += f"Description: {drink['description']}\n"
            msg += f"Images: {len(drink['images'])} 📸\n\n"

        await reply(msg, parse_mode='HTML')
    # Show start menu after listing
    welcome_message, reply_markup = get_start_menu()
    await reply(welcome_message, reply_markup=reply_markup)

async def edit_drink_choose(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    if not text.isdigit():
        await update.message.reply_text("Please reply with a valid number.")
        return EDIT_DRINK_CHOOSE

    idx = int(text) - 1
    drinks = context.user_data.get('drinks', [])
    if idx < 0 or idx >= len(drinks):
        await update.message.reply_text("Number out of range. Try again.")
        return EDIT_DRINK_CHOOSE

    context.user_data['edit_drink'] = drinks[idx]
    await update.message.reply_text(
        "What would you like to edit?",
        reply_markup=EDIT_FIELD_KEYBOARD
    )
    return EDIT_DRINK_FIELD

async def edit_drink_field(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Accept only callback_query for field selection
    if update.callback_query:
        field_data = update.callback_query.data
        field_map = {
            'editfield_name': 'name',
            'editfield_type': 'type',
            'editfield_description': 'description',
            'editfield_category': 'category',
            'editfield_price': 'price',
        }
        field = field_map.get(field_data)
        if not field:
            await update.callback_query.answer("Invalid field.")
            return EDIT_DRINK_FIELD
        context.user_data['edit_field'] = field
        if field == 'type':
            await update.callback_query.message.reply_text(
                "Please select the new type:",
                reply_markup=DRINK_TYPE_KEYBOARD
            )
        elif field == 'category':
            await update.callback_query.message.reply_text(
                "Please select the new category:",
                reply_markup=DRINK_CATEGORY_KEYBOARD
            )
        elif field == 'price':
            await update.callback_query.message.reply_text(
                "Please enter the new price in GEL (e.g. 10.5):"
            )
        else:
            await update.callback_query.message.reply_text(f"Please enter the new {field}:")
        return EDIT_DRINK_VALUE
    else:
        await update.message.reply_text("Please use the buttons to select the field.")
        return EDIT_DRINK_FIELD

async def edit_drink_value(update: Update, context: ContextTypes.DEFAULT_TYPE):
    field = context.user_data.get('edit_field')
    drink = context.user_data.get('edit_drink')
    # Handle type/category edits via callback_query
    if update.callback_query and field in ['type', 'category']:
        if field == 'type':
            type_data = update.callback_query.data
            if type_data == 'drinktype_hot':
                value = 'hot'
            elif type_data == 'drinktype_cold':
                value = 'cold'
            else:
                await update.callback_query.answer("Invalid type.")
                return EDIT_DRINK_VALUE
        elif field == 'category':
            cat_data = update.callback_query.data
            if cat_data == 'drinkcat_main':
                value = 'main'
            elif cat_data == 'drinkcat_summer':
                value = 'summer'
            elif cat_data == 'drinkcat_winter':
                value = 'winter'
            else:
                await update.callback_query.answer("Invalid category.")
                return EDIT_DRINK_VALUE
    else:
        value = update.message.text.strip()
        if field == 'type' and value.lower() not in ['hot', 'cold']:
            await update.message.reply_text("Invalid type. Please enter 'hot' or 'cold':")
            return EDIT_DRINK_VALUE
        elif field == 'category' and value.lower() not in ['main', 'summer', 'winter']:
            await update.message.reply_text("Invalid category. Please enter 'main', 'summer', or 'winter':")
            return EDIT_DRINK_VALUE
        elif field == 'price':
            try:
                value = float(value)
                if value < 0:
                    raise ValueError
            except Exception:
                await update.message.reply_text("Invalid price. Please enter a valid number (e.g. 10.5):")
                return EDIT_DRINK_VALUE

    try:
        updates = {field: value}
        if field == 'name':
            # Generate new ID based on new name
            updates['id'] = value.lower().replace(' ', '-')

        resp = requests.put(
            f"{DRINKS_URL}/{drink['id']}",
            json={**updates, 'secret': API_SECRET}
        )

        reply = update.message.reply_text if update.message else update.callback_query.message.reply_text
        if resp.status_code == 200:
            await reply("Drink updated successfully!")
        else:
            await reply(f"Failed to update drink: {resp.text}")
    except Exception as e:
        reply = update.message.reply_text if update.message else update.callback_query.message.reply_text
        await reply(f"Error updating drink: {e}")

    # Show start menu after editing
    welcome_message, reply_markup = get_start_menu()
    await reply(welcome_message, reply_markup=reply_markup)
    return ConversationHandler.END

def deletedrink(update: Update, context: ContextTypes.DEFAULT_TYPE):
    pass

def toggledrink(update: Update, context: ContextTypes.DEFAULT_TYPE):
    pass

def togglestock(update: Update, context: ContextTypes.DEFAULT_TYPE):
    pass

def adddrinkimage(update: Update, context: ContextTypes.DEFAULT_TYPE):
    pass

def deletedrinkimage(update: Update, context: ContextTypes.DEFAULT_TYPE):
    pass

async def check_seasonal_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        resp = requests.get(f"{SETTINGS_URL}/seasonal-drinks")
        if resp.status_code == 200:
            status = resp.json()
            await update.message.reply_text(
                "Current Seasonal Drinks Status:\n\n"
                f"Summer Drinks: {'🟢 Enabled' if status.get('summer', True) else '🔴 Disabled'}\n"
                f"Winter Drinks: {'🟢 Enabled' if status.get('winter', True) else '🔴 Disabled'}"
            )
        else:
            await update.message.reply_text(f"Failed to fetch seasonal drinks status: {resp.text}")
    except Exception as e:
        await update.message.reply_text(f"Error checking seasonal drinks status: {e}")

async def toggle_summer_drinks(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        resp = requests.post(
            f"{SETTINGS_URL}/seasonal-drinks",
            json={
                'season': 'summer',
                'secret': API_SECRET
            }
        )
        
        if resp.status_code == 200:
            result = resp.json()
            await update.message.reply_text(result['message'])
        else:
            await update.message.reply_text(f"Failed to toggle summer drinks: {resp.text}")
    except Exception as e:
        await update.message.reply_text(f"Error toggling summer drinks: {e}")

async def toggle_winter_drinks(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        resp = requests.post(
            f"{SETTINGS_URL}/seasonal-drinks",
            json={
                'season': 'winter',
                'secret': API_SECRET
            }
        )
        
        if resp.status_code == 200:
            result = resp.json()
            await update.message.reply_text(result['message'])
        else:
            await update.message.reply_text(f"Failed to toggle winter drinks: {resp.text}")
    except Exception as e:
        await update.message.reply_text(f"Error toggling winter drinks: {e}")

# Remove old placeholder functions and implement the async drink management functions

async def add_drink_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message:
        await update.message.reply_text("Please enter the name of the new drink:")
    elif update.callback_query:
        await update.callback_query.message.reply_text("Please enter the name of the new drink:")
    return ADD_DRINK_NAME

async def add_drink_name(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['drink_name'] = update.message.text
    await update.message.reply_text(
        "Please choose the drink type:",
        reply_markup=DRINK_TYPE_KEYBOARD
    )
    return ADD_DRINK_TYPE

async def add_drink_type(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Accept only callback_query for type selection
    if update.callback_query:
        type_data = update.callback_query.data
        if type_data == 'drinktype_hot':
            context.user_data['drink_type'] = 'hot'
        elif type_data == 'drinktype_cold':
            context.user_data['drink_type'] = 'cold'
        else:
            await update.callback_query.answer("Invalid type.")
            return ADD_DRINK_TYPE
        await update.callback_query.message.reply_text(
            "Please enter the drink description:"
        )
        return ADD_DRINK_DESC
    else:
        await update.message.reply_text("Please use the buttons to select the type.")
        return ADD_DRINK_TYPE

async def add_drink_desc(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        context.user_data['drink_desc'] = update.message.text
        await update.message.reply_text(
            "Please choose the drink category:",
            reply_markup=DRINK_CATEGORY_KEYBOARD
        )
        return ADD_DRINK_CATEGORY
    except Exception as e:
        await update.message.reply_text(f"Error: {e}")
        return ConversationHandler.END

async def add_drink_category(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Accept only callback_query for category selection
    if update.callback_query:
        cat_data = update.callback_query.data
        if cat_data == 'drinkcat_main':
            context.user_data['drink_category'] = 'main'
        elif cat_data == 'drinkcat_summer':
            context.user_data['drink_category'] = 'summer'
        elif cat_data == 'drinkcat_winter':
            context.user_data['drink_category'] = 'winter'
        else:
            await update.callback_query.answer("Invalid category.")
            return ADD_DRINK_CATEGORY
        await update.callback_query.message.reply_text(
            "Please enter the price of the drink in GEL (e.g. 10.5):"
        )
        return ADD_DRINK_PRICE
    else:
        await update.message.reply_text("Please use the buttons to select the category.")
        return ADD_DRINK_CATEGORY

async def add_drink_price(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    try:
        price = float(text)
        if price < 0:
            raise ValueError
    except Exception:
        await update.message.reply_text("Invalid price. Please enter a valid number (e.g. 10.5):")
        return ADD_DRINK_PRICE
    context.user_data['drink_price'] = price
    await update.message.reply_text(
        "Please send an image for the drink.\nYou can add more images later using /add_drink_image command."
    )
    return ADD_DRINK_IMAGE

async def add_drink_image(update: Update, context: ContextTypes.DEFAULT_TYPE):
    image_url = None
    file_id = None

    if update.message and update.message.photo:
        photo = update.message.photo[-1]
        file_id = photo.file_id
        file = await update.message.get_bot().get_file(file_id)
        image_url = file.file_path
    elif update.message and update.message.text and update.message.text.startswith('http'):
        image_url = update.message.text
    else:
        await update.message.reply_text("Please send a photo or a valid image URL.")
        return ADD_DRINK_IMAGE

    try:
        # Check if we're adding an image to an existing drink
        if 'selected_drink' in context.user_data:
            drink = context.user_data['selected_drink']
            image_data = {
                'image_url': image_url,
                'secret': API_SECRET
            }
            resp = requests.post(f"{DRINKS_URL}/{drink['id']}/images", json=image_data)
            if resp.status_code != 200:
                await update.message.reply_text("Failed to add image to drink.")
                return ConversationHandler.END
            await update.message.reply_text("Image added successfully!")
            del context.user_data['selected_drink']
            # Show start menu after image add
            welcome_message, reply_markup = get_start_menu()
            await update.message.reply_text(welcome_message, reply_markup=reply_markup)
            return ConversationHandler.END
        else:
            drink_data = {
                'name': context.user_data['drink_name'],
                'type': context.user_data['drink_type'],
                'description': context.user_data['drink_desc'],
                'category': context.user_data['drink_category'],
                'price': context.user_data['drink_price'],
                'secret': API_SECRET
            }
            resp = requests.post(DRINKS_URL, json=drink_data)
            if resp.status_code != 200:
                await update.message.reply_text(f"Failed to create drink: {resp.text}")
                return ConversationHandler.END
            drink = resp.json()
            image_data = {
                'image_url': image_url,
                'secret': API_SECRET
            }
            resp = requests.post(f"{DRINKS_URL}/{drink['id']}/images", json=image_data)
            if resp.status_code != 200:
                await update.message.reply_text("Drink created, but failed to add image.")
                return ConversationHandler.END
            await update.message.reply_text("Drink added successfully!")
            # Show start menu after drink add
            welcome_message, reply_markup = get_start_menu()
            await update.message.reply_text(welcome_message, reply_markup=reply_markup)
            return ConversationHandler.END
    except Exception as e:
        await update.message.reply_text(f"Error adding drink/image: {e}")
        return ConversationHandler.END

async def edit_drink_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    reply = update.message.reply_text if update.message else update.callback_query.message.reply_text
    try:
        resp = requests.get(DRINKS_URL)
        if resp.status_code == 200:
            drinks = resp.json()
        else:
            await reply(f"Failed to fetch drinks: {resp.text}")
            return ConversationHandler.END
    except Exception as e:
        await reply(f"Error fetching drinks: {e}")
        return ConversationHandler.END

    if not drinks:
        await reply("No drinks to edit.")
        return ConversationHandler.END

    context.user_data['drinks'] = drinks
    
    # Split drinks into chunks
    chunk_size = 10  # Number of drinks per message
    for i in range(0, len(drinks), chunk_size):
        chunk = drinks[i:i + chunk_size]
        msg = f"Which drink do you want to edit? (Part {i//chunk_size + 1})\nReply with the number.\n"
        for j, drink in enumerate(chunk):
            msg += f"\n{i+j+1}. {drink['name']} ({drink['type']})"
        await reply(msg)
    return EDIT_DRINK_CHOOSE

async def delete_drink_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    reply = update.message.reply_text if update.message else update.callback_query.message.reply_text
    try:
        resp = requests.get(DRINKS_URL)
        if resp.status_code == 200:
            drinks = resp.json()
        else:
            await reply(f"Failed to fetch drinks: {resp.text}")
            return ConversationHandler.END
    except Exception as e:
        await reply(f"Error fetching drinks: {e}")
        return ConversationHandler.END

    if not drinks:
        await reply("No drinks to delete.")
        return ConversationHandler.END

    context.user_data['drinks'] = drinks
    
    # Split drinks into chunks
    chunk_size = 10  # Number of drinks per message
    for i in range(0, len(drinks), chunk_size):
        chunk = drinks[i:i + chunk_size]
        msg = f"Which drink do you want to delete? (Part {i//chunk_size + 1})\nReply with the number.\n"
        for j, drink in enumerate(chunk):
            msg += f"\n{i+j+1}. {drink['name']} ({drink['type']})"
        await reply(msg)
    return DELETE_DRINK_CHOOSE

async def delete_drink_choose(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    if not text.isdigit():
        await update.message.reply_text("Please reply with a valid number.")
        return DELETE_DRINK_CHOOSE

    idx = int(text) - 1
    drinks = context.user_data.get('drinks', [])
    if idx < 0 or idx >= len(drinks):
        await update.message.reply_text("Number out of range. Try again.")
        return DELETE_DRINK_CHOOSE

    context.user_data['delete_drink'] = drinks[idx]
    msg = f"Are you sure you want to delete {drinks[idx]['name']}? Reply YES to confirm, or /cancel."
    await update.message.reply_text(msg)
    return DELETE_DRINK_CONFIRM

async def delete_drink_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message.text.strip().upper() != 'YES':
        await update.message.reply_text("Deletion cancelled.")
        return ConversationHandler.END

    drink = context.user_data.get('delete_drink')
    if not drink:
        await update.message.reply_text("No drink selected.")
        return ConversationHandler.END

    try:
        resp = requests.delete(
            f"{DRINKS_URL}/{drink['id']}",
            json={'secret': API_SECRET}
        )

        if resp.status_code == 200:
            await update.message.reply_text("Drink deleted successfully!")
        else:
            await update.message.reply_text(f"Failed to delete drink: {resp.text}")
    except Exception as e:
        await update.message.reply_text(f"Error deleting drink: {e}")

    # Show start menu after deleting a drink
    welcome_message, reply_markup = get_start_menu()
    await update.message.reply_text(welcome_message, reply_markup=reply_markup)
    return ConversationHandler.END

async def toggle_drink_visibility_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    reply = update.message.reply_text if update.message else update.callback_query.message.reply_text
    try:
        resp = requests.get(DRINKS_URL)
        if resp.status_code == 200:
            drinks = resp.json()
        else:
            await reply(f"Failed to fetch drinks: {resp.text}")
            return ConversationHandler.END
    except Exception as e:
        await reply(f"Error fetching drinks: {e}")
        return ConversationHandler.END

    if not drinks:
        await reply("No drinks to toggle.")
        return ConversationHandler.END

    context.user_data['drinks'] = drinks
    
    # Split drinks into chunks
    chunk_size = 10  # Number of drinks per message
    for i in range(0, len(drinks), chunk_size):
        chunk = drinks[i:i + chunk_size]
        msg = f"Which drink's visibility do you want to toggle? (Part {i//chunk_size + 1})\nReply with the number.\n"
        for j, drink in enumerate(chunk):
            status = "👁️ Hidden" if not drink.get('visible', True) else "👁️ Visible"
            msg += f"\n{i+j+1}. {drink['name']} - {status}"
        await reply(msg)
    return TOGGLE_DRINK_VISIBILITY_CHOOSE

async def toggle_drink_visibility_choose(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    if not text.isdigit():
        await update.message.reply_text("Please reply with a valid number.")
        return TOGGLE_DRINK_VISIBILITY_CHOOSE

    idx = int(text) - 1
    drinks = context.user_data.get('drinks', [])
    if idx < 0 or idx >= len(drinks):
        await update.message.reply_text("Number out of range. Try again.")
        return TOGGLE_DRINK_VISIBILITY_CHOOSE

    drink = drinks[idx]
    try:
        resp = requests.put(
            f"{DRINKS_URL}/{drink['id']}",
            json={
                'visible': not drink.get('visible', True),
                'secret': API_SECRET
            }
        )

        if resp.status_code == 200:
            new_status = "hidden" if drink.get('visible', True) else "visible"
            await update.message.reply_text(f"Drink is now {new_status}!")
        else:
            await update.message.reply_text(f"Failed to toggle visibility: {resp.text}")
    except Exception as e:
        await update.message.reply_text(f"Error toggling visibility: {e}")

    # Show start menu after toggling visibility
    welcome_message, reply_markup = get_start_menu()
    await update.message.reply_text(welcome_message, reply_markup=reply_markup)
    return ConversationHandler.END

async def toggle_drink_stock_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    reply = update.message.reply_text if update.message else update.callback_query.message.reply_text
    try:
        resp = requests.get(DRINKS_URL)
        if resp.status_code == 200:
            drinks = resp.json()
        else:
            await reply(f"Failed to fetch drinks: {resp.text}")
            return ConversationHandler.END
    except Exception as e:
        await reply(f"Error fetching drinks: {e}")
        return ConversationHandler.END

    if not drinks:
        await reply("No drinks to toggle.")
        return ConversationHandler.END

    context.user_data['drinks'] = drinks
    
    # Split drinks into chunks
    chunk_size = 10  # Number of drinks per message
    for i in range(0, len(drinks), chunk_size):
        chunk = drinks[i:i + chunk_size]
        msg = f"Which drink's stock status do you want to toggle? (Part {i//chunk_size + 1})\nReply with the number.\n"
        for j, drink in enumerate(chunk):
            status = "❌ Out of Stock" if not drink.get('inStock', True) else "✅ In Stock"
            msg += f"\n{i+j+1}. {drink['name']} - {status}"
        await reply(msg)
    return TOGGLE_DRINK_STOCK_CHOOSE

async def toggle_drink_stock_choose(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    if not text.isdigit():
        await update.message.reply_text("Please reply with a valid number.")
        return TOGGLE_DRINK_STOCK_CHOOSE

    idx = int(text) - 1
    drinks = context.user_data.get('drinks', [])
    if idx < 0 or idx >= len(drinks):
        await update.message.reply_text("Number out of range. Try again.")
        return TOGGLE_DRINK_STOCK_CHOOSE

    drink = drinks[idx]
    try:
        resp = requests.put(
            f"{DRINKS_URL}/{drink['id']}",
            json={
                'inStock': not drink.get('inStock', True),
                'secret': API_SECRET
            }
        )

        if resp.status_code == 200:
            new_status = "out of stock" if drink.get('inStock', True) else "in stock"
            await update.message.reply_text(f"Drink is now {new_status}!")
        else:
            await update.message.reply_text(f"Failed to toggle stock status: {resp.text}")
    except Exception as e:
        await update.message.reply_text(f"Error toggling stock status: {e}")

    # Show start menu after toggling stock
    welcome_message, reply_markup = get_start_menu()
    await update.message.reply_text(welcome_message, reply_markup=reply_markup)
    return ConversationHandler.END

async def add_drink_image_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    reply = update.message.reply_text if update.message else update.callback_query.message.reply_text
    try:
        resp = requests.get(DRINKS_URL)
        if resp.status_code == 200:
            drinks = resp.json()
        else:
            await reply(f"Failed to fetch drinks: {resp.text}")
            return ConversationHandler.END
    except Exception as e:
        await reply(f"Error fetching drinks: {e}")
        return ConversationHandler.END

    if not drinks:
        await reply("No drinks to add images to.")
        return ConversationHandler.END

    context.user_data['drinks'] = drinks
    
    # Split drinks into chunks
    chunk_size = 10  # Number of drinks per message
    for i in range(0, len(drinks), chunk_size):
        chunk = drinks[i:i + chunk_size]
        msg = f"Which drink do you want to add an image to? (Part {i//chunk_size + 1})\nReply with the number.\n"
        for j, drink in enumerate(chunk):
            msg += f"\n{i+j+1}. {drink['name']} ({len(drink['images'])} images)"
        await reply(msg)
    return ADD_DRINK_IMAGE_CHOOSE

async def add_drink_image_choose(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    if not text.isdigit():
        await update.message.reply_text("Please reply with a valid number.")
        return ADD_DRINK_IMAGE_CHOOSE

    idx = int(text) - 1
    drinks = context.user_data.get('drinks', [])
    if idx < 0 or idx >= len(drinks):
        await update.message.reply_text("Number out of range. Try again.")
        return ADD_DRINK_IMAGE_CHOOSE

    context.user_data['selected_drink'] = drinks[idx]
    await update.message.reply_text(
        "Please send an image for the drink (send a photo or paste an image URL)."
    )
    return ADD_DRINK_IMAGE

async def delete_drink_image_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    reply = update.message.reply_text if update.message else update.callback_query.message.reply_text
    try:
        resp = requests.get(DRINKS_URL)
        if resp.status_code == 200:
            drinks = resp.json()
        else:
            await reply(f"Failed to fetch drinks: {resp.text}")
            return ConversationHandler.END
    except Exception as e:
        await reply(f"Error fetching drinks: {e}")
        return ConversationHandler.END

    if not drinks:
        await reply("No drinks to delete images from.")
        return ConversationHandler.END

    context.user_data['drinks'] = drinks
    
    # Split drinks into chunks
    chunk_size = 10  # Number of drinks per message
    for i in range(0, len(drinks), chunk_size):
        chunk = drinks[i:i + chunk_size]
        msg = f"Which drink's image do you want to delete? (Part {i//chunk_size + 1})\nReply with the number.\n"
        for j, drink in enumerate(chunk):
            if drink['images']:
                msg += f"\n{i+j+1}. {drink['name']} ({len(drink['images'])} images)"
        await reply(msg)
    return DELETE_DRINK_IMAGE_CHOOSE

async def delete_drink_image_choose(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    if not text.isdigit():
        await update.message.reply_text("Please reply with a valid number.")
        return DELETE_DRINK_IMAGE_CHOOSE

    idx = int(text) - 1
    drinks = context.user_data.get('drinks', [])
    if idx < 0 or idx >= len(drinks):
        await update.message.reply_text("Number out of range. Try again.")
        return DELETE_DRINK_IMAGE_CHOOSE

    drink = drinks[idx]
    if not drink['images']:
        await update.message.reply_text("This drink has no images to delete.")
        return ConversationHandler.END

    context.user_data['selected_drink'] = drink
    msg = "Which image do you want to delete? Reply with the number.\n"
    for i, image in enumerate(drink['images']):
        msg += f"\n{i+1}. {image}"
    await update.message.reply_text(msg)
    return DELETE_DRINK_IMAGE_CONFIRM

async def delete_drink_image_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    if not text.isdigit():
        await update.message.reply_text("Please reply with a valid number.")
        return DELETE_DRINK_IMAGE_CONFIRM

    idx = int(text) - 1
    drink = context.user_data.get('selected_drink')
    if idx < 0 or idx >= len(drink['images']):
        await update.message.reply_text("Number out of range. Try again.")
        return DELETE_DRINK_IMAGE_CONFIRM

    try:
        resp = requests.delete(
            f"{DRINKS_URL}/{drink['id']}/images/{drink['images'][idx]}",
            json={'secret': API_SECRET}
        )

        if resp.status_code == 200:
            await update.message.reply_text("Image deleted successfully!")
        else:
            await update.message.reply_text(f"Failed to delete image: {resp.text}")
    except Exception as e:
        await update.message.reply_text(f"Error deleting image: {e}")

    # Show start menu after deleting an image
    welcome_message, reply_markup = get_start_menu()
    await update.message.reply_text(welcome_message, reply_markup=reply_markup)
    return ConversationHandler.END

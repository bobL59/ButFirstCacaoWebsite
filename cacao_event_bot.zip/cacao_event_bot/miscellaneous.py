from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.constants import ParseMode
from telegram.ext import ContextTypes
from common import get_go_back_button, go_back_handler
import requests
from constants import ADD_BAR_IMAGE_TITLE, ADD_BAR_IMAGE_URL, DELETE_BAR_IMAGE_CHOOSE, DELETE_BAR_IMAGE_CONFIRM
from common import get_env_vars

# Helper to generate the miscellaneous message
MISCELLANEOUS_MESSAGE = (
    "🧩 <b>Miscellaneous</b>\n"
    "Select an action below:"
)

# Update the keyboard to include bar image actions
MISCELLANEOUS_KEYBOARD = [
    [InlineKeyboardButton("Add Bar Image", callback_data="add_bar_image")],
    [InlineKeyboardButton("List Bar Images", callback_data="list_bar_images")],
    [InlineKeyboardButton("Delete Bar Image", callback_data="delete_bar_image")],
    get_go_back_button(),
]
MISCELLANEOUS_REPLY_MARKUP = InlineKeyboardMarkup(MISCELLANEOUS_KEYBOARD)

env = get_env_vars()
API_SECRET = env['API_SECRET']
BAR_IMAGES_URL = env['API_BASE_URL'] + '/api/the-bar/images'

async def miscellaneous(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Handles both command and callback
    if update.message:
        await update.message.reply_text(
            MISCELLANEOUS_MESSAGE,
            parse_mode=ParseMode.HTML,
            reply_markup=MISCELLANEOUS_REPLY_MARKUP
        )
    elif update.callback_query:
        query = update.callback_query
        await query.answer()
        if query.data == "go_back":
            await go_back_handler(update, context)
            return
        if query.data == "add_bar_image":
            await query.edit_message_text("Please enter the title for the new bar image:")
            return ADD_BAR_IMAGE_TITLE
        if query.data == "list_bar_images":
            await list_bar_images(update, context, from_callback=True)
            return
        if query.data == "delete_bar_image":
            return await delete_bar_image_start(update, context, from_callback=True)
        await query.edit_message_text(
            MISCELLANEOUS_MESSAGE,
            parse_mode=ParseMode.HTML,
            reply_markup=MISCELLANEOUS_REPLY_MARKUP
        )

# --- Add Bar Image Handlers ---
async def add_bar_image_title(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['bar_image_title'] = update.message.text
    await update.message.reply_text("Please send the image for the bar (as a photo or file attachment):")
    return ADD_BAR_IMAGE_URL

async def add_bar_image_url(update: Update, context: ContextTypes.DEFAULT_TYPE):
    title = context.user_data.get('bar_image_title')
    image_data = None
    image_ext = '.jpg'
    # Handle photo or document
    if update.message.photo:
        photo = update.message.photo[-1]
        file = await update.message.get_bot().get_file(photo.file_id)
        file_bytes = await file.download_as_bytearray()
        image_data = file_bytes
        image_ext = '.jpg'
    elif update.message.document and update.message.document.mime_type and update.message.document.mime_type.startswith('image/'):
        file = await update.message.get_bot().get_file(update.message.document.file_id)
        file_bytes = await file.download_as_bytearray()
        image_data = file_bytes
        # Try to get extension from filename
        filename = update.message.document.file_name
        if '.' in filename:
            image_ext = filename[filename.rfind('.'):]
    else:
        await update.message.reply_text("Please send a valid image (photo or image file).")
        return ADD_BAR_IMAGE_URL
    try:
        import base64
        image_b64 = base64.b64encode(image_data).decode('utf-8')
        resp = requests.post(BAR_IMAGES_URL, json={
            'title': title,
            'image_data': image_b64,
            'image_ext': image_ext,
            'secret': API_SECRET
        })
        if resp.status_code == 200:
            await update.message.reply_text("Bar image added successfully!")
        else:
            await update.message.reply_text(f"Failed to add bar image: {resp.text}")
    except Exception as e:
        await update.message.reply_text(f"Error adding bar image: {e}")
    from handlers import start
    await start(update, context)
    return -1

# --- List Bar Images Handler ---
async def list_bar_images(update: Update, context: ContextTypes.DEFAULT_TYPE, from_callback=False):
    message = update.callback_query.message if from_callback and update.callback_query else update.message
    if message is None:
        message = update.effective_message
    if message is None:
        # Nowhere to reply, just return
        return
    try:
        resp = requests.get(BAR_IMAGES_URL)
        if resp.status_code == 200:
            images = resp.json()
            if not images:
                await message.reply_text("No bar images found.")
            else:
                msg = "<b>Bar Images:</b>\n\n"
                for img in images:
                    msg += f"<b>{img['id']}</b>. {img['title']}\n{img['src']}\n\n"
                await message.reply_text(msg, parse_mode=ParseMode.HTML)
        else:
            await message.reply_text(f"Failed to fetch bar images: {resp.text}")
    except Exception as e:
        await message.reply_text(f"Error fetching bar images: {e}")
    # Send the /start message as a new message (never edit)
    from handlers import get_start_menu
    welcome_message, reply_markup = get_start_menu()
    await message.reply_text(welcome_message, reply_markup=reply_markup)
    return -1

# --- Delete Bar Image Handlers ---
async def delete_bar_image_start(update: Update, context: ContextTypes.DEFAULT_TYPE, from_callback=False):
    message = update.callback_query.message if from_callback and update.callback_query else update.message
    if message is None:
        message = update.effective_message
    if message is None:
        # Nowhere to reply, just return
        return
    try:
        resp = requests.get(BAR_IMAGES_URL)
        if resp.status_code == 200:
            images = resp.json()
            if not images:
                await message.reply_text("No bar images to delete.")
                from handlers import get_start_menu
                welcome_message, reply_markup = get_start_menu()
                await message.reply_text(welcome_message, reply_markup=reply_markup)
                return -1
            context.user_data['bar_images'] = images
            msg = "Which bar image do you want to delete? Reply with the number.\n"
            for i, img in enumerate(images):
                msg += f"\n{i+1}. {img['title']} ({img['src']})"
            await message.reply_text(msg)
            return DELETE_BAR_IMAGE_CHOOSE
        else:
            await message.reply_text(f"Failed to fetch bar images: {resp.text}")
    except Exception as e:
        await message.reply_text(f"Error fetching bar images: {e}")
    from handlers import get_start_menu
    welcome_message, reply_markup = get_start_menu()
    await message.reply_text(welcome_message, reply_markup=reply_markup)
    return -1

async def delete_bar_image_choose(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    if not text.isdigit():
        await update.message.reply_text("Please reply with a valid number.")
        return DELETE_BAR_IMAGE_CHOOSE
    idx = int(text) - 1
    images = context.user_data.get('bar_images', [])
    if idx < 0 or idx >= len(images):
        await update.message.reply_text("Number out of range. Try again.")
        return DELETE_BAR_IMAGE_CHOOSE
    context.user_data['delete_bar_image'] = images[idx]
    await update.message.reply_text(f"Are you sure you want to delete '{images[idx]['title']}'? Reply YES to confirm, or /cancel.")
    return DELETE_BAR_IMAGE_CONFIRM

async def delete_bar_image_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message.text.strip().upper() != 'YES':
        await update.message.reply_text("Deletion cancelled.")
        from handlers import get_start_menu
        welcome_message, reply_markup = get_start_menu()
        await update.message.reply_text(welcome_message, reply_markup=reply_markup)
        return -1
    img = context.user_data.get('delete_bar_image')
    if not img:
        await update.message.reply_text("No image selected.")
        from handlers import get_start_menu
        welcome_message, reply_markup = get_start_menu()
        await update.message.reply_text(welcome_message, reply_markup=reply_markup)
        return -1
    try:
        resp = requests.delete(f"{BAR_IMAGES_URL}/{img['id']}", json={'secret': API_SECRET})
        if resp.status_code == 200:
            await update.message.reply_text("Bar image deleted successfully!")
        else:
            await update.message.reply_text(f"Failed to delete bar image: {resp.text}")
    except Exception as e:
        await update.message.reply_text(f"Error deleting bar image: {e}")
    from handlers import get_start_menu
    welcome_message, reply_markup = get_start_menu()
    await update.message.reply_text(welcome_message, reply_markup=reply_markup)
    return -1

# Export for bot_app.py
__all__ = [
    'miscellaneous',
    'add_bar_image_title', 'add_bar_image_url',
    'list_bar_images',
    'delete_bar_image_start', 'delete_bar_image_choose', 'delete_bar_image_confirm',
]

import { useEffect, useState } from 'react';
import { Box, Typography, Paper, CircularProgress, Grid, Pagination } from '@mui/material';

interface Discount {
  title: string;
  images: string[];
  occurrence: string;
  description: string;
  visibility: 'visible' | 'hidden';
}

const DiscountsPage = () => {
  const [discounts, setDiscounts] = useState<Discount[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [imageIndexes, setImageIndexes] = useState<{ [idx: number]: number }>({});
  const [page, setPage] = useState(1);
  const DISCOUNTS_PER_PAGE = 8;

  useEffect(() => {
    const fetchDiscounts = async () => {
      setLoading(true);
      setError(null);
      try {
        const res = await fetch('./src/data/discounts.json');
        if (!res.ok) throw new Error('Failed to fetch discounts');
        const data = await res.json();
        setDiscounts(data as Discount[]);
      } catch (err) {
        setError('Failed to load discounts');
      } finally {
        setLoading(false);
      }
    };
    fetchDiscounts();
    const interval = setInterval(fetchDiscounts, 30000); // 30 seconds
    return () => clearInterval(interval);
  }, []);

  const handleImageChange = (idx: number, numImages: number, direction: 'left' | 'right') => {
    setImageIndexes(prev => {
      const current = prev[idx] || 0;
      let next;
      if (direction === 'left') {
        next = (current - 1 + numImages) % numImages;
      } else {
        next = (current + 1) % numImages;
      }
      return { ...prev, [idx]: next };
    });
  };

  // Pagination logic
  const visibleDiscounts = discounts.filter(d => d.visibility !== 'hidden');
  const pageCount = Math.ceil(visibleDiscounts.length / DISCOUNTS_PER_PAGE);
  const pagedDiscounts = visibleDiscounts.slice((page - 1) * DISCOUNTS_PER_PAGE, page * DISCOUNTS_PER_PAGE);

  const handlePageChange = (_event: React.ChangeEvent<unknown>, value: number) => {
    setPage(value);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <Box>
      <Typography variant="h4" gutterBottom sx={{ color: 'primary.main', fontWeight: 'bold', mb: 4 }}>
        Discounts
      </Typography>
      {loading ? (
        <CircularProgress />
      ) : error ? (
        <Typography color="error">{error}</Typography>
      ) : discounts.length === 0 || visibleDiscounts.length === 0 ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: 200 }}>
          <Typography align="center">No discounts are currently available.</Typography>
        </Box>
      ) : (
        <>
          <Grid container direction="column" spacing={4}>
            {pagedDiscounts.map((discount, idx) => {
              const globalIdx = (page - 1) * DISCOUNTS_PER_PAGE + idx;
              return (
                <Grid item key={globalIdx}>
                  <Paper sx={{ p: 6, mb: 2, width: '100%', maxWidth: '100vw', mx: 'auto', minHeight: 300 }} elevation={6}>
                    <Typography variant="h4" sx={{ color: 'primary.main', fontWeight: 700, mb: 2 }}>{discount.title}</Typography>
                    <Typography variant="subtitle1" sx={{ color: 'secondary.main', fontWeight: 600, mb: 2 }}>{discount.occurrence}</Typography>
                    <Typography variant="body1" sx={{ mb: 4, fontSize: 20 }}
                      component="div"
                      dangerouslySetInnerHTML={{
                        __html: (discount.description || '').replace(/\n/g, '<br/>')
                      }}
                    />
                    {discount.images && discount.images.length > 0 && (
                      <Box sx={{ textAlign: 'center', position: 'relative', maxWidth: 800, mx: 'auto' }}>
                        <img
                          src={discount.images[imageIndexes[globalIdx] || 0]}
                          alt={discount.title}
                          style={{ maxWidth: '500px', maxHeight: '300px', borderRadius: 16 }}
                        />
                        {discount.images.length > 1 && (
                          <>
                            <button
                              style={{
                                position: 'absolute',
                                top: '50%',
                                left: 0,
                                transform: 'translateY(-50%)',
                                background: 'rgba(0,0,0,0.3)',
                                color: 'white',
                                border: 'none',
                                borderRadius: '50%',
                                width: 40,
                                height: 40,
                                cursor: 'pointer',
                                fontSize: 24,
                              }}
                              onClick={() => handleImageChange(globalIdx, discount.images.length, 'left')}
                              aria-label="Previous image"
                            >
                              {'<'}
                            </button>
                            <button
                              style={{
                                position: 'absolute',
                                top: '50%',
                                right: 0,
                                transform: 'translateY(-50%)',
                                background: 'rgba(0,0,0,0.3)',
                                color: 'white',
                                border: 'none',
                                borderRadius: '50%',
                                width: 40,
                                height: 40,
                                cursor: 'pointer',
                                fontSize: 24,
                              }}
                              onClick={() => handleImageChange(globalIdx, discount.images.length, 'right')}
                              aria-label="Next image"
                            >
                              {'>'}
                            </button>
                          </>
                        )}
                        <Box sx={{ mt: 1 }}>
                          {discount.images.map((_, i) => (
                            <span
                              key={i}
                              style={{
                                display: 'inline-block',
                                width: 10,
                                height: 10,
                                borderRadius: '50%',
                                background: (imageIndexes[globalIdx] || 0) === i ? '#1976d2' : '#ccc',
                                margin: '0 4px',
                              }}
                            />
                          ))}
                        </Box>
                      </Box>
                    )}
                  </Paper>
                </Grid>
              );
            })}
          </Grid>
          {pageCount > 1 && (
            <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
              <Pagination
                count={pageCount}
                page={page}
                onChange={handlePageChange}
                color="primary"
                size="large"
              />
            </Box>
          )}
        </>
      )}
    </Box>
  );
};

export default DiscountsPage;

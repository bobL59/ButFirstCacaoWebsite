import { Typography, Grid, Box } from '@mui/material';
import { useLanguage } from '../contexts/LanguageContext';
import { useTranslation } from '../contexts/TranslationContext';
import PDFViewer from '../components/PDFViewer';
import { useEffect, useState } from 'react';
import menuData from '../data/menu.json';

interface MenuCategory {
  id: string;
  name: string;
  path: string;
  description: string;
}

interface Settings {
  specialMenuEnabled: boolean;
}

const MenuPage = () => {
  const { language } = useLanguage();
  const { t } = useTranslation();
  const [menuCategories, setMenuCategories] = useState<MenuCategory[]>(menuData.categories);
  const [settings, setSettings] = useState<Settings>({ specialMenuEnabled: true });
  const [pdfUrls, setPdfUrls] = useState<Record<string, string>>({});

  // Fetch settings
  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const response = await fetch('/api/settings');
        const data = await response.json();
        setSettings(data);
      } catch (error) {
        console.error('Error fetching settings:', error);
      }
    };
    fetchSettings();
  }, []);

  // Function to check if a PDF exists
  const checkPdfExists = async (url: string): Promise<boolean> => {
    try {
      const response = await fetch(url, { method: 'HEAD' });
      return response.ok;
    } catch (error) {
      console.log(`File not found: ${url}`);
      return false;
    }
  };

  // Function to get the PDF URL based on language and category
  const getPdfUrl = async (category: MenuCategory) => {
    try {
      const response = await fetch(`/api/menu/url?category=${category.id}&language=${language}`);
      if (response.ok) {
        const data = await response.json();
        return data.url;
      }
      // If the endpoint returns an error, fall back to English
      return category.path.replace(/{language}/g, 'en');
    } catch (error) {
      console.error(`Error getting menu URL for ${category.id}:`, error);
      // Fall back to English on any error
      return category.path.replace(/{language}/g, 'en');
    }
  };

  // Update PDF URLs when language changes
  useEffect(() => {
    const updatePdfUrls = async () => {
      const newUrls: Record<string, string> = {};
      for (const category of menuCategories) {
        try {
          newUrls[category.id] = await getPdfUrl(category);
        } catch (error) {
          console.error(`Error getting PDF URL for ${category.id}:`, error);
          // Fallback to English if there's any error
          newUrls[category.id] = category.path.replace(/{language}/g, 'en');
        }
      }
      setPdfUrls(newUrls);
    };
    updatePdfUrls();
  }, [language, menuCategories]);

  // Update category names based on language and filter out special menu if disabled
  useEffect(() => {
    let categories = menuData.categories;
    
    // Filter out special menu if disabled
    if (!settings.specialMenuEnabled) {
      categories = categories.filter(category => category.id !== 'special');
    }
    
    setMenuCategories(categories.map(category => ({
      ...category,
      name: t(`menu.categories.${category.id}`)
    })));
  }, [language, t, settings.specialMenuEnabled]);

  return (
    <Box sx={{ p: 2 }}>
      <Typography 
        variant="h4" 
        gutterBottom 
        sx={{ 
          textAlign: 'center',
          fontWeight: 'bold',
          mb: 4
        }}
      >
        {t('menu.title')}
      </Typography>

      <Grid 
        container 
        spacing={3} 
        justifyContent={menuCategories.length % 2 === 1 ? 'center' : 'flex-start'}
      >
        {menuCategories.map((category) => (
          <Grid 
            item 
            xs={12} 
            md={6} 
            key={category.id}
            sx={{
              maxWidth: menuCategories.length % 2 === 1 ? '600px' : 'none'
            }}
          >
            <Box sx={{ 
              height: '100%',
              display: 'flex',
              flexDirection: 'column',
              borderRadius: 1,
              overflow: 'hidden'
            }}>
              <Typography 
                variant="h5" 
                sx={{ 
                  p: 2,
                  color: 'text.primary'
                }}
              >
                {category.name}
              </Typography>
              <Box sx={{ flex: 1, minHeight: '500px' }}>
                <PDFViewer pdfUrl={pdfUrls[category.id] || ''} />
              </Box>
            </Box>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
};

export default MenuPage; 
import { useEffect, useState, useCallback } from 'react';
import { Box, Typography, Paper, CircularProgress, Grid, Pagination, TextField, Button } from '@mui/material';
import { styled } from '@mui/material/styles';
import { useTranslation } from '../contexts/TranslationContext';
// If you have @mui/x-date-pickers installed, you can use:
// import { DatePicker } from '@mui/x-date-pickers/DatePicker';
// import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
// import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';

interface Event {
  title: string;
  date: string;
  start_time: string | null;
  end_time: string | null;
  desc: string;
  images?: string[];
  channel_message_id: number;
  visibility: string;
}

// Sticker style for 'Coming' label
const ComingSticker = styled('div')(({ theme }) => ({
  display: 'inline-block',
  background: theme.palette.success.main,
  color: theme.palette.common.white,
  borderRadius: 16,
  padding: '4px 16px',
  fontWeight: 700,
  fontSize: 18,
  marginBottom: 12,
  letterSpacing: 1,
  boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
  alignSelf: 'flex-start',
}));

const EventsPage = () => {
  const { t } = useTranslation();
  const [events, setEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [page, setPage] = useState(1);
  const EVENTS_PER_PAGE = 10;
  const [imageIndexes, setImageIndexes] = useState<{ [eventIdx: number]: number }>({});
  const [selectedDate, setSelectedDate] = useState<string | null>(null);

  const fetchEvents = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/events');
      if (!res.ok) throw new Error('Failed to fetch events');
      const data = await res.json();
      setEvents(data as Event[]);
    } catch (err) {
      setError('Failed to load events');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchEvents();
  }, [fetchEvents]);

  // Filter events by selected date (if any)
  const filteredEvents = selectedDate
    ? events.filter(event => event.date === selectedDate)
    : events;

  // Sort events by date descending
  const sortedEvents = filteredEvents.slice().sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  const pageCount = Math.ceil(sortedEvents.length / EVENTS_PER_PAGE);
  const pagedEvents = sortedEvents.slice((page - 1) * EVENTS_PER_PAGE, page * EVENTS_PER_PAGE);

  const handlePageChange = (_event: React.ChangeEvent<unknown>, value: number) => {
    setPage(value);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const formatEventTime = (event: Event) => {
    if (!event.start_time) return '';
    
    const timeFormat = t('events.time_format', {
      start_time: event.start_time,
      end_time: event.end_time ? t('events.end_time_format', { end_time: event.end_time }) : ''
    });
    // Ensure a space before 'at' if not present
    return timeFormat.startsWith('at') ? ` ${timeFormat}` : ` ${timeFormat}`;
  };

  const handleImageChange = (eventIdx: number, numImages: number, direction: 'left' | 'right') => {
    setImageIndexes(prev => {
      const current = prev[eventIdx] || 0;
      let next;
      if (direction === 'left') {
        next = (current - 1 + numImages) % numImages;
      } else {
        next = (current + 1) % numImages;
      }
      return { ...prev, [eventIdx]: next };
    });
  };

  return (
    <Box>
      <Typography variant="h4" gutterBottom sx={{ color: 'primary.main', fontWeight: 'bold', mb: 4 }}>
        {t('events.title')}
      </Typography>
      {/* Date Picker and Clear Button */}
      <Paper elevation={4} sx={{ p: 2, mb: 4, display: 'flex', alignItems: 'center', gap: 2, justifyContent: 'center', background: '#f5f5f5', borderRadius: 2 }}>
        {/* If you have @mui/x-date-pickers, use the DatePicker below. Otherwise, fallback to input type='date' */}
        {/*
        <LocalizationProvider dateAdapter={AdapterDateFns}>
          <DatePicker
            label={t('events.select_date')}
            value={selectedDate ? new Date(selectedDate) : null}
            onChange={date => {
              setSelectedDate(date ? date.toISOString().slice(0, 10) : null);
              setPage(1);
            }}
            renderInput={(params) => <TextField {...params} size="medium" sx={{ minWidth: 180, fontSize: 18 }} />}
          />
        </LocalizationProvider>
        */}
        <TextField
          label={t('events.select_date')}
          type="date"
          value={selectedDate || ''}
          onChange={e => {
            setSelectedDate(e.target.value || null);
            setPage(1);
          }}
          InputLabelProps={{ shrink: true }}
          sx={{ minWidth: 180, fontSize: 18, background: 'white', borderRadius: 1 }}
          inputProps={{ style: { fontSize: 18, height: 36 } }}
          size="small"
        />
        <Button
          variant="contained"
          color="secondary"
          onClick={() => {
            setSelectedDate(null);
            setPage(1);
          }}
          disabled={!selectedDate}
          size="medium"
          sx={{ height: 40, fontSize: 16, fontWeight: 600, px: 2.5, borderRadius: 1 }}
        >
          {t('events.clear') || 'Clear'}
        </Button>
      </Paper>
      {loading ? (
        <CircularProgress />
      ) : error ? (
        <Typography color="error">{error}</Typography>
      ) : events.length === 0 ? (
        <Typography>{t('events.no_events')}</Typography>
      ) : (
        <>
          <Grid container spacing={4} justifyContent="center">
            {pagedEvents.map((event, idx) => {
              // If this is the last event and the number of events is odd, make it full width
              const isLastSingle = pagedEvents.length % 2 === 1 && idx === pagedEvents.length - 1;
              // Check if event is today or in the future
              const eventDate = new Date(event.date);
              const now = new Date();
              eventDate.setHours(0,0,0,0);
              now.setHours(0,0,0,0);
              const isComing = eventDate.getTime() >= now.getTime();
              return (
                <Grid item xs={12} sm={isLastSingle ? 12 : 6} key={idx}>
                  <Paper sx={{ p: 6, mb: 2, minHeight: 600, maxWidth: 900, mx: 'auto' }} elevation={6}>
                    {isComing && <ComingSticker>{t('events.coming')}</ComingSticker>}
                    <Typography variant="h4" sx={{ color: 'primary.main', fontWeight: 700, mb: 2 }}>{event.title}</Typography>
                    <Typography variant="h5" sx={{ color: 'secondary.main', fontWeight: 600, mb: 2 }}>
                      {event.date}{formatEventTime(event)}
                    </Typography>
                    <Typography variant="body1" sx={{ mb: 4, fontSize: 20 }}
                      component="div"
                      dangerouslySetInnerHTML={{
                        __html: (event.desc || '').replace(/\n/g, '<br/>')
                      }}
                    />
                    {event.images && event.images.length > 0 && (
                      <Box sx={{ textAlign: 'center', position: 'relative', maxWidth: 600, mx: 'auto' }}>
                        <img
                          src={event.images[imageIndexes[idx] || 0]}
                          alt={event.title}
                          style={{ maxWidth: '100%', maxHeight: 500, borderRadius: 16 }}
                        />
                        {event.images.length > 1 && (
                          <>
                            <button
                              style={{
                                position: 'absolute',
                                top: '50%',
                                left: 0,
                                transform: 'translateY(-50%)',
                                background: 'rgba(0,0,0,0.3)',
                                color: 'white',
                                border: 'none',
                                borderRadius: '50%',
                                width: 40,
                                height: 40,
                                cursor: 'pointer',
                                fontSize: 24,
                              }}
                              onClick={() => handleImageChange(idx, event.images!.length, 'left')}
                              aria-label="Previous image"
                            >
                              {'<'}
                            </button>
                            <button
                              style={{
                                position: 'absolute',
                                top: '50%',
                                right: 0,
                                transform: 'translateY(-50%)',
                                background: 'rgba(0,0,0,0.3)',
                                color: 'white',
                                border: 'none',
                                borderRadius: '50%',
                                width: 40,
                                height: 40,
                                cursor: 'pointer',
                                fontSize: 24,
                              }}
                              onClick={() => handleImageChange(idx, event.images!.length, 'right')}
                              aria-label="Next image"
                            >
                              {'>'}
                            </button>
                          </>
                        )}
                        <Box sx={{ mt: 1 }}>
                          {event.images.map((_, i) => (
                            <span
                              key={i}
                              style={{
                                display: 'inline-block',
                                width: 10,
                                height: 10,
                                borderRadius: '50%',
                                background: (imageIndexes[idx] || 0) === i ? '#1976d2' : '#ccc',
                                margin: '0 4px',
                              }}
                            />
                          ))}
                        </Box>
                      </Box>
                    )}
                  </Paper>
                </Grid>
              );
            })}
          </Grid>
          {pageCount > 1 && (
            <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
              <Pagination
                count={pageCount}
                page={page}
                onChange={handlePageChange}
                color="primary"
                size="large"
              />
            </Box>
          )}
        </>
      )}
    </Box>
  );
};

export default EventsPage; 
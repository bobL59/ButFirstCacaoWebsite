import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import { Container } from '@mui/material';
import DishesPage from './dishes/DishesPage';
import ContactPage from './contact/ContactPage';
import EventsPage from './events/EventsPage';
import DrinksPage from './drinks/DrinksPage';
import MenuPage from './menu/MenuPage';
import DesertsPage from './deserts/DesertsPage';
import OthersPage from './others/OthersPage';
import DiscountsPage from './discounts/discountsPage';
import { LanguageProvider } from './contexts/LanguageContext';
import { TranslationProvider } from './contexts/TranslationContext';

const theme = createTheme({
  palette: {
    mode: 'light',
    primary: {
      main: '#611a07', // dark brown
      contrastText: '#fff',
    },
    secondary: {
      main: '#b05808', // orange-brown
      contrastText: '#fff',
    },
    background: {
      default: '#be9e75', // light beige
      paper: '#fff',
    },
    text: {
      primary: '#611a07', // dark brown for main text
      secondary: '#785433', // medium brown for secondary text
    },
    warning: {
      main: '#da8f2a', // gold
    },
    success: {
      main: '#5b6e00', // olive green
    },
    info: {
      main: '#be9e75', // light beige as info
    },
  },
  typography: {
    fontFamily: 'Inter, system-ui, Avenir, Helvetica, Arial, sans-serif',
  },
  components: {
    MuiCssBaseline: {
      styleOverrides: {
        body: {
          WebkitFontSmoothing: 'antialiased',
          MozOsxFontSmoothing: 'grayscale',
          textRendering: 'optimizeLegibility',
        },
      },
    },
  },
});

function App() {
  return (
    <LanguageProvider>
      <TranslationProvider>
        <ThemeProvider theme={theme}>
          <CssBaseline />
          <BrowserRouter>
            <Header />
            <Container sx={{ mt: 8, pt: 2 }}>
              <Routes>
                <Route path="/" element={<ContactPage />} />
                <Route path="/menu" element={<MenuPage />} />
                <Route path="/menu/:lang" element={<MenuPage />} />
                <Route path="/dishes" element={<DishesPage />} />
                <Route path="/drinks" element={<DrinksPage />} />
                <Route path="/events" element={<EventsPage />} />
                <Route path="/us" element={<ContactPage />} />
                <Route path="/deserts" element={<DesertsPage />} />
                <Route path="/others" element={<OthersPage />} />
                <Route path="/discounts" element={<DiscountsPage />} />
              </Routes>
            </Container>
          </BrowserRouter>
        </ThemeProvider>
      </TranslationProvider>
    </LanguageProvider>
  );
}

export default App; 
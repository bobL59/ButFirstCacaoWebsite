import { Typography, Grid, Card, CardMedia, CardContent, IconButton, Box, Container, Button, Stack} from '@mui/material';
import { useState, useRef, useEffect } from 'react';
import { useTranslation } from '../contexts/TranslationContext';
import ArrowBackIosNewIcon from '@mui/icons-material/ArrowBackIosNew';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import drinksData from '../data/drinks.json';

interface Drink {
  id: string;
  name: string;
  type: 'hot' | 'cold';
  description: string;
  images: string[];
  category: 'main' | 'summer' | 'winter';
  visible: boolean;
  inStock: boolean;
  price: number;
}

interface SeasonalStatus {
  summer: boolean;
  winter: boolean;
}

const DrinksPage = () => {
  const { t } = useTranslation();
  const [currentImages, setCurrentImages] = useState<{ [key: string]: number }>({});
  const [seasonalStatus, setSeasonalStatus] = useState<SeasonalStatus>({ summer: true, winter: true });
  const summerRef = useRef<HTMLDivElement>(null);
  const winterRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Fetch seasonal drinks visibility status
    fetch('/api/settings/seasonal-drinks')
      .then(res => res.json())
      .then(data => setSeasonalStatus(data))
      .catch(err => console.error('Error fetching seasonal status:', err));
  }, []);

  const handleNextImage = (drinkId: string, totalImages: number) => {
    setCurrentImages(prev => ({
      ...prev,
      [drinkId]: ((prev[drinkId] || 0) + 1) % totalImages
    }));
  };

  const handlePrevImage = (drinkId: string, totalImages: number) => {
    setCurrentImages(prev => ({
      ...prev,
      [drinkId]: ((prev[drinkId] || 0) - 1 + totalImages) % totalImages
    }));
  };

  const scrollToSection = (ref: React.RefObject<HTMLDivElement>) => {
    ref.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const renderDrinksGrid = (drinks: Drink[]) => (
    <Grid container spacing={4}>
      {drinks
        .filter(drink => drink.visible)
        .map((drink: Drink) => (
          <Grid item xs={12} sm={6} md={3} key={drink.id}>
            <Card 
              sx={{ 
                height: '100%', 
                display: 'flex', 
                flexDirection: 'column',
                borderRadius: '15px',
                boxShadow: '0 4px 20px rgba(0,0,0,0.1)',
                transition: 'transform 0.2s ease-in-out',
                '&:hover': {
                  transform: 'translateY(-5px)'
                },
                position: 'relative',
                opacity: drink.inStock ? 1 : 0.7
              }}
            >
              {!drink.inStock && (
                <Box
                  sx={{
                    position: 'absolute',
                    top: '50%',
                    left: '50%',
                    transform: 'translate(-50%, -50%) rotate(-45deg)',
                    backgroundColor: 'rgba(255, 0, 0, 0.8)',
                    color: 'white',
                    padding: '8px 40px',
                    zIndex: 1,
                    width: '200px',
                    textAlign: 'center',
                    fontWeight: 'bold',
                    fontSize: '1.2rem',
                    textTransform: 'uppercase',
                    letterSpacing: '2px'
                  }}
                >
                  Out of Stock
                </Box>
              )}
              <CardContent sx={{ p: 2, pb: '8px !important' }}>
                <Typography 
                  variant="h5" 
                  component="div" 
                  sx={{ 
                    fontWeight: 'bold',
                    textAlign: 'center',
                    mb: 1,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: 1
                  }}
                >
                  {drink.type === 'hot' ? '🔥' : '❄️'} {drink.name}
                </Typography>
                <Typography
                  variant="subtitle1"
                  sx={{
                    textAlign: 'center',
                    fontWeight: 'bold',
                    color: '#388e3c',
                    mb: 1
                  }}
                >
                  ₾{drink.price}
                </Typography>
              </CardContent>
              <Box sx={{ position: 'relative', flexGrow: 1 }}>
                <CardMedia
                  component="img"
                  height="250"
                  image={`/images/drinks/${drink.images[currentImages[drink.id] || 0]}`}
                  alt={drink.name}
                  sx={{
                    objectFit: 'cover',
                    borderTop: '1px solid rgba(0,0,0,0.1)',
                    borderBottom: '1px solid rgba(0,0,0,0.1)'
                  }}
                />
                {drink.images.length > 1 && (
                  <>
                    <IconButton
                      sx={{
                        position: 'absolute',
                        left: 8,
                        top: '50%',
                        transform: 'translateY(-50%)',
                        bgcolor: 'rgba(255, 255, 255, 0.9)',
                        '&:hover': { bgcolor: 'rgba(255, 255, 255, 1)' },
                        boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
                      }}
                      onClick={() => handlePrevImage(drink.id, drink.images.length)}
                    >
                      <ArrowBackIosNewIcon />
                    </IconButton>
                    <IconButton
                      sx={{
                        position: 'absolute',
                        right: 8,
                        top: '50%',
                        transform: 'translateY(-50%)',
                        bgcolor: 'rgba(255, 255, 255, 0.9)',
                        '&:hover': { bgcolor: 'rgba(255, 255, 255, 1)' },
                        boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
                      }}
                      onClick={() => handleNextImage(drink.id, drink.images.length)}
                    >
                      <ArrowForwardIosIcon />
                    </IconButton>
                  </>
                )}
              </Box>
              <CardContent sx={{ p: 2, pt: '8px !important' }}>
                <Typography 
                  variant="body2" 
                  color="text.secondary"
                  sx={{
                    textAlign: 'center',
                    fontSize: '0.95rem',
                    lineHeight: 1.5
                  }}
                  component="div"
                  dangerouslySetInnerHTML={{
                    __html: (drink.description || '').replace(/\n/g, '<br/>')
                  }}
                />
              </CardContent>
            </Card>
          </Grid>
        ))}
    </Grid>
  );

  const mainDrinks = (drinksData.drinks as Drink[]).filter(drink => drink.category === 'main');
  const summerDrinks = (drinksData.drinks as Drink[]).filter(drink => drink.category === 'summer');
  const winterDrinks = (drinksData.drinks as Drink[]).filter(drink => drink.category === 'winter');

  return (
    <Container maxWidth="xl" sx={{ py: 4 }}>
      <Typography 
        variant="h3" 
        gutterBottom 
        sx={{ 
          textAlign: 'center',
          fontWeight: 'bold',
          mb: 4,
          textTransform: 'uppercase',
          letterSpacing: '2px'
        }}
      >
        {t('drinks.title')}
      </Typography>

      <Stack 
        direction="row" 
        spacing={2} 
        justifyContent="center" 
        sx={{ mb: 6 }}
      >
        {seasonalStatus.summer && (
          <Button 
            variant="contained" 
            onClick={() => scrollToSection(summerRef)}
            sx={{ 
              bgcolor: '#FFA500',
              '&:hover': { bgcolor: '#FF8C00' }
            }}
          >
            Summer Drinks ☀️
          </Button>
        )}
        {seasonalStatus.winter && (
          <Button 
            variant="contained" 
            onClick={() => scrollToSection(winterRef)}
            sx={{ 
              bgcolor: '#4682B4',
              '&:hover': { bgcolor: '#357ABD' }
            }}
          >
            Winter Drinks ❄️
          </Button>
        )}
      </Stack>

      {renderDrinksGrid(mainDrinks)}

      {seasonalStatus.summer && (
        <Box ref={summerRef} sx={{ mt: 8 }}>
          <Typography 
            variant="h4" 
            sx={{ 
              mb: 4,
              fontWeight: 'bold',
              textAlign: 'center',
              color: '#FFA500',
              textShadow: '0 2px 4px rgba(255, 165, 0, 0.2)'
            }}
          >
            Summer Specials ☀️
          </Typography>
          {renderDrinksGrid(summerDrinks)}
        </Box>
      )}

      {seasonalStatus.winter && (
        <Box ref={winterRef} sx={{ mt: 8 }}>
          <Typography 
            variant="h4" 
            sx={{ 
              mb: 4,
              fontWeight: 'bold',
              textAlign: 'center',
              color: '#4682B4',
              textShadow: '0 2px 4px rgba(70, 130, 180, 0.2)'
            }}
          >
            Winter Specials ❄️
          </Typography>
          {renderDrinksGrid(winterDrinks)}
        </Box>
      )}
    </Container>
  );
};

export default DrinksPage; 
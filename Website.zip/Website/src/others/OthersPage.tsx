import { useState } from 'react';
import { Box, Typography, Tabs, Tab, Container, Card, CardContent, CardMedia, Chip, Stack } from '@mui/material';
import { useTranslation } from '../contexts/TranslationContext';
import othersData from '../data/others.json';

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

interface ProductCardProps {
  product: {
    id: string;
    name: string;
    flavors: Array<{
      id: string;
      name: string;
      description: string;
      price: number;
      image: string;
      available: boolean;
      visible?: boolean;
    }>;
  };
}

function ProductCard({ product }: ProductCardProps) {
  // Filter out flavors with visible: false (default to true if not present)
  const visibleFlavors = product.flavors.filter(flavor => flavor.visible !== false);
  const [selectedFlavor, setSelectedFlavor] = useState(visibleFlavors[0]);

  return (
    <Card sx={{ 
      display: 'flex', 
      mb: 3,
      height: '300px',
      '&:hover': {
        boxShadow: 6,
        transition: 'box-shadow 0.3s ease-in-out'
      }
    }}>
      <CardMedia
        component="img"
        sx={{ 
          width: 300,
          objectFit: 'cover'
        }}
        image={`/images/others/${selectedFlavor.image}`}
        alt={product.name}
      />
      <Box sx={{ display: 'flex', flexDirection: 'column', flex: 1 }}>
        <CardContent sx={{ flex: '1 0 auto', p: 3 }}>
          <Typography variant="h5" component="div" gutterBottom>
            {product.name}
          </Typography>
          
          <Stack direction="row" spacing={1} sx={{ mb: 2, flexWrap: 'wrap', gap: 1 }}>
            {visibleFlavors.map((flavor) => (
              <Chip
                key={flavor.id}
                label={flavor.name}
                onClick={() => setSelectedFlavor(flavor)}
                color={selectedFlavor.id === flavor.id ? "primary" : "default"}
                sx={{ 
                  '&:hover': {
                    backgroundColor: 'primary.light',
                    color: 'white'
                  }
                }}
              />
            ))}
          </Stack>

          <Typography variant="body1" color="text.secondary" paragraph
            component="div"
            dangerouslySetInnerHTML={{
              __html: (selectedFlavor.description || '').replace(/\n/g, '<br/>')
            }}
          />

          <Typography variant="h6" color="primary" sx={{ mt: 'auto' }}>
            {selectedFlavor.price.toFixed(2)} GEL
          </Typography>
        </CardContent>
      </Box>
    </Card>
  );
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`category-tabpanel-${index}`}
      aria-labelledby={`category-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ py: 3 }}>
          {children}
        </Box>
      )}
    </div>
  );
}

function OthersPage() {
  const { t } = useTranslation();
  const [selectedCategory, setSelectedCategory] = useState(0);
  const visibleCategories = othersData.categories.filter(category => category.visible);

  const handleCategoryChange = (event: React.SyntheticEvent, newValue: number) => {
    setSelectedCategory(newValue);
  };

  return (
    <Container maxWidth="lg">
      <Box sx={{ 
        mt: 4, 
        mb: 2,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center'
      }}>
        <Box sx={{ 
          width: '100%',
          maxWidth: '1000px',
          borderBottom: 1, 
          borderColor: 'divider',
          '& .MuiTabs-root': {
            minHeight: '80px',
          },
          '& .MuiTabs-flexContainer': {
            justifyContent: 'center',
          }
        }}>
          <Tabs
            value={selectedCategory}
            onChange={handleCategoryChange}
            variant="scrollable"
            scrollButtons="auto"
            aria-label="category tabs"
            centered
            sx={{
              '& .MuiTab-root': {
                textTransform: 'none',
                fontSize: '1.3rem',
                fontWeight: 500,
                minWidth: 200,
                padding: '16px 32px',
                transition: 'all 0.3s ease',
                '&:hover': {
                  backgroundColor: 'rgba(0, 0, 0, 0.04)',
                },
                '&.Mui-selected': {
                  fontWeight: 600,
                }
              },
              '& .MuiTabs-indicator': {
                height: 3,
              }
            }}
          >
            {visibleCategories.map((category, index) => (
              <Tab
                key={category.id}
                label={t(`others.categories.${category.id}`)}
                id={`category-tab-${index}`}
                aria-controls={`category-tabpanel-${index}`}
              />
            ))}
          </Tabs>
        </Box>
      </Box>

      {visibleCategories.map((category, index) => (
        <TabPanel key={category.id} value={selectedCategory} index={index}>
          <Box sx={{ px: 2 }}>
            {othersData.products
              .filter(product => product.categoryId === category.id && product.visible)
              .map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
          </Box>
        </TabPanel>
      ))}
    </Container>
  );
}

export default OthersPage;

import { AppBar, Toolbar, Typography, Button, Box } from '@mui/material';
import { Link as RouterLink } from 'react-router-dom';
import LanguageSelector from './LanguageSelector';
import logo from '../../images/common/logo.png';
import { useTranslation } from '../contexts/TranslationContext';

const Header = () => {
  const { t } = useTranslation();

  return (
    <AppBar 
      position="fixed" 
      sx={{ 
        width: '100%',
        top: 0,
        left: 0,
        right: 0,
        zIndex: (theme) => theme.zIndex.drawer + 1,
      }}
    >
      <Toolbar sx={{ width: '100%', maxWidth: '100%' }}>
        <Box sx={{ display: 'flex', alignItems: 'center', flexGrow: 1 }}>
          <Box component={RouterLink} to="/" sx={{ display: 'flex', alignItems: 'center', mr: 2 }}>
            <img src={logo} alt="But First Cacao Logo" style={{ height: 48, width: 48, marginRight: 12 }} />
          </Box>
          <Typography
            variant="h6"
            component={RouterLink}
            to="/"
            sx={{
              textDecoration: 'none',
              color: 'inherit',
              fontWeight: 'bold',
            }}
          >
            {t('header.brand')}
          </Typography>
        </Box>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
          <Button
            color="inherit"
            component={RouterLink}
            to="/menu"
            sx={{ mx: 1 }}
          >
            {t('header.navigation.menu')}
          </Button>
          
          <Button
            color="inherit"
            component={RouterLink}
            to="/dishes"
            sx={{ mx: 1 }}
          >
            {t('header.navigation.dishes')}
          </Button>
          <Button
            color="inherit"
            component={RouterLink}
            to="/deserts"
            sx={{ mx: 1 }}
          >
            {t('header.navigation.deserts')}
          </Button>
          <Button
            color="inherit"
            component={RouterLink}
            to="/drinks"
            sx={{ mx: 1 }}
          >
            {t('header.navigation.drinks')}
          </Button>
          <Button
            color="inherit"
            component={RouterLink}
            to="/others"
            sx={{ mx: 1 }}
          >
            {t('header.navigation.others')}
          </Button>
          <Button
            color="inherit"
            component={RouterLink}
            to="/events"
            sx={{ mx: 1 }}
          >
            {t('header.navigation.events')}
          </Button>
          <Button
            color="inherit"
            component={RouterLink}
            to="/discounts"
            sx={{ mx: 1 }}
          >
            {t('header.navigation.discounts')}
          </Button>
          <Button
            color="inherit"
            component={RouterLink}
            to="/us"
            sx={{ mx: 1 }}
          >
            {t('header.navigation.us')}
          </Button>
          <LanguageSelector />
        </Box>
      </Toolbar>
    </AppBar>
  );
};

export default Header; 
import { useState, useEffect } from 'react';
import { Box, CircularProgress, Typography } from '@mui/material';
import { getDocument, GlobalWorkerOptions, version, PDFDocumentProxy } from 'pdfjs-dist';

// Set up the worker for PDF.js
GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${version}/pdf.worker.min.js`;

interface PDFViewerProps {
  pdfUrl: string;
}

const PDFViewer = ({ pdfUrl }: PDFViewerProps) => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [pdfDocument, setPdfDocument] = useState<PDFDocumentProxy | null>(null);

  useEffect(() => {
    let isMounted = true;
    let currentPdf: PDFDocumentProxy | null = null;

    const renderPDF = async () => {
      try {
        setLoading(true);
        setError(null);
        setImageUrl(null);

        // Cleanup previous PDF if it exists
        if (pdfDocument) {
          await pdfDocument.destroy();
          setPdfDocument(null);
        }

        // Load the PDF
        const loadingTask = getDocument(pdfUrl);
        currentPdf = await loadingTask.promise;
        
        if (!isMounted) return;
        setPdfDocument(currentPdf);

        // Get the first page
        const page = await currentPdf.getPage(1);
        
        // Set scale for better quality
        const scale = 2.0;
        const viewport = page.getViewport({ scale });

        // Prepare canvas
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        canvas.height = viewport.height;
        canvas.width = viewport.width;

        if (!context) {
          throw new Error('Could not get canvas context');
        }

        // Render PDF page to canvas
        const renderContext = {
          canvasContext: context,
          viewport: viewport
        };

        await page.render(renderContext).promise;

        if (!isMounted) return;

        // Convert canvas to image URL
        const imageUrl = canvas.toDataURL('image/jpeg', 0.95);
        setImageUrl(imageUrl);
        setLoading(false);
      } catch (error) {
        console.error('Error rendering PDF:', error);
        if (isMounted) {
          setError(`Failed to render PDF: ${error instanceof Error ? error.message : 'Unknown error'}`);
          setLoading(false);
        }
      }
    };

    renderPDF();

    // Cleanup function
    return () => {
      isMounted = false;
      if (currentPdf) {
        currentPdf.destroy().catch(console.error);
      }
    };
  }, [pdfUrl]); // Only re-run when pdfUrl changes

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
        <CircularProgress />
        <Typography sx={{ ml: 2 }}>Loading PDF...</Typography>
      </Box>
    );
  }

  if (error) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
        <Typography color="error">
          {error}
          <br />
          <small>URL: {pdfUrl}</small>
        </Typography>
      </Box>
    );
  }

  return (
    <Box sx={{ 
      width: '100%',
      display: 'flex',
      justifyContent: 'center',
      '& img': {
        maxWidth: '100%',
        height: 'auto',
        boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
        borderRadius: '8px',
      }
    }}>
      {imageUrl && (
        <img 
          src={imageUrl} 
          alt="PDF Preview" 
          style={{ maxHeight: '800px' }}
        />
      )}
    </Box>
  );
};

export default PDFViewer; 
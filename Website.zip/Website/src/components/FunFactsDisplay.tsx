import { useState, useEffect } from 'react';
import { Paper, Typography, Box } from '@mui/material';
import { motion, AnimatePresence } from 'framer-motion';
import funFactsData from '../data/funFacts.json';

const FunFactsDisplay = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    if (funFactsData.length === 0) return;

    const timer = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % funFactsData.length);
    }, 8000); // Change fact every 8 seconds

    return () => clearInterval(timer);
  }, []);

  if (funFactsData.length === 0) {
    return null; // Don't show anything if there are no facts
  }

  return (
    <Paper 
      elevation={3} 
      sx={{ 
        p: 3, 
        mt: 4,
        mb: 4,
        backgroundColor: 'primary.main',
        color: 'white',
        position: 'relative',
        overflow: 'hidden',
        minHeight: '120px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }}
    >
      <AnimatePresence mode="wait">
        <motion.div
          key={currentIndex}
          initial={{ x: 100, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          exit={{ x: -100, opacity: 0 }}
          transition={{ duration: 0.5 }}
          style={{ width: '100%' }}
        >
          <Box sx={{ textAlign: 'center' }}>
            <Typography variant="h6" sx={{ mb: 1, fontWeight: 'bold' }}>
              {funFactsData[currentIndex].title}
            </Typography>
            <Typography variant="body1">
              {funFactsData[currentIndex].text}
            </Typography>
          </Box>
        </motion.div>
      </AnimatePresence>
    </Paper>
  );
};

export default FunFactsDisplay; 
import { Box, Grid, Typography, Card, CardMedia, CardContent, IconButton, Container } from '@mui/material';
// import { useTranslation } from '../contexts/TranslationContext';
import dishesData from '../data/dishesData.json';
import { useState } from 'react';
import ArrowBackIosNewIcon from '@mui/icons-material/ArrowBackIosNew';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';

interface Dish {
  id: number;
  images: string[];
  name?: string;
  titleKey?: string;
  price: string | number;
  visible?: boolean;
  inStock?: boolean;
  description?: string;
}

const DishesPage = () => {
  const [currentImages, setCurrentImages] = useState<{ [key: number]: number }>({});

  const handleNextImage = (dishId: number, totalImages: number) => {
    setCurrentImages(prev => ({
      ...prev,
      [dishId]: ((prev[dishId] || 0) + 1) % totalImages
    }));
  };

  const handlePrevImage = (dishId: number, totalImages: number) => {
    setCurrentImages(prev => ({
      ...prev,
      [dishId]: ((prev[dishId] || 0) - 1 + totalImages) % totalImages
    }));
  };

  return (
    <Container maxWidth="xl" sx={{ py: 4 }}>
      <Typography variant="h4" gutterBottom sx={{ color: 'primary.main', fontWeight: 'bold', mb: 4, textAlign: 'center', textTransform: 'uppercase', letterSpacing: '2px' }}>
        Dishes
      </Typography>
      <Grid container spacing={4}>
        {(dishesData as { dishes: Dish[] }).dishes
          .filter((dish: Dish) => dish.visible !== false)
          .map((dish: Dish) => {
            const imagesCount = dish.images.length;
            const currentIdx = currentImages[dish.id] || 0;
            return (
              <Grid item xs={12} sm={6} md={4} key={dish.id}>
                <Card
                  sx={{
                    height: '100%',
                    display: 'flex',
                    flexDirection: 'column',
                    borderRadius: '15px',
                    boxShadow: '0 4px 20px rgba(0,0,0,0.1)',
                    transition: 'transform 0.2s ease-in-out',
                    '&:hover': { transform: 'translateY(-5px)' },
                    position: 'relative',
                    opacity: dish.inStock ? 1 : 0.7
                  }}
                >
                  <CardContent sx={{ p: 2, pb: '8px !important' }}>
                    <Typography
                      variant="h5"
                      component="div"
                      sx={{ fontWeight: 'bold', textAlign: 'center', mb: 1 }}
                    >
                      {dish.name || dish.titleKey}
                      {!dish.inStock && (
                        <Typography
                          component="span"
                          sx={{
                            display: 'block',
                            fontSize: '0.8rem',
                            color: 'error.main',
                            mt: 0.5
                          }}
                        >
                          ⏳ Not Available Now
                        </Typography>
                      )}
                      {dish.inStock && (
                        <Typography
                          component="span"
                          sx={{
                            display: 'block',
                            fontSize: '0.8rem',
                            color: 'success.main',
                            mt: 0.5
                          }}
                        >
                          ✅ Available Now
                        </Typography>
                      )}
                    </Typography>
                  </CardContent>
                  <Box sx={{ position: 'relative', flexGrow: 1 }}>
                    {imagesCount > 0 ? (
                      <>
                        <CardMedia
                          component="img"
                          height="250"
                          image={"/images/dishes/" + dish.images[currentIdx]}
                          alt={dish.name || dish.titleKey || `Dish ${dish.id}`}
                          sx={{
                            objectFit: 'cover',
                            borderTop: '1px solid rgba(0,0,0,0.1)',
                            borderBottom: '1px solid rgba(0,0,0,0.1)'
                          }}
                        />
                        {imagesCount > 1 && (
                          <>
                            <IconButton
                              sx={{
                                position: 'absolute',
                                left: 8,
                                top: '50%',
                                transform: 'translateY(-50%)',
                                bgcolor: 'rgba(255, 255, 255, 0.7)',
                                '&:hover': { bgcolor: 'rgba(255, 255, 255, 1)' },
                                boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
                              }}
                              onClick={() => handlePrevImage(dish.id, imagesCount)}
                            >
                              <ArrowBackIosNewIcon />
                            </IconButton>
                            <IconButton
                              sx={{
                                position: 'absolute',
                                right: 8,
                                top: '50%',
                                transform: 'translateY(-50%)',
                                bgcolor: 'rgba(255, 255, 255, 0.7)',
                                '&:hover': { bgcolor: 'rgba(255, 255, 255, 1)' },
                                boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
                              }}
                              onClick={() => handleNextImage(dish.id, imagesCount)}
                            >
                              <ArrowForwardIosIcon />
                            </IconButton>
                          </>
                        )}
                      </>
                    ) : (
                      <Box
                        sx={{
                          height: 250,
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          bgcolor: 'grey.100',
                          borderTop: '1px solid rgba(0,0,0,0.1)',
                          borderBottom: '1px solid rgba(0,0,0,0.1)'
                        }}
                      >
                        <Typography color="text.secondary">
                          No Image Available
                        </Typography>
                      </Box>
                    )}
                  </Box>
                  <CardContent sx={{ p: 2, pt: '8px !important' }}>
                    {dish.description && (
                      <Typography
                        variant="body2"
                        color="text.secondary"
                        sx={{ textAlign: 'center', fontSize: '0.95rem', lineHeight: 1.5, mb: 1 }}
                        component="div"
                        dangerouslySetInnerHTML={{
                          __html: (dish.description || '').replace(/\n/g, '<br/>')
                        }}
                      />
                    )}
                    <Typography
                      variant="h6"
                      sx={{ textAlign: 'center', color: 'primary.main', fontWeight: 'bold' }}
                    >
                      {dish.price} ₾
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>
            );
          })}
      </Grid>
    </Container>
  );
};

export default DishesPage; 
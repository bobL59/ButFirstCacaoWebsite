import React, { createContext, useContext, useState, useEffect } from 'react';
import { useLanguage } from './LanguageContext';

// Import all translation files
import enTranslations from '../translations/en.json';
import kaTranslations from '../translations/ka.json';
import ruTranslations from '../translations/ru.json';
import frTranslations from '../translations/fr.json';
import hiTranslations from '../translations/hi.json';
import ukTranslations from '../translations/uk.json';
import deTranslations from '../translations/de.json';
import trTranslations from '../translations/tr.json';
import jaTranslations from '../translations/ja.json';
import zhTranslations from '../translations/zh.json';

// Type for our translations
type Translations = {
  [key: string]: any;
};

// Available languages and their translations
const translations: { [key: string]: Translations } = {
  en: enTranslations,
  ka: kaTranslations,
  ru: ruTranslations,
  fr: frTranslations,
  hi: hiTranslations,
  uk: ukTranslations,
  de: deTranslations,
  tr: trTranslations,
  ja: jaTranslations,
  zh: zhTranslations
};

interface TranslationContextType {
  t: (key: string, params?: { [key: string]: string }) => string;
}

const TranslationContext = createContext<TranslationContextType | undefined>(undefined);

export const TranslationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { language } = useLanguage();
  const [currentTranslations, setCurrentTranslations] = useState<Translations>(translations.en);

  useEffect(() => {
    setCurrentTranslations(translations[language] || translations.en);
  }, [language]);

  const t = (key: string, params?: { [key: string]: string }): string => {
    const keys = key.split('.');
    let value: any = currentTranslations;

    for (const k of keys) {
      if (value && typeof value === 'object' && k in value) {
        value = value[k];
      } else {
        return key; // Return the key if translation is not found
      }
    }

    if (typeof value !== 'string') {
      return key;
    }

    // Replace parameters in the translation string
    if (params) {
      return Object.entries(params).reduce((str, [key, val]) => {
        return str.replace(new RegExp(`{${key}}`, 'g'), val);
      }, value);
    }

    return value;
  };

  return (
    <TranslationContext.Provider value={{ t }}>
      {children}
    </TranslationContext.Provider>
  );
};

export const useTranslation = () => {
  const context = useContext(TranslationContext);
  if (context === undefined) {
    throw new Error('useTranslation must be used within a TranslationProvider');
  }
  return context;
}; 
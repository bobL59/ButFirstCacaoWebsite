import { Box, Typography, Container, Paper, Button, Stack, Grid, Dialog, DialogContent } from '@mui/material';
import PhoneIcon from '@mui/icons-material/Phone';
import InstagramIcon from '@mui/icons-material/Instagram';
import TelegramIcon from '@mui/icons-material/Telegram';
import MapIcon from '@mui/icons-material/Map';
import EmailIcon from '@mui/icons-material/Email';
import Carousel from 'react-material-ui-carousel';
import { useState, useEffect } from 'react';
import { useTranslation } from '../contexts/TranslationContext';
import FunFactsDisplay from '../components/FunFactsDisplay';
import galleryData from '../data/the_bar.json';

interface GalleryImageInput {
  id: number;
  title: string;
  src: string;
}

interface GalleryImage {
  id: number;
  alt: string;
  src: string;
}

// Use the gallery data for carousel images
const carouselImages: GalleryImage[] = galleryData.images.map((image: GalleryImageInput) => ({
  src: image.src,
  alt: image.title,
  id: image.id
}));

const ContactPage = () => {
  const { t } = useTranslation();
  const address = "37 Alexander Griboedov St, Tbilisi 1037";
  const googleMapsUrl = `https://www.google.com/maps?q=${encodeURIComponent(address)}&output=embed`;
  const phoneNumber = "+995 579185903";
  const instagramUrl = "https://www.instagram.com/but_first_cacao";
  const telegramUrl = "https://t.me/ButFirstCacao";
  const emailAddress = "but1cacao@gmail.com";
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  const handleImageClick = (imageSrc: string) => {
    setSelectedImage(imageSrc);
  };

  const handleCloseDialog = () => {
    setSelectedImage(null);
  };

  return (
    <div>
      <Typography 
        variant="h4" 
        gutterBottom 
        sx={{ 
          textAlign: 'center',
          fontWeight: 'bold'
        }}
      >
        {t('contact.title')}
      </Typography>

      {/* Fun Facts Display */}
      <FunFactsDisplay />
      
      <Grid container spacing={4}>
        {/* Map Column */}
        <Grid item xs={12} md={6}>
          <Paper elevation={3} sx={{ p: 3, height: '100%' }}>
            <Typography variant="h6" gutterBottom sx={{ color: 'primary.main' }}>
              {t('contact.location.title')}
            </Typography>
            <Typography variant="body1" paragraph>
              {address}
            </Typography>
            
            <Box sx={{ mt: 2, height: '400px', width: '100%' }}>
              <iframe
                title="But First Cacao Location"
                width="100%"
                height="100%"
                frameBorder="0"
                style={{ border: 0 }}
                src={googleMapsUrl}
                allowFullScreen
              />
            </Box>
          </Paper>
        </Grid>

        {/* Description Column */}
        <Grid item xs={12} md={6}>
          <Paper elevation={3} sx={{ p: 3, height: '100%' }}>
            <Typography variant="h6" gutterBottom sx={{ color: 'primary.main' }}>
              {t('contact.about.title')}
            </Typography>
            <Typography variant="body1" paragraph>
              {t('contact.about.description')}
            </Typography>
            <Typography variant="body1" paragraph>
              {t('contact.about.description2')}
            </Typography>
            <Typography variant="body1" paragraph>
              {t('contact.about.description3')}
            </Typography>
          </Paper>
        </Grid>
      </Grid>

      {/* Carousel Section */}
      <Box sx={{ my: 4, position: 'relative' }}>
        <Paper elevation={3} sx={{ p: 2, overflow: 'hidden' }}>
          <Box>
            <Carousel
              animation="slide"
              interval={5000}
              duration={500}
              indicators={true}
              navButtonsAlwaysVisible={true}
              sx={{ 
                height: '300px',
                '& .MuiCarousel-root': {
                  height: '100%',
                },
                '& .MuiCarousel-slide': {
                  display: 'flex',
                  justifyContent: 'center',
                  alignItems: 'center',
                  gap: '20px',
                },
                '& .MuiButtonBase-root': {
                  backgroundColor: 'rgba(97, 26, 7, 0.8) !important',
                  color: 'white !important',
                  '&:hover': {
                    backgroundColor: 'rgba(97, 26, 7, 0.9) !important',
                  }
                }
              }}
              navButtonsProps={{
                style: {
                  borderRadius: '50%',
                  padding: '10px',
                  margin: '0 10px',
                }
              }}
            >
              {Array.from({ length: carouselImages.length }).map((_, index) => {
                // Calculate the three images to show for this slide
                const images = [
                  carouselImages[index],
                  carouselImages[(index + 1) % carouselImages.length],
                  carouselImages[(index + 2) % carouselImages.length]
                ];

                return (
                  <Box
                    key={index}
                    sx={{
                      display: 'flex',
                      justifyContent: 'center',
                      alignItems: 'center',
                      gap: '20px',
                      width: '100%',
                    }}
                  >
                    {images.map((image, imgIndex) => (
                      <Box
                        key={imgIndex}
                        sx={{
                          height: '300px',
                          width: 'calc(33.33% - 14px)',
                          display: 'flex',
                          justifyContent: 'center',
                          alignItems: 'center',
                          cursor: 'pointer',
                          overflow: 'hidden',
                        }}
                        onClick={() => handleImageClick(image.src)}
                      >
                        <img
                          src={image.src}
                          alt={image.alt}
                          style={{
                            maxHeight: '100%',
                            maxWidth: '100%',
                            objectFit: 'contain',
                            borderRadius: '8px',
                            boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
                          }}
                        />
                      </Box>
                    ))}
                  </Box>
                );
              })}
            </Carousel>
          </Box>
        </Paper>
      </Box>

      {/* Contact Buttons Section */}
      <Box sx={{ display: 'flex', justifyContent: 'center' }}>
        <Paper elevation={3} sx={{ p: 3, width: '100%', maxWidth: '600px' }}>
          <Typography variant="h6" gutterBottom sx={{ color: 'primary.main', textAlign: 'center' }}>
            {t('contact.get_in_touch.title')}
          </Typography>
          
          <Stack spacing={2} sx={{ mt: 2 }}>
            <Button
              variant="contained"
              startIcon={<PhoneIcon />}
              href={`tel:${phoneNumber}`}
              sx={{ 
                backgroundColor: 'primary.main',
                '&:hover': { backgroundColor: 'primary.dark' }
              }}
            >
              {t('contact.get_in_touch.call_us', { phone: phoneNumber })}
            </Button>

            <Button
              variant="contained"
              startIcon={<EmailIcon />}
              href={`mailto:${emailAddress}`}
              sx={{ 
                backgroundColor: '#EA4335',
                '&:hover': { backgroundColor: '#D33426' }
              }}
            >
              {t('contact.get_in_touch.email_us', { email: emailAddress })}
            </Button>

            <Button
              variant="contained"
              startIcon={<InstagramIcon />}
              href={instagramUrl}
              target="_blank"
              sx={{ 
                backgroundColor: '#E1306C',
                '&:hover': { backgroundColor: '#C13584' }
              }}
            >
              {t('contact.get_in_touch.instagram')}
            </Button>

            <Button
              variant="contained"
              startIcon={<TelegramIcon />}
              href={telegramUrl}
              target="_blank"
              sx={{ 
                backgroundColor: '#0088cc',
                '&:hover': { backgroundColor: '#006699' }
              }}
            >
              {t('contact.get_in_touch.telegram')}
            </Button>

            <Button
              variant="contained"
              startIcon={<MapIcon />}
              href={`https://www.google.com/maps?q=${encodeURIComponent(address)}`}
              target="_blank"
              sx={{ 
                backgroundColor: '#34A853',
                '&:hover': { backgroundColor: '#2E8B57' }
              }}
            >
              {t('contact.get_in_touch.maps')}
            </Button>
          </Stack>

          <Typography variant="body1" sx={{ mt: 3, textAlign: 'center' }}>
            {t('contact.get_in_touch.opening_hours')}
          </Typography>
        </Paper>
      </Box>

      {/* Image Dialog */}
      <Dialog
        open={!!selectedImage}
        onClose={handleCloseDialog}
        maxWidth="lg"
        fullWidth
        PaperProps={{
          sx: {
            maxHeight: '90vh',
            margin: '20px',
          }
        }}
      >
        <DialogContent sx={{ 
          padding: 0,
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          minHeight: '70vh',
          '& img': {
            maxWidth: '100%',
            maxHeight: '90vh',
            objectFit: 'contain',
            borderRadius: '8px',
          }
        }}>
          {selectedImage && (
            <img
              src={selectedImage}
              alt="Enlarged view"
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ContactPage; 
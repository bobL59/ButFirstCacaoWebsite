import { Typography, Grid, Card, CardMedia, CardContent, IconButton, Box, Container } from '@mui/material';
import { useState } from 'react';
import { useTranslation } from '../contexts/TranslationContext';
import ArrowBackIosNewIcon from '@mui/icons-material/ArrowBackIosNew';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import desertsData from '../data/deserts.json';

interface Desert {
    id: string;
    name: string;
    description: string;
    price: number;
    images: string[];
    visible: boolean;
    available: boolean;
}

const DesertsPage = () => {
    const { t } = useTranslation();
    const [currentImages, setCurrentImages] = useState<{ [key: string]: number }>({});

    const handleNextImage = (desertId: string, totalImages: number) => {
        setCurrentImages(prev => ({
            ...prev,
            [desertId]: ((prev[desertId] || 0) + 1) % totalImages
        }));
    };

    const handlePrevImage = (desertId: string, totalImages: number) => {
        setCurrentImages(prev => ({
            ...prev,
            [desertId]: ((prev[desertId] || 0) - 1 + totalImages) % totalImages
        }));
    };

    // Filter out invisible deserts
    const visibleDeserts = (desertsData as Desert[]).filter(desert => desert.visible);

    return (
        <Container maxWidth="xl" sx={{ py: 4 }}>
            <Typography 
                variant="h3" 
                gutterBottom 
                sx={{ 
                    textAlign: 'center',
                    fontWeight: 'bold',
                    mb: 4,
                    textTransform: 'uppercase',
                    letterSpacing: '2px'
                }}
            >
                {t('deserts.title')}
            </Typography>

            <Grid container spacing={4}>
                {visibleDeserts.map((desert: Desert) => (
                    <Grid item xs={12} sm={6} md={3} key={desert.id}>
                        <Card 
                            sx={{ 
                                height: '100%', 
                                display: 'flex', 
                                flexDirection: 'column',
                                borderRadius: '15px',
                                boxShadow: '0 4px 20px rgba(0,0,0,0.1)',
                                transition: 'transform 0.2s ease-in-out',
                                '&:hover': {
                                    transform: 'translateY(-5px)'
                                }
                            }}
                        >
                            <CardContent sx={{ p: 2, pb: '8px !important' }}>
                                <Typography 
                                    variant="h5" 
                                    component="div" 
                                    sx={{ 
                                        fontWeight: 'bold',
                                        textAlign: 'center',
                                        mb: 1
                                    }}
                                >
                                    {desert.name}
                                    {!desert.available && (
                                        <Typography 
                                            component="span" 
                                            sx={{ 
                                                display: 'block',
                                                fontSize: '0.8rem',
                                                color: 'error.main',
                                                mt: 0.5
                                            }}
                                        >
                                            ⏳ Not Available Now
                                        </Typography>
                                    )}
                                    {desert.available && (
                                        <Typography 
                                            component="span" 
                                            sx={{ 
                                                display: 'block',
                                                fontSize: '0.8rem',
                                                color: 'success.main',
                                                mt: 0.5
                                            }}
                                        >
                                            ✅ Available Now
                                        </Typography>
                                    )}
                                </Typography>
                            </CardContent>
                            <Box sx={{ position: 'relative', flexGrow: 1 }}>
                                {desert.images.length > 0 ? (
                                    <>
                                        <CardMedia
                                            component="img"
                                            height="250"
                                            image={`/images/deserts/${desert.images[currentImages[desert.id] || 0]}`}
                                            alt={desert.name}
                                            sx={{
                                                objectFit: 'cover',
                                                borderTop: '1px solid rgba(0,0,0,0.1)',
                                                borderBottom: '1px solid rgba(0,0,0,0.1)'
                                            }}
                                        />
                                        {desert.images.length > 1 && (
                                            <>
                                                <IconButton
                                                    sx={{
                                                        position: 'absolute',
                                                        left: 8,
                                                        top: '50%',
                                                        transform: 'translateY(-50%)',
                                                        bgcolor: 'rgba(255, 255, 255, 0.9)',
                                                        '&:hover': { bgcolor: 'rgba(255, 255, 255, 1)' },
                                                        boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
                                                    }}
                                                    onClick={() => handlePrevImage(desert.id, desert.images.length)}
                                                >
                                                    <ArrowBackIosNewIcon />
                                                </IconButton>
                                                <IconButton
                                                    sx={{
                                                        position: 'absolute',
                                                        right: 8,
                                                        top: '50%',
                                                        transform: 'translateY(-50%)',
                                                        bgcolor: 'rgba(255, 255, 255, 0.9)',
                                                        '&:hover': { bgcolor: 'rgba(255, 255, 255, 1)' },
                                                        boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
                                                    }}
                                                    onClick={() => handleNextImage(desert.id, desert.images.length)}
                                                >
                                                    <ArrowForwardIosIcon />
                                                </IconButton>
                                            </>
                                        )}
                                    </>
                                ) : (
                                    <Box
                                        sx={{
                                            height: 250,
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'center',
                                            bgcolor: 'grey.100',
                                            borderTop: '1px solid rgba(0,0,0,0.1)',
                                            borderBottom: '1px solid rgba(0,0,0,0.1)'
                                        }}
                                    >
                                        <Typography color="text.secondary">
                                            No Image Available
                                        </Typography>
                                    </Box>
                                )}
                            </Box>
                            <CardContent sx={{ p: 2, pt: '8px !important' }}>
                                <Typography 
                                    variant="body2" 
                                    color="text.secondary"
                                    sx={{
                                        textAlign: 'center',
                                        fontSize: '0.95rem',
                                        lineHeight: 1.5,
                                        mb: 1
                                    }}
                                    component="div"
                                    dangerouslySetInnerHTML={{
                                        __html: (desert.description || '').replace(/\n/g, '<br/>')
                                    }}
                                />
                                <Typography 
                                    variant="h6" 
                                    sx={{ 
                                        textAlign: 'center',
                                        color: 'primary.main',
                                        fontWeight: 'bold'
                                    }}
                                >
                                    {desert.price} Lari
                                </Typography>
                            </CardContent>
                        </Card>
                    </Grid>
                ))}
            </Grid>
        </Container>
    );
};

export default DesertsPage; 
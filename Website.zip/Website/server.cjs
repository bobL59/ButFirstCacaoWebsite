const express = require('express');
const fs = require('fs');
const path = require('path');
const cors = require('cors');
const https = require('https');
const http = require('http');
const fetch = require('node-fetch');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3001;
const WORKSPACE_ROOT = path.resolve(__dirname, '..');
const EVENTS_FILE = path.join(__dirname, 'src', 'data', 'events.json');
const FUN_FACTS_FILE = path.join(__dirname, 'src', 'data', 'funFacts.json');
const SETTINGS_FILE = path.join(__dirname, 'settings.json');
const API_SECRET = process.env.EVENT_API_SECRET || 'changeme';
const IMAGES_DIR = path.join(WORKSPACE_ROOT, 'Website', 'images');
const EVENTS_IMAGES_DIR = path.join(IMAGES_DIR, 'events');
const MENU_DIR = path.join(IMAGES_DIR, 'menu');
const DRINKS_FILE = path.join(__dirname, 'src/data/drinks.json');
const DRINKS_IMAGES_DIR = path.join(IMAGES_DIR, 'drinks');
const DESERTS_FILE = path.join(__dirname, 'src/data/deserts.json');
const DESERTS_IMAGES_DIR = path.join(WORKSPACE_ROOT, 'Website', 'images', 'deserts');
const DISHES_FILE = path.join(__dirname, 'src/data/dishesData.json');
const DISHES_IMAGES_DIR = path.join(IMAGES_DIR, 'dishes');
const DISCOUNTS_FILE = path.join(__dirname, 'src/data/discounts.json');

// Ensure images directories exist
if (!fs.existsSync(IMAGES_DIR)) {
  fs.mkdirSync(IMAGES_DIR, { recursive: true });
}
if (!fs.existsSync(EVENTS_IMAGES_DIR)) {
  fs.mkdirSync(EVENTS_IMAGES_DIR, { recursive: true });
}
if (!fs.existsSync(MENU_DIR)) {
  fs.mkdirSync(MENU_DIR, { recursive: true });
}
if (!fs.existsSync(DRINKS_IMAGES_DIR)) {
  fs.mkdirSync(DRINKS_IMAGES_DIR, { recursive: true });
}
if (!fs.existsSync(DESERTS_IMAGES_DIR)) {
  fs.mkdirSync(DESERTS_IMAGES_DIR, { recursive: true });
}
if (!fs.existsSync(DISHES_IMAGES_DIR)) {
  fs.mkdirSync(DISHES_IMAGES_DIR, { recursive: true });
}

// Create language subdirectories for all supported languages
const LANGUAGES = ['en', 'ru', 'ka', 'fr', 'hi', 'uk', 'de', 'tr', 'ja', 'zh'];
LANGUAGES.forEach(lang => {
  const langDir = path.join(MENU_DIR, lang);
  if (!fs.existsSync(langDir)) {
    fs.mkdirSync(langDir, { recursive: true });
  }
});

// Initialize fun facts file if it doesn't exist
if (!fs.existsSync(FUN_FACTS_FILE)) {
  const initialFunFacts = [
    {
      id: 1,
      title: "Our Cacao Source",
      text: "Did you know? Our cacao beans are sourced directly from small-scale farmers in South America!"
    },
    {
      id: 2,
      title: "Family Recipe",
      text: "Our signature hot chocolate recipe has been passed down through three generations!"
    },
    {
      id: 3,
      title: "Organic Commitment",
      text: "We use only organic ingredients in all our beverages!"
    },
    {
      id: 4,
      title: "Local Recognition",
      text: "Our cafe was featured in the local newspaper for our unique cacao ceremonies!"
    },
    {
      id: 5,
      title: "Variety is the Spice of Life",
      text: "We offer over 20 different types of hot chocolate variations!"
    }
  ];
  fs.writeFileSync(FUN_FACTS_FILE, JSON.stringify(initialFunFacts, null, 2));
}

// Initialize settings file if it doesn't exist
if (!fs.existsSync(SETTINGS_FILE)) {
  const initialSettings = {
    specialMenuEnabled: true,
    seasonalDrinks: {
      summer: true,
      winter: true
    }
  };
  fs.writeFileSync(SETTINGS_FILE, JSON.stringify(initialSettings, null, 2));
}

app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use('/images', express.static(IMAGES_DIR));

// Function to download image from URL
function downloadImage(url, filename) {
  return new Promise((resolve, reject) => {
    const protocol = url.startsWith('https') ? https : http;
    protocol.get(url, (response) => {
      if (response.statusCode !== 200) {
        reject(new Error(`Failed to download image: ${response.statusCode}`));
        return;
      }

      const filePath = path.join(EVENTS_IMAGES_DIR, filename);
      const fileStream = fs.createWriteStream(filePath);
      response.pipe(fileStream);

      fileStream.on('finish', () => {
        fileStream.close();
        resolve(`/images/events/${filename}`);
      });

      fileStream.on('error', (err) => {
        fs.unlink(filePath, () => {}); // Delete the file if there's an error
        reject(err);
      });
    }).on('error', reject);
  });
}

// POST /api/events - add a new event
app.post('/api/events', async (req, res) => {
  const { title, date, start_time, end_time, desc, images, channel_message_id, secret } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).send('Forbidden');
  }

  let events = [];
  if (fs.existsSync(EVENTS_FILE)) {
    try {
      events = JSON.parse(fs.readFileSync(EVENTS_FILE, 'utf-8'));
    } catch (e) {
      return res.status(500).send('Could not parse events.json');
    }
  }

  let localImagePaths = [];
  if (Array.isArray(images)) {
    for (const image of images) {
      try {
        const timestamp = Date.now();
        const randomStr = Math.random().toString(36).substring(7);
        const extension = path.extname(image) || '.jpg';
        const filename = `${timestamp}-${randomStr}${extension}`;
        const localPath = await downloadImage(image, filename);
        localImagePaths.push(localPath);
      } catch (error) {
        console.error('Error downloading image:', error);
        return res.status(500).send('Failed to download image');
      }
    }
  }

  const eventData = {
    title,
    date,
    desc,
    images: localImagePaths,
    channel_message_id,
    start_time: start_time || null,
    end_time: end_time || null
  };
  events.unshift(eventData);
  fs.writeFileSync(EVENTS_FILE, JSON.stringify(events, null, 2));
  res.send('Event added!');
});

// POST /api/events/local - store event locally and handle website visibility
app.post('/api/events/local', async (req, res) => {
  const { title, date, start_time, end_time, desc, images, channel_message_id, visibility, secret } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).send('Forbidden');
  }

  let events = [];
  if (fs.existsSync(EVENTS_FILE)) {
    try {
      events = JSON.parse(fs.readFileSync(EVENTS_FILE, 'utf-8'));
    } catch (e) {
      return res.status(500).send('Could not parse events.json');
    }
  }

  let localImagePaths = [];
  if (Array.isArray(images)) {
    for (const image of images) {
      try {
        const timestamp = Date.now();
        const randomStr = Math.random().toString(36).substring(7);
        const extension = path.extname(image) || '.jpg';
        const filename = `${timestamp}-${randomStr}${extension}`;
        const localPath = await downloadImage(image, filename);
        localImagePaths.push(localPath);
      } catch (error) {
        console.error('Error downloading image:', error);
        return res.status(500).send('Failed to download image');
      }
    }
  }

  const eventData = {
    title,
    date,
    desc,
    images: localImagePaths,
    channel_message_id,
    start_time: start_time || null,
    end_time: end_time || null,
    visibility: visibility || 'both'
  };
  events.unshift(eventData);
  fs.writeFileSync(EVENTS_FILE, JSON.stringify(events, null, 2));
  res.send('Event stored successfully!');
});

// GET /api/events/all - get all events regardless of visibility
app.get('/api/events/all', (req, res) => {
  let events = [];
  if (fs.existsSync(EVENTS_FILE)) {
    try {
      events = JSON.parse(fs.readFileSync(EVENTS_FILE, 'utf-8'));
      // Ensure all events have time fields, even if null
      events = events.map(event => ({
        ...event,
        start_time: event.start_time || null,
        end_time: event.end_time || null,
        visibility: event.visibility || 'both'  // Default to 'both' if not specified
      }));
    } catch (e) {
      return res.status(500).json({ error: 'Could not parse events.json', events: [] });
    }
  }
  res.json(events);
});

// GET /api/events - get events for website display
app.get('/api/events', (req, res) => {
  let events = [];
  if (fs.existsSync(EVENTS_FILE)) {
    try {
      events = JSON.parse(fs.readFileSync(EVENTS_FILE, 'utf-8'));
      // Filter out events that are not meant for the website
      events = events.filter(event => event.visibility !== 'channel');
      // Ensure all events have time fields, even if null
      events = events.map(event => ({
        ...event,
        start_time: event.start_time || null,
        end_time: event.end_time || null
      }));
    } catch (e) {
      return res.status(500).json({ error: 'Could not parse events.json', events: [] });
    }
  }
  res.json(events);
});

// DELETE /api/events/:index - delete an event by index
app.delete('/api/events/:index', (req, res) => {
  const { secret } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).send('Forbidden');
  }
  const idx = parseInt(req.params.index, 10);
  if (isNaN(idx)) {
    return res.status(400).send('Invalid index');
  }
  let events = [];
  if (fs.existsSync(EVENTS_FILE)) {
    try {
      events = JSON.parse(fs.readFileSync(EVENTS_FILE, 'utf-8'));
    } catch (e) {
      return res.status(500).send('Could not parse events.json');
    }
  }
  if (idx < 0 || idx >= events.length) {
    return res.status(404).send('Event not found');
  }

  // Get the event being deleted
  const deletedEvent = events[idx];
  
  // Delete all associated image files if they exist
  if (deletedEvent.images && Array.isArray(deletedEvent.images)) {
    for (const imagePathRel of deletedEvent.images) {
      try {
        const imagePath = path.join(__dirname, imagePathRel);
        if (fs.existsSync(imagePath)) {
          fs.unlinkSync(imagePath);
        }
      } catch (error) {
        console.error('Error deleting image file:', error);
        // Continue with event deletion even if image deletion fails
      }
    }
  }

  events.splice(idx, 1);
  fs.writeFileSync(EVENTS_FILE, JSON.stringify(events, null, 2));
  res.send('Event deleted!');
});

// GET /api/funfacts - get all fun facts
app.get('/api/funfacts', (req, res) => {
  let funFacts = [];
  if (fs.existsSync(FUN_FACTS_FILE)) {
    try {
      funFacts = JSON.parse(fs.readFileSync(FUN_FACTS_FILE, 'utf-8'));
    } catch (e) {
      return res.status(500).json({ error: 'Could not parse funFacts.json', funFacts: [] });
    }
  }
  res.json(funFacts);
});

// POST /api/funfacts - add a new fun fact
app.post('/api/funfacts', (req, res) => {
  const { title, text, secret } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).send('Forbidden');
  }

  let funFacts = [];
  if (fs.existsSync(FUN_FACTS_FILE)) {
    try {
      funFacts = JSON.parse(fs.readFileSync(FUN_FACTS_FILE, 'utf-8'));
    } catch (e) {
      return res.status(500).send('Could not parse funFacts.json');
    }
  }

  // Generate new ID
  const newId = funFacts.length > 0 ? Math.max(...funFacts.map(f => f.id)) + 1 : 1;

  const funFactData = {
    id: newId,
    title,
    text
  };

  funFacts.push(funFactData);
  fs.writeFileSync(FUN_FACTS_FILE, JSON.stringify(funFacts, null, 2));
  res.send('Fun fact added!');
});

// DELETE /api/funfacts/:id - delete a fun fact by ID
app.delete('/api/funfacts/:id', (req, res) => {
  const { secret } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).send('Forbidden');
  }

  const id = parseInt(req.params.id, 10);
  if (isNaN(id)) {
    return res.status(400).send('Invalid ID');
  }

  let funFacts = [];
  if (fs.existsSync(FUN_FACTS_FILE)) {
    try {
      funFacts = JSON.parse(fs.readFileSync(FUN_FACTS_FILE, 'utf-8'));
    } catch (e) {
      return res.status(500).send('Could not parse funFacts.json');
    }
  }

  const index = funFacts.findIndex(f => f.id === id);
  if (index === -1) {
    return res.status(404).send('Fun fact not found');
  }

  funFacts.splice(index, 1);
  fs.writeFileSync(FUN_FACTS_FILE, JSON.stringify(funFacts, null, 2));
  res.send('Fun fact deleted!');
});

// GET /api/settings - get all settings
app.get('/api/settings', (req, res) => {
  let settings = {};
  if (fs.existsSync(SETTINGS_FILE)) {
    try {
      settings = JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf-8'));
    } catch (e) {
      return res.status(500).json({ error: 'Could not parse settings.json', settings: {} });
    }
  }
  res.json(settings);
});

// POST /api/settings/special-menu - toggle special menu availability
app.post('/api/settings/special-menu', (req, res) => {
  const { secret } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).send('Forbidden');
  }

  let settings = {};
  if (fs.existsSync(SETTINGS_FILE)) {
    try {
      settings = JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf-8'));
    } catch (e) {
      return res.status(500).send('Could not parse settings.json');
    }
  }

  // Toggle the current status
  settings.specialMenuEnabled = !settings.specialMenuEnabled;
  fs.writeFileSync(SETTINGS_FILE, JSON.stringify(settings, null, 2));
  
  // Return both the new status and a message
  res.json({
    message: `Special menu has been ${settings.specialMenuEnabled ? 'enabled' : 'disabled'}`,
    enabled: settings.specialMenuEnabled
  });
});

// POST /api/settings/seasonal-drinks - toggle seasonal drinks visibility
app.post('/api/settings/seasonal-drinks', (req, res) => {
  const { secret, season } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).send('Forbidden');
  }

  if (!['summer', 'winter'].includes(season)) {
    return res.status(400).send('Invalid season. Must be either "summer" or "winter"');
  }

  let settings = {};
  if (fs.existsSync(SETTINGS_FILE)) {
    try {
      settings = JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf-8'));
    } catch (e) {
      return res.status(500).send('Could not parse settings.json');
    }
  }

  // Initialize seasonalDrinks if it doesn't exist
  if (!settings.seasonalDrinks) {
    settings.seasonalDrinks = { summer: true, winter: true };
  }

  // Toggle the current status for the specified season
  settings.seasonalDrinks[season] = !settings.seasonalDrinks[season];
  fs.writeFileSync(SETTINGS_FILE, JSON.stringify(settings, null, 2));
  
  // Return both the new status and a message
  res.json({
    message: `${season.charAt(0).toUpperCase() + season.slice(1)} drinks have been ${settings.seasonalDrinks[season] ? 'enabled' : 'disabled'}`,
    enabled: settings.seasonalDrinks[season]
  });
});

// GET /api/settings/seasonal-drinks - get seasonal drinks visibility status
app.get('/api/settings/seasonal-drinks', (req, res) => {
  let settings = {};
  if (fs.existsSync(SETTINGS_FILE)) {
    try {
      settings = JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf-8'));
    } catch (e) {
      return res.status(500).json({ error: 'Could not parse settings.json', settings: {} });
    }
  }

  // Initialize seasonalDrinks if it doesn't exist
  if (!settings.seasonalDrinks) {
    settings.seasonalDrinks = { summer: true, winter: true };
  }

  res.json(settings.seasonalDrinks);
});

// POST /api/menu - add a new menu file
app.post('/api/menu', async (req, res) => {
  const { category, languages, file_url, secret } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).send('Forbidden');
  }

  if (!category || !languages || !file_url) {
    return res.status(400).send('Missing required fields');
  }

  console.log('Processing menu update:', {
    category,
    languages,
    file_url: file_url.substring(0, 100) + '...' // Log only part of the URL for security
  });

  try {
    // Download and save the file for each language
    for (const lang of languages) {
      const langDir = path.join(MENU_DIR, lang);
      const filename = `${category}_${lang}.pdf`;
      const filePath = path.join(langDir, filename);

      console.log(`Processing language ${lang}:`, {
        langDir,
        filename,
        filePath
      });

      // Delete existing file if it exists
      if (fs.existsSync(filePath)) {
        console.log(`Deleting existing file: ${filePath}`);
        fs.unlinkSync(filePath);
      }

      // Download and save the new file
      console.log(`Downloading file from: ${file_url}`);
      const response = await fetch(file_url);
      if (!response.ok) {
        throw new Error(`Failed to download file: ${response.statusText}`);
      }

      // Create a write stream
      const fileStream = fs.createWriteStream(filePath);
      
      // Get the response as a buffer and write it to file
      const buffer = await response.buffer();
      await new Promise((resolve, reject) => {
        fileStream.write(buffer, (error) => {
          if (error) reject(error);
          else resolve();
        });
      });
      
      // Close the file stream
      fileStream.end();
      console.log(`Successfully saved file: ${filePath}`);
    }

    console.log('Menu files updated successfully');
    res.json({ message: 'Menu files updated successfully' });
  } catch (error) {
    console.error('Error updating menu files:', error);
    res.status(500).send('Failed to update menu files: ' + error.message);
  }
});

// DELETE /api/menu/:category/:language - delete menu file for a specific category and language
app.delete('/api/menu/:category/:language', (req, res) => {
  const { secret } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).send('Forbidden');
  }

  const category = req.params.category;
  const language = req.params.language;
  
  console.log('DELETE /api/menu:', { received_category: category, received_language: language });

  if (!category || !language) {
    return res.status(400).send('Missing required parameters');
  }

  try {
    const langDir = path.join(MENU_DIR, language);
    if (!fs.existsSync(langDir)) {
      console.log('Language directory does not exist:', langDir);
      return res.status(404).send('Menu file not found');
    }
    // Find the file that matches the category, ignoring underscores, dashes, and case
    const files = fs.readdirSync(langDir);
    const normalize = s => s.replace(/[-_\s]+/g, '').toLowerCase();
    const target = normalize(category);
    console.log('Files in directory:', files);
    console.log('Normalized target:', target);
    const file = files.find(f => {
      const match = f.match(/^(.*)_([a-z]{2})\.pdf$/);
      if (!match) return false;
      const fileCategory = match[1];
      const normFileCategory = normalize(fileCategory);
      if (normFileCategory === target) {
        console.log('Matched file:', f, 'with normalized category:', normFileCategory);
        return true;
      }
      return false;
    });
    if (file) {
      const filePath = path.join(langDir, file);
      fs.unlinkSync(filePath);
      console.log('Deleted file:', filePath);
      res.json({ message: 'Menu file deleted successfully' });
    } else {
      console.log('No matching file found for category:', category, 'in', langDir);
      res.status(404).send('Menu file not found');
    }
  } catch (error) {
    console.error('Error deleting menu file:', error);
    res.status(500).send('Failed to delete menu file');
  }
});

// GET /api/menu - list available menu files
app.get('/api/menu', (req, res) => {
  try {
    const menuFiles = {};
    for (const lang of LANGUAGES) {
      const langDir = path.join(MENU_DIR, lang);
      if (fs.existsSync(langDir)) {
        const files = fs.readdirSync(langDir);
        menuFiles[lang] = files.map(file => {
          // Extract the full category part before _<lang>.pdf
          const match = file.match(/^(.*)_([a-z]{2})\.pdf$/);
          return match ? match[1] : file;
        });
      }
    }
    res.json(menuFiles);
  } catch (error) {
    console.error('Error listing menu files:', error);
    res.status(500).send('Failed to list menu files');
  }
});

// GET /api/menu/url - get the appropriate menu URL for a category and language
app.get('/api/menu/url', (req, res) => {
  const { category, language } = req.query;
  
  if (!category || !language) {
    return res.status(400).send('Missing required parameters');
  }

  // First check if the requested language file exists
  const requestedPath = path.join(MENU_DIR, language, `${category}_${language}.pdf`);
  if (fs.existsSync(requestedPath)) {
    return res.json({ url: `/images/menu/${language}/${category}_${language}.pdf` });
  }

  // If not, return the English version
  const englishPath = path.join(MENU_DIR, 'en', `${category}_en.pdf`);
  if (fs.existsSync(englishPath)) {
    return res.json({ url: `/images/menu/en/${category}_en.pdf` });
  }

  // If neither exists, return 404
  res.status(404).send('Menu file not found');
});

// GET /api/drinks - get all drinks
app.get('/api/drinks', (req, res) => {
  let drinks = [];
  if (fs.existsSync(DRINKS_FILE)) {
    try {
      drinks = JSON.parse(fs.readFileSync(DRINKS_FILE, 'utf-8')).drinks;
    } catch (e) {
      return res.status(500).json({ error: 'Could not parse drinks.json', drinks: [] });
    }
  }
  res.json(drinks);
});

// POST /api/drinks - add a new drink
app.post('/api/drinks', (req, res) => {
  const { name, type, description, category, price, secret } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).send('Forbidden');
  }

  let drinks = [];
  if (fs.existsSync(DRINKS_FILE)) {
    try {
      drinks = JSON.parse(fs.readFileSync(DRINKS_FILE, 'utf-8')).drinks;
    } catch (e) {
      return res.status(500).send('Could not parse drinks.json');
    }
  }

  // Generate a unique ID based on the name
  const id = name.toLowerCase().replace(/\s+/g, '-');
  
  // Check if drink with this ID already exists
  if (drinks.some(drink => drink.id === id)) {
    return res.status(400).send('A drink with this name already exists');
  }

  // Validate price
  if (typeof price !== 'number' || isNaN(price)) {
    return res.status(400).send('Price is required and must be a number');
  }

  const newDrink = {
    id,
    name,
    type,
    description,
    images: [],
    category,
    visible: true,
    inStock: true,
    price
  };

  drinks.push(newDrink);
  fs.writeFileSync(DRINKS_FILE, JSON.stringify({ drinks }, null, 2));
  res.json(newDrink);
});

// PUT /api/drinks/:id - update a drink
app.put('/api/drinks/:id', (req, res) => {
  const { secret, ...updates } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).send('Forbidden');
  }

  let drinks = [];
  if (fs.existsSync(DRINKS_FILE)) {
    try {
      drinks = JSON.parse(fs.readFileSync(DRINKS_FILE, 'utf-8')).drinks;
    } catch (e) {
      return res.status(500).send('Could not parse drinks.json');
    }
  }

  const index = drinks.findIndex(drink => drink.id === req.params.id);
  if (index === -1) {
    return res.status(404).send('Drink not found');
  }

  // If price is provided, validate it
  if ('price' in updates && (typeof updates.price !== 'number' || isNaN(updates.price))) {
    return res.status(400).send('Price must be a number');
  }

  // Update only the provided fields
  drinks[index] = { ...drinks[index], ...updates };
  fs.writeFileSync(DRINKS_FILE, JSON.stringify({ drinks }, null, 2));
  res.json(drinks[index]);
});

// DELETE /api/drinks/:id - delete a drink
app.delete('/api/drinks/:id', (req, res) => {
  const { secret } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).send('Forbidden');
  }

  let drinks = [];
  if (fs.existsSync(DRINKS_FILE)) {
    try {
      drinks = JSON.parse(fs.readFileSync(DRINKS_FILE, 'utf-8')).drinks;
    } catch (e) {
      return res.status(500).send('Could not parse drinks.json');
    }
  }

  const index = drinks.findIndex(drink => drink.id === req.params.id);
  if (index === -1) {
    return res.status(404).send('Drink not found');
  }

  // Delete associated images
  const drink = drinks[index];
  drink.images.forEach(image => {
    const imagePath = path.join(DRINKS_IMAGES_DIR, image);
    if (fs.existsSync(imagePath)) {
      fs.unlinkSync(imagePath);
    }
  });

  drinks.splice(index, 1);
  fs.writeFileSync(DRINKS_FILE, JSON.stringify({ drinks }, null, 2));
  res.send('Drink deleted successfully');
});

// POST /api/drinks/:id/images - add an image to a drink
app.post('/api/drinks/:id/images', async (req, res) => {
  const { image_url, secret } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).send('Forbidden');
  }

  let drinks = [];
  if (fs.existsSync(DRINKS_FILE)) {
    try {
      drinks = JSON.parse(fs.readFileSync(DRINKS_FILE, 'utf-8')).drinks;
    } catch (e) {
      return res.status(500).send('Could not parse drinks.json');
    }
  }

  const index = drinks.findIndex(drink => drink.id === req.params.id);
  if (index === -1) {
    return res.status(404).send('Drink not found');
  }

  try {
    // Generate a unique filename
    const timestamp = Date.now();
    const randomStr = Math.random().toString(36).substring(7);
    const extension = path.extname(image_url) || '.jpg';
    const filename = `${drinks[index].id}-${timestamp}-${randomStr}${extension}`;
    
    // Download and save the image
    const imagePath = path.join(DRINKS_IMAGES_DIR, filename);
    const response = await fetch(image_url);
    if (!response.ok) {
      throw new Error(`Failed to download image: ${response.statusText}`);
    }

    const fileStream = fs.createWriteStream(imagePath);
    const buffer = await response.buffer();
    await new Promise((resolve, reject) => {
      fileStream.write(buffer, (error) => {
        if (error) reject(error);
        else resolve();
      });
    });
    fileStream.end();

    // Add the image to the drink
    if (!drinks[index].images) drinks[index].images = [];
    drinks[index].images.push(filename);
    fs.writeFileSync(DRINKS_FILE, JSON.stringify({ drinks }, null, 2));
    res.json({ message: 'Image added successfully', filename });
  } catch (error) {
    console.error('Error adding image:', error);
    res.status(500).send('Failed to add image: ' + error.message);
  }
});

// DELETE /api/drinks/:id/images/:filename - delete a specific image from a drink
app.delete('/api/drinks/:id/images/:filename', (req, res) => {
  const { secret } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).send('Forbidden');
  }

  let drinks = [];
  if (fs.existsSync(DRINKS_FILE)) {
    try {
      drinks = JSON.parse(fs.readFileSync(DRINKS_FILE, 'utf-8')).drinks;
    } catch (e) {
      return res.status(500).send('Could not parse drinks.json');
    }
  }

  const index = drinks.findIndex(drink => drink.id === req.params.id);
  if (index === -1) {
    return res.status(404).send('Drink not found');
  }

  const imageIndex = drinks[index].images.indexOf(req.params.filename);
  if (imageIndex === -1) {
    return res.status(404).send('Image not found');
  }

  // Delete the image file
  const imagePath = path.join(DRINKS_IMAGES_DIR, req.params.filename);
  if (fs.existsSync(imagePath)) {
    fs.unlinkSync(imagePath);
  }

  // Remove the image from the drink
  drinks[index].images.splice(imageIndex, 1);
  fs.writeFileSync(DRINKS_FILE, JSON.stringify({ drinks }, null, 2));
  res.send('Image deleted successfully');
});

// GET /api/deserts - get all deserts
app.get('/api/deserts', (req, res) => {
  try {
    const deserts = JSON.parse(fs.readFileSync(DESERTS_FILE, 'utf-8'));
    res.json(deserts);
  } catch (error) {
    res.status(500).json({ error: 'Failed to read deserts data' });
  }
});

app.post('/api/deserts', (req, res) => {
  const { name, description, price, secret } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).json({ error: 'Invalid secret' });
  }

  try {
    let deserts = [];
    if (fs.existsSync(DESERTS_FILE)) {
      deserts = JSON.parse(fs.readFileSync(DESERTS_FILE, 'utf-8'));
    }

    const desert_id = name.toLowerCase().replace(' ', '-');
    if (deserts.some(d => d.id === desert_id)) {
      return res.status(400).json({ error: 'Desert with this name already exists' });
    }

    const new_desert = {
      id: desert_id,
      name,
      description,
      price: parseFloat(price),
      images: [],
      visible: true,
      available: true
    };

    deserts.push(new_desert);
    fs.writeFileSync(DESERTS_FILE, JSON.stringify(deserts, null, 2));
    res.status(200).json({ message: 'Desert created successfully', dessert: new_desert });
  } catch (error) {
    res.status(500).json({ error: 'Failed to add desert' });
  }
});

app.put('/api/deserts/:desert_id', (req, res) => {
  const { desert_id } = req.params;
  const { name, description, price, visible, available, secret } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).json({ error: 'Invalid secret' });
  }

  try {
    const deserts = JSON.parse(fs.readFileSync(DESERTS_FILE, 'utf-8'));
    const desert = deserts.find(d => d.id === desert_id);
    if (!desert) {
      return res.status(404).json({ error: 'Desert not found' });
    }

    if (name) {
      const new_id = name.toLowerCase().replace(' ', '-');
      if (new_id !== desert_id && deserts.some(d => d.id === new_id)) {
        return res.status(400).json({ error: 'Desert with this name already exists' });
      }
      desert.id = new_id;
      desert.name = name;
    }
    if (description) desert.description = description;
    if (price) desert.price = parseFloat(price);
    if (typeof visible === 'boolean') desert.visible = visible;
    if (typeof available === 'boolean') desert.available = available;

    fs.writeFileSync(DESERTS_FILE, JSON.stringify(deserts, null, 2));
    res.json(desert);
  } catch (error) {
    res.status(500).json({ error: 'Failed to update desert' });
  }
});

app.delete('/api/deserts/:desert_id', (req, res) => {
  const { desert_id } = req.params;
  const { secret } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).json({ error: 'Invalid secret' });
  }

  try {
    const deserts = JSON.parse(fs.readFileSync(DESERTS_FILE, 'utf-8'));
    const desert = deserts.find(d => d.id === desert_id);
    if (!desert) {
      return res.status(404).json({ error: 'Desert not found' });
    }

    // Delete associated images
    for (const image of desert.images) {
      try {
        fs.unlinkSync(path.join(DESERTS_IMAGES_DIR, image));
      } catch (error) {
        console.error(`Failed to delete image ${image}:`, error);
      }
    }

    const updated_deserts = deserts.filter(d => d.id !== desert_id);
    fs.writeFileSync(DESERTS_FILE, JSON.stringify(updated_deserts, null, 2));
    res.status(204).send();
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete desert' });
  }
});

app.post('/api/deserts/:desert_id/images', async (req, res) => {
  const { desert_id } = req.params;
  const { image_url, secret } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).json({ error: 'Invalid secret' });
  }

  try {
    let deserts = [];
    if (fs.existsSync(DESERTS_FILE)) {
      deserts = JSON.parse(fs.readFileSync(DESERTS_FILE, 'utf-8'));
    }

    const desert = deserts.find(d => d.id === desert_id);
    if (!desert) {
      return res.status(404).json({ error: 'Desert not found' });
    }

    // Download image
    const response = await fetch(image_url);
    if (!response.ok) {
      let errorText = '';
      try {
        errorText = await response.text();
      } catch (e) {
        errorText = '[Could not read response body]';
      }
      console.error('Failed to download image:', {
        url: image_url,
        status: response.status,
        statusText: response.statusText,
        body: errorText
      });
      return res.status(400).json({ error: 'Failed to download image', status: response.status, statusText: response.statusText, body: errorText });
    }

    // Generate unique filename
    const timestamp = Date.now();
    const randomStr = Math.random().toString(36).substring(7);
    const extension = path.extname(image_url) || '.jpg';
    const filename = `${desert_id}-${timestamp}-${randomStr}${extension}`;

    // Save image
    const buffer = await response.buffer();
    fs.writeFileSync(path.join(DESERTS_IMAGES_DIR, filename), buffer);

    // Add to desert's images
    desert.images.push(filename);
    fs.writeFileSync(DESERTS_FILE, JSON.stringify(deserts, null, 2));

    res.status(200).json({ message: 'Image added successfully', filename });
  } catch (error) {
    console.error('Error adding image:', error);
    res.status(500).json({ error: 'Failed to add image: ' + error.message });
  }
});

app.delete('/api/deserts/:desert_id/images/:filename', (req, res) => {
  const { desert_id, filename } = req.params;
  const { secret } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).json({ error: 'Invalid secret' });
  }

  try {
    const deserts = JSON.parse(fs.readFileSync(DESERTS_FILE, 'utf-8'));
    const desert = deserts.find(d => d.id === desert_id);
    if (!desert) {
      return res.status(404).json({ error: 'Desert not found' });
    }

    if (!desert.images.includes(filename)) {
      return res.status(404).json({ error: 'Image not found' });
    }

    // Delete image file
    try {
      fs.unlinkSync(path.join(DESERTS_IMAGES_DIR, filename));
    } catch (error) {
      console.error(`Failed to delete image ${filename}:`, error);
    }

    // Remove from desert's images
    desert.images = desert.images.filter(img => img !== filename);
    fs.writeFileSync(DESERTS_FILE, JSON.stringify(deserts, null, 2));

    res.status(200).json({ message: 'Image deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete image' });
  }
});

app.get('/api/categories', (req, res) => {
  try {
    const others = JSON.parse(fs.readFileSync(path.join(__dirname, 'src/data/others.json'), 'utf-8'));
    const categories = others.categories.map(category => ({
      id: category.id,
      name: category.name,
      visible: category.visible
    }));
    res.json(categories);
  } catch (error) {
    res.status(500).json({ error: 'Failed to read categories data' });
  }
});

app.post('/api/categories', (req, res) => {
  const { name, secret } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).send('Forbidden');
  }

  try {
    // Get absolute paths
    const othersPath = path.join(__dirname, 'src/data/others.json');
    const translationsPath = path.join(__dirname, 'src/translations/en.json');

    // Check if files exist
    if (!fs.existsSync(othersPath)) {
      console.error('others.json not found at:', othersPath);
      return res.status(500).json({ error: 'Configuration file not found' });
    }
    if (!fs.existsSync(translationsPath)) {
      console.error('en.json not found at:', translationsPath);
      return res.status(500).json({ error: 'Translations file not found' });
    }

    // Read and parse others.json
    let others;
    try {
      others = JSON.parse(fs.readFileSync(othersPath, 'utf-8'));
    } catch (error) {
      console.error('Error parsing others.json:', error);
      return res.status(500).json({ error: 'Invalid others.json format' });
    }

    // Generate ID from name (lowercase, replace spaces with hyphens)
    const id = name.toLowerCase().replace(/\s+/g, '-');
    
    // Check if category with this ID already exists
    if (others.categories.some(cat => cat.id === id)) {
      return res.status(400).json({ error: 'Category with this name already exists' });
    }

    // Add new category
    const newCategory = {
      id,
      name,
      visible: true
    };
    others.categories.push(newCategory);
    
    // Save to others.json
    try {
      fs.writeFileSync(othersPath, JSON.stringify(others, null, 2));
    } catch (error) {
      console.error('Error writing to others.json:', error);
      return res.status(500).json({ error: 'Failed to save category to others.json' });
    }

    // Read and parse translations
    let translations;
    try {
      translations = JSON.parse(fs.readFileSync(translationsPath, 'utf-8'));
    } catch (error) {
      console.error('Error parsing translations:', error);
      return res.status(500).json({ error: 'Invalid translations format' });
    }
    
    // Add category name to translations
    if (!translations.others) {
      translations.others = {};
    }
    if (!translations.others.categories) {
      translations.others.categories = {};
    }
    translations.others.categories[id] = name;
    
    // Save translations
    try {
      fs.writeFileSync(translationsPath, JSON.stringify(translations, null, 2));
    } catch (error) {
      console.error('Error writing to translations:', error);
      return res.status(500).json({ error: 'Failed to save category to translations' });
    }

    res.json(newCategory);
  } catch (error) {
    console.error('Unexpected error adding category:', error);
    res.status(500).json({ error: 'Failed to add category: ' + error.message });
  }
});

// DELETE /api/categories/:id - delete a category and its associated data
app.delete('/api/categories/:id', (req, res) => {
  const { secret } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).send('Forbidden');
  }

  try {
    // Get absolute paths
    const othersPath = path.join(__dirname, 'src/data/others.json');
    const translationsPath = path.join(__dirname, 'src/translations/en.json');
    const imagesDir = path.join(__dirname, 'images/others');

    // Check if files exist
    if (!fs.existsSync(othersPath)) {
      console.error('others.json not found at:', othersPath);
      return res.status(500).json({ error: 'Configuration file not found' });
    }
    if (!fs.existsSync(translationsPath)) {
      console.error('en.json not found at:', translationsPath);
      return res.status(500).json({ error: 'Translations file not found' });
    }

    // Read and parse others.json
    let others;
    try {
      others = JSON.parse(fs.readFileSync(othersPath, 'utf-8'));
    } catch (error) {
      console.error('Error parsing others.json:', error);
      return res.status(500).json({ error: 'Invalid others.json format' });
    }

    const categoryId = req.params.id;
    // Check if category exists
    const categoryIndex = others.categories.findIndex(cat => cat.id === categoryId);
    if (categoryIndex === -1) {
      return res.status(404).json({ error: 'Category not found' });
    }

    // Remove all products in this category (and their images/flavours)
    const productsToDelete = others.products.filter(product => product.categoryId === categoryId);
    for (const product of productsToDelete) {
      // Delete all flavour images
      if (Array.isArray(product.flavors)) {
        for (const flavour of product.flavors) {
          if (flavour.image) {
            const flavourImagePath = path.join(imagesDir, flavour.image);
            if (fs.existsSync(flavourImagePath)) {
              try { fs.unlinkSync(flavourImagePath); } catch (e) { console.error('Failed to delete flavour image:', flavour.image, e); }
            }
          }
        }
      }
      // Optionally, delete product-level images if any (not in current schema, but future-proof)
      if (product.image) {
        const productImagePath = path.join(imagesDir, product.image);
        if (fs.existsSync(productImagePath)) {
          try { fs.unlinkSync(productImagePath); } catch (e) { console.error('Failed to delete product image:', product.image, e); }
        }
      }
    }
    // Remove products from others.json
    others.products = others.products.filter(product => product.categoryId !== categoryId);
    // Remove category from categories array
    others.categories.splice(categoryIndex, 1);

    // Save updated others.json
    try {
      fs.writeFileSync(othersPath, JSON.stringify(others, null, 2));
    } catch (error) {
      console.error('Error writing to others.json:', error);
      return res.status(500).json({ error: 'Failed to save changes to others.json' });
    }

    // Read and parse translations
    let translations;
    try {
      translations = JSON.parse(fs.readFileSync(translationsPath, 'utf-8'));
    } catch (error) {
      console.error('Error parsing translations:', error);
      return res.status(500).json({ error: 'Invalid translations format' });
    }
    // Remove category from translations
    if (translations.others && translations.others.categories) {
      delete translations.others.categories[categoryId];
    }
    // Save translations
    try {
      fs.writeFileSync(translationsPath, JSON.stringify(translations, null, 2));
    } catch (error) {
      console.error('Error writing to translations:', error);
      return res.status(500).json({ error: 'Failed to save changes to translations' });
    }
    res.json({ message: 'Category and associated data deleted successfully' });
  } catch (error) {
    console.error('Unexpected error deleting category:', error);
    res.status(500).json({ error: 'Failed to delete category: ' + error.message });
  }
});

// PUT /api/categories/:id - rename a category
app.put('/api/categories/:id', (req, res) => {
  const { secret, name } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).send('Forbidden');
  }
  if (!name) {
    return res.status(400).json({ error: 'Missing new name' });
  }
  try {
    const othersPath = path.join(__dirname, 'src/data/others.json');
    const translationsPath = path.join(__dirname, 'src/translations/en.json');
    if (!fs.existsSync(othersPath) || !fs.existsSync(translationsPath)) {
      return res.status(500).json({ error: 'Configuration or translations file not found' });
    }
    let others = JSON.parse(fs.readFileSync(othersPath, 'utf-8'));
    let translations = JSON.parse(fs.readFileSync(translationsPath, 'utf-8'));
    const categoryId = req.params.id;
    const category = others.categories.find(cat => cat.id === categoryId);
    if (!category) {
      return res.status(404).json({ error: 'Category not found' });
    }
    // Update name
    category.name = name;
    // Update translation
    if (translations.others && translations.others.categories && translations.others.categories[categoryId]) {
      translations.others.categories[categoryId] = name;
    }
    fs.writeFileSync(othersPath, JSON.stringify(others, null, 2));
    fs.writeFileSync(translationsPath, JSON.stringify(translations, null, 2));
    res.json({ message: 'Category renamed successfully', id: categoryId, name });
  } catch (error) {
    console.error('Error renaming category:', error);
    res.status(500).json({ error: 'Failed to rename category: ' + error.message });
  }
});

// Helper: Download image for dish
async function downloadDishImage(url, filename) {
  const protocol = url.startsWith('https') ? https : http;
  return new Promise((resolve, reject) => {
    protocol.get(url, (response) => {
      if (response.statusCode !== 200) {
        reject(new Error(`Failed to download image: ${response.statusCode}`));
        return;
      }
      const filePath = path.join(DISHES_IMAGES_DIR, filename);
      const fileStream = fs.createWriteStream(filePath);
      response.pipe(fileStream);
      fileStream.on('finish', () => {
        fileStream.close();
        resolve(`images/dishes/${filename}`);
      });
      fileStream.on('error', (err) => {
        fs.unlink(filePath, () => {});
        reject(err);
      });
    }).on('error', reject);
  });
}

// POST /api/dishes - add a new dish
app.post('/api/dishes', async (req, res) => {
  const { name, description, price, image_url, secret } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).send('Forbidden');
  }
  let dishes = [];
  if (fs.existsSync(DISHES_FILE)) {
    try {
      dishes = JSON.parse(fs.readFileSync(DISHES_FILE, 'utf-8')).dishes;
    } catch (e) {
      return res.status(500).send('Could not parse dishesData.json');
    }
  }
  // Generate new id
  const newId = dishes.length > 0 ? Math.max(...dishes.map(d => d.id)) + 1 : 1;
  // Download image
  let image = '';
  if (image_url) {
    try {
      const timestamp = Date.now();
      const randomStr = Math.random().toString(36).substring(7);
      const extension = path.extname(image_url) || '.jpg';
      const filename = `${newId}-${timestamp}-${randomStr}${extension}`;
      image = await downloadDishImage(image_url, filename);
    } catch (error) {
      return res.status(500).send('Failed to download image');
    }
  }
  const newDish = {
    id: newId,
    image,
    titleKey: name, // You may want to adjust this for i18n
    description,
    price,
    visible: true,
    inStock: true
  };
  dishes.push(newDish);
  fs.writeFileSync(DISHES_FILE, JSON.stringify({ dishes }, null, 2));
  res.json(newDish);
});

// DELETE /api/dishes/:id - delete a dish and its image
app.delete('/api/dishes/:id', (req, res) => {
  const { secret } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).send('Forbidden');
  }
  let dishes = [];
  if (fs.existsSync(DISHES_FILE)) {
    try {
      dishes = JSON.parse(fs.readFileSync(DISHES_FILE, 'utf-8')).dishes;
    } catch (e) {
      return res.status(500).send('Could not parse dishesData.json');
    }
  }
  const id = parseInt(req.params.id, 10);
  const index = dishes.findIndex(d => d.id === id);
  if (index === -1) {
    return res.status(404).send('Dish not found');
  }
  // Delete all associated image files
  const dish = dishes[index];
  // Delete single image field if present
  if (dish.image) {
    const imagePath = path.join(WORKSPACE_ROOT, 'Website', dish.image);
    if (fs.existsSync(imagePath)) {
      fs.unlinkSync(imagePath);
    }
  }
  // Delete all images in the images array
  if (dish.images && Array.isArray(dish.images)) {
    for (const filename of dish.images) {
      const imagePath = path.join(DISHES_IMAGES_DIR, filename);
      if (fs.existsSync(imagePath)) {
        try {
          fs.unlinkSync(imagePath);
        } catch (err) {
          console.error('Failed to delete dish image:', filename, err);
        }
      }
    }
  }
  dishes.splice(index, 1);
  fs.writeFileSync(DISHES_FILE, JSON.stringify({ dishes }, null, 2));
  res.send('Dish deleted successfully');
});

// PUT /api/dishes/:id - update a dish
app.put('/api/dishes/:id', (req, res) => {
  const { secret, name, description, price } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).send('Forbidden');
  }
  let dishes = [];
  if (fs.existsSync(DISHES_FILE)) {
    try {
      dishes = JSON.parse(fs.readFileSync(DISHES_FILE, 'utf-8')).dishes;
    } catch (e) {
      return res.status(500).send('Could not parse dishesData.json');
    }
  }
  const id = parseInt(req.params.id, 10);
  const index = dishes.findIndex(d => d.id === id);
  if (index === -1) {
    return res.status(404).send('Dish not found');
  }
  if (name) dishes[index].titleKey = name; // Adjust for i18n if needed
  if (description) dishes[index].description = description;
  if (price) dishes[index].price = price;
  fs.writeFileSync(DISHES_FILE, JSON.stringify({ dishes }, null, 2));
  res.json(dishes[index]);
});

// GET /api/dishes/all - list all dishes with status
app.get('/api/dishes/all', (req, res) => {
  let dishes = [];
  if (fs.existsSync(DISHES_FILE)) {
    try {
      dishes = JSON.parse(fs.readFileSync(DISHES_FILE, 'utf-8')).dishes;
    } catch (e) {
      return res.status(500).json({ error: 'Could not parse dishesData.json', dishes: [] });
    }
  }
  res.json(dishes);
});

// POST /api/dishes/:id/toggle-visibility
app.post('/api/dishes/:id/toggle-visibility', (req, res) => {
  const { secret } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).send('Forbidden');
  }
  let dishes = [];
  if (fs.existsSync(DISHES_FILE)) {
    try {
      dishes = JSON.parse(fs.readFileSync(DISHES_FILE, 'utf-8')).dishes;
    } catch (e) {
      return res.status(500).send('Could not parse dishesData.json');
    }
  }
  const id = parseInt(req.params.id, 10);
  const index = dishes.findIndex(d => d.id === id);
  if (index === -1) {
    return res.status(404).send('Dish not found');
  }
  dishes[index].visible = !dishes[index].visible;
  fs.writeFileSync(DISHES_FILE, JSON.stringify({ dishes }, null, 2));
  res.json({ id, visible: dishes[index].visible });
});

// POST /api/dishes/:id/toggle-stock
app.post('/api/dishes/:id/toggle-stock', (req, res) => {
  const { secret } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).send('Forbidden');
  }
  let dishes = [];
  if (fs.existsSync(DISHES_FILE)) {
    try {
      dishes = JSON.parse(fs.readFileSync(DISHES_FILE, 'utf-8')).dishes;
    } catch (e) {
      return res.status(500).send('Could not parse dishesData.json');
    }
  }
  const id = parseInt(req.params.id, 10);
  const index = dishes.findIndex(d => d.id === id);
  if (index === -1) {
    return res.status(404).send('Dish not found');
  }
  dishes[index].inStock = !dishes[index].inStock;
  fs.writeFileSync(DISHES_FILE, JSON.stringify({ dishes }, null, 2));
  res.json({ id, inStock: dishes[index].inStock });
});

// POST /api/dishes/:id/images - add an image to a dish
app.post('/api/dishes/:id/images', async (req, res) => {
  const id = parseInt(req.params.id, 10);
  let dishes = [];
  if (fs.existsSync(DISHES_FILE)) {
    try {
      dishes = JSON.parse(fs.readFileSync(DISHES_FILE, 'utf-8')).dishes;
    } catch (e) {
      return res.status(500).send('Could not parse dishesData.json');
    }
  }
  const index = dishes.findIndex(d => d.id === id);
  if (index === -1) {
    return res.status(404).send('Dish not found');
  }
  const { image_url, secret } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).json({ error: 'Invalid secret' });
  }
  if (!image_url) {
    return res.status(400).json({ error: 'No image_url provided' });
  }
  try {
    // Download image
    const response = await fetch(image_url);
    if (!response.ok) {
      let errorText = '';
      try { errorText = await response.text(); } catch (e) { errorText = '[Could not read response body]'; }
      return res.status(400).json({ error: 'Failed to download image', status: response.status, statusText: response.statusText, body: errorText });
    }
    // Generate unique filename
    const timestamp = Date.now();
    const randomStr = Math.random().toString(36).substring(7);
    const extension = path.extname(image_url) || '.jpg';
    const filename = `${id}-${timestamp}-${randomStr}${extension}`;
    // Save image
    const buffer = await response.buffer();
    fs.writeFileSync(path.join(DISHES_IMAGES_DIR, filename), buffer);
    // Add to dish's images
    if (!dishes[index].images) dishes[index].images = [];
    dishes[index].images.push(filename);
    fs.writeFileSync(DISHES_FILE, JSON.stringify({ dishes }, null, 2));
    res.status(200).json({ message: 'Image added successfully', filename });
  } catch (error) {
    console.error('Error adding image:', error);
    res.status(500).json({ error: 'Failed to add image: ' + error.message });
  }
});

app.delete('/api/dishes/:id/images/:filename', (req, res) => {
  const id = parseInt(req.params.id, 10);
  const filename = req.params.filename;
  const { secret } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).json({ error: 'Invalid secret' });
  }
  let dishes = [];
  if (fs.existsSync(DISHES_FILE)) {
    try {
      dishes = JSON.parse(fs.readFileSync(DISHES_FILE, 'utf-8')).dishes;
    } catch (e) {
      return res.status(500).json({ error: 'Could not parse dishesData.json' });
    }
  }
  const index = dishes.findIndex(d => d.id === id);
  if (index === -1) {
    return res.status(404).json({ error: 'Dish not found' });
  }
  const dish = dishes[index];
  if (!dish.images || !dish.images.includes(filename)) {
    return res.status(404).json({ error: 'Image not found' });
  }
  // Delete image file
  try {
    fs.unlinkSync(path.join(DISHES_IMAGES_DIR, filename));
  } catch (error) {
    console.error(`Failed to delete image ${filename}:`, error);
  }
  // Remove from dish's images
  dish.images = dish.images.filter(img => img !== filename);
  fs.writeFileSync(DISHES_FILE, JSON.stringify({ dishes }, null, 2));
  res.status(200).json({ message: 'Image deleted successfully' });
});

// --- THE BAR IMAGES ENDPOINTS ---
const THE_BAR_JSON = path.join(__dirname, 'src/data/the_bar.json');
const THE_BAR_IMAGES_DIR = path.join(IMAGES_DIR, 'the_bar');

// Ensure the_bar images directory exists
if (!fs.existsSync(THE_BAR_IMAGES_DIR)) {
  fs.mkdirSync(THE_BAR_IMAGES_DIR, { recursive: true });
}

// POST /api/the-bar/images - add an image (title + image buffer)
app.post('/api/the-bar/images', async (req, res) => {
  const { title, image_data, image_ext, secret } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).send('Forbidden');
  }
  if (!title || !image_data) {
    return res.status(400).send('Missing title or image data');
  }
  let data = { images: [] };
  if (fs.existsSync(THE_BAR_JSON)) {
    try {
      data = JSON.parse(fs.readFileSync(THE_BAR_JSON, 'utf-8'));
    } catch (e) {
      return res.status(500).send('Could not parse the_bar.json');
    }
  }
  // Generate new id
  const newId = data.images.length > 0 ? Math.max(...data.images.map(img => img.id)) + 1 : 1;
  try {
    const timestamp = Date.now();
    const randomStr = Math.random().toString(36).substring(7);
    const extension = image_ext || '.jpg';
    const filename = `img${newId}_${timestamp}_${randomStr}${extension}`;
    const imagePath = path.join(THE_BAR_IMAGES_DIR, filename);
    // Decode base64 image data
    const buffer = Buffer.from(image_data, 'base64');
    fs.writeFileSync(imagePath, buffer);
    // Add to JSON
    const relSrc = `/images/the_bar/${filename}`;
    data.images.push({ id: newId, title, src: relSrc });
    fs.writeFileSync(THE_BAR_JSON, JSON.stringify(data, null, 2));
    res.status(200).json({ message: 'Image added successfully', id: newId, title, src: relSrc });
  } catch (error) {
    console.error('Error adding image to the_bar:', error);
    res.status(500).send('Failed to add image: ' + error.message);
  }
});

// GET /api/the-bar/images - list all images
app.get('/api/the-bar/images', (req, res) => {
  let data = { images: [] };
  if (fs.existsSync(THE_BAR_JSON)) {
    try {
      data = JSON.parse(fs.readFileSync(THE_BAR_JSON, 'utf-8'));
    } catch (e) {
      return res.status(500).json({ error: 'Could not parse the_bar.json', images: [] });
    }
  }
  res.json(data.images);
});

// DELETE /api/the-bar/images/:id - delete image by id
app.delete('/api/the-bar/images/:id', (req, res) => {
  const { secret } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).send('Forbidden');
  }
  const id = parseInt(req.params.id, 10);
  if (isNaN(id)) {
    return res.status(400).send('Invalid id');
  }
  let data = { images: [] };
  if (fs.existsSync(THE_BAR_JSON)) {
    try {
      data = JSON.parse(fs.readFileSync(THE_BAR_JSON, 'utf-8'));
    } catch (e) {
      return res.status(500).send('Could not parse the_bar.json');
    }
  }
  const index = data.images.findIndex(img => img.id === id);
  if (index === -1) {
    return res.status(404).send('Image not found');
  }
  // Delete image file
  const img = data.images[index];
  if (img.src) {
    const imgPath = path.join(WORKSPACE_ROOT, 'Website', img.src);
    if (fs.existsSync(imgPath)) {
      try {
        fs.unlinkSync(imgPath);
      } catch (err) {
        console.error('Failed to delete image file:', imgPath, err);
      }
    }
  }
  data.images.splice(index, 1);
  fs.writeFileSync(THE_BAR_JSON, JSON.stringify(data, null, 2));
  res.json({ message: 'Image deleted successfully' });
});

// Helper: Download image for others (products/flavours)
async function downloadOthersImage(url, filename) {
  const protocol = url.startsWith('https') ? https : http;
  const imagesDir = path.join(__dirname, 'images/others');
  return new Promise((resolve, reject) => {
    protocol.get(url, (response) => {
      if (response.statusCode !== 200) {
        reject(new Error(`Failed to download image: ${response.statusCode}`));
        return;
      }
      const filePath = path.join(imagesDir, filename);
      const fileStream = fs.createWriteStream(filePath);
      response.pipe(fileStream);
      fileStream.on('finish', () => {
        fileStream.close();
        resolve(filename);
      });
      fileStream.on('error', (err) => {
        fs.unlink(filePath, () => {});
        reject(err);
      });
    }).on('error', reject);
  });
}

// POST /api/products - add a new product (with main flavour and image download)
app.post('/api/products', async (req, res) => {
  const { name, categoryId, flavour, secret } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).send('Forbidden');
  }
  if (!name || !categoryId || !flavour || !flavour.name || !flavour.description || !flavour.price || !flavour.image_url) {
    return res.status(400).json({ error: 'Missing required fields' });
  }
  try {
    const othersPath = path.join(__dirname, 'src/data/others.json');
    const imagesDir = path.join(__dirname, 'images/others');
    let others = JSON.parse(fs.readFileSync(othersPath, 'utf-8'));
    // Generate product id
    const id = name.toLowerCase().replace(/\s+/g, '-');
    if (others.products.some(p => p.id === id)) {
      return res.status(400).json({ error: 'Product with this name already exists' });
    }
    // Download main flavour image
    const timestamp = Date.now();
    const randomStr = Math.random().toString(36).substring(7);
    const extension = path.extname(flavour.image_url) || '.jpg';
    const flavourImageFilename = `${id}-main-${timestamp}-${randomStr}${extension}`;
    await downloadOthersImage(flavour.image_url, flavourImageFilename);
    // Build product
    const newProduct = {
      id,
      name,
      categoryId,
      visible: true,
      flavors: [
        {
          id: 'main',
          name: flavour.name,
          description: flavour.description,
          price: parseFloat(flavour.price),
          image: flavourImageFilename,
          available: true,
          visible: true
        }
      ]
    };
    others.products.push(newProduct);
    fs.writeFileSync(othersPath, JSON.stringify(others, null, 2));
    res.json(newProduct);
  } catch (error) {
    console.error('Error adding product:', error);
    res.status(500).json({ error: 'Failed to add product: ' + error.message });
  }
});

// GET /api/products - list all products
app.get('/api/products', (req, res) => {
  try {
    const others = JSON.parse(fs.readFileSync(path.join(__dirname, 'src/data/others.json'), 'utf-8'));
    res.json(others.products || []);
  } catch (error) {
    res.status(500).json({ error: 'Failed to read products data' });
  }
});

// DELETE /api/products/:id - delete a product and all its flavours/images
app.delete('/api/products/:id', (req, res) => {
  const { secret } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).send('Forbidden');
  }
  try {
    const othersPath = path.join(__dirname, 'src/data/others.json');
    const imagesDir = path.join(__dirname, 'images/others');
    let others = JSON.parse(fs.readFileSync(othersPath, 'utf-8'));
    const productIndex = others.products.findIndex(p => p.id === req.params.id);
    if (productIndex === -1) {
      return res.status(404).json({ error: 'Product not found' });
    }
    const product = others.products[productIndex];
    // Delete all flavour images
    if (Array.isArray(product.flavors)) {
      for (const flavour of product.flavors) {
        if (flavour.image) {
          const flavourImagePath = path.join(imagesDir, flavour.image);
          if (fs.existsSync(flavourImagePath)) {
            try { fs.unlinkSync(flavourImagePath); } catch (e) { console.error('Failed to delete flavour image:', flavour.image, e); }
          }
        }
      }
    }
    // Optionally, delete product-level images if any (future-proof)
    if (product.image) {
      const productImagePath = path.join(imagesDir, product.image);
      if (fs.existsSync(productImagePath)) {
        try { fs.unlinkSync(productImagePath); } catch (e) { console.error('Failed to delete product image:', product.image, e); }
      }
    }
    others.products.splice(productIndex, 1);
    fs.writeFileSync(othersPath, JSON.stringify(others, null, 2));
    res.json({ message: 'Product and associated data deleted successfully' });
  } catch (error) {
    console.error('Error deleting product:', error);
    res.status(500).json({ error: 'Failed to delete product: ' + error.message });
  }
});

// PUT /api/products/:id - edit a product (name, category, visible)
app.put('/api/products/:id', (req, res) => {
  const { secret, name, categoryId, visible } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).send('Forbidden');
  }
  try {
    const othersPath = path.join(__dirname, 'src/data/others.json');
    let others = JSON.parse(fs.readFileSync(othersPath, 'utf-8'));
    const product = others.products.find(p => p.id === req.params.id);
    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }
    if (name) product.name = name;
    if (categoryId) product.categoryId = categoryId;
    if (typeof visible === 'boolean') product.visible = visible;
    fs.writeFileSync(othersPath, JSON.stringify(others, null, 2));
    res.json(product);
  } catch (error) {
    console.error('Error editing product:', error);
    res.status(500).json({ error: 'Failed to edit product: ' + error.message });
  }
});

// POST /api/products/:id/hide - toggle product visibility
app.post('/api/products/:id/hide', (req, res) => {
  const { secret } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).send('Forbidden');
  }
  try {
    const othersPath = path.join(__dirname, 'src/data/others.json');
    let others = JSON.parse(fs.readFileSync(othersPath, 'utf-8'));
    const product = others.products.find(p => p.id === req.params.id);
    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }
    product.visible = !product.visible;
    fs.writeFileSync(othersPath, JSON.stringify(others, null, 2));
    res.json({ id: product.id, visible: product.visible });
  } catch (error) {
    console.error('Error toggling product visibility:', error);
    res.status(500).json({ error: 'Failed to toggle product visibility: ' + error.message });
  }
});

// POST /api/products/:id/flavours - add a flavour (with image download)
app.post('/api/products/:id/flavours', async (req, res) => {
  const { name, description, price, image_url, available, visible, secret } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).send('Forbidden');
  }
  if (!name || !description || !price || !image_url) {
    return res.status(400).json({ error: 'Missing required fields' });
  }
  try {
    const othersPath = path.join(__dirname, 'src/data/others.json');
    const imagesDir = path.join(__dirname, 'images/others');
    let others = JSON.parse(fs.readFileSync(othersPath, 'utf-8'));
    const product = others.products.find(p => p.id === req.params.id);
    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }
    // Generate flavour id
    const flavourId = name.toLowerCase().replace(/\s+/g, '-') + '-' + Date.now();
    // Download image
    const timestamp = Date.now();
    const randomStr = Math.random().toString(36).substring(7);
    const extension = path.extname(image_url) || '.jpg';
    const flavourImageFilename = `${product.id}-${flavourId}-${timestamp}-${randomStr}${extension}`;
    await downloadOthersImage(image_url, flavourImageFilename);
    const newFlavour = {
      id: flavourId,
      name,
      description,
      price: parseFloat(price),
      image: flavourImageFilename,
      available: typeof available === 'boolean' ? available : true,
      visible: typeof visible === 'boolean' ? visible : true
    };
    product.flavors.push(newFlavour);
    fs.writeFileSync(othersPath, JSON.stringify(others, null, 2));
    res.json(newFlavour);
  } catch (error) {
    console.error('Error adding flavour:', error);
    res.status(500).json({ error: 'Failed to add flavour: ' + error.message });
  }
});

// GET /api/products/:id/flavours - list all flavours for a product
app.get('/api/products/:id/flavours', (req, res) => {
  try {
    const others = JSON.parse(fs.readFileSync(path.join(__dirname, 'src/data/others.json'), 'utf-8'));
    const product = others.products.find(p => p.id === req.params.id);
    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }
    res.json(product.flavors || []);
  } catch (error) {
    res.status(500).json({ error: 'Failed to read flavours data' });
  }
});

// DELETE /api/products/:id/flavours/:flavourId - delete a flavour and its image
app.delete('/api/products/:id/flavours/:flavourId', (req, res) => {
  const { secret } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).send('Forbidden');
  }
  try {
    const othersPath = path.join(__dirname, 'src/data/others.json');
    const imagesDir = path.join(__dirname, 'images/others');
    let others = JSON.parse(fs.readFileSync(othersPath, 'utf-8'));
    const product = others.products.find(p => p.id === req.params.id);
    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }
    const flavourIndex = product.flavors.findIndex(f => f.id === req.params.flavourId);
    if (flavourIndex === -1) {
      return res.status(404).json({ error: 'Flavour not found' });
    }
    const flavour = product.flavors[flavourIndex];
    if (flavour.image) {
      const flavourImagePath = path.join(imagesDir, flavour.image);
      if (fs.existsSync(flavourImagePath)) {
        try { fs.unlinkSync(flavourImagePath); } catch (e) { console.error('Failed to delete flavour image:', flavour.image, e); }
      }
    }
    product.flavors.splice(flavourIndex, 1);
    fs.writeFileSync(othersPath, JSON.stringify(others, null, 2));
    res.json({ message: 'Flavour deleted successfully' });
  } catch (error) {
    console.error('Error deleting flavour:', error);
    res.status(500).json({ error: 'Failed to delete flavour: ' + error.message });
  }
});

// PUT /api/products/:id/flavours/:flavourId - edit a flavour
app.put('/api/products/:id/flavours/:flavourId', async (req, res) => {
  const { secret, name, description, price, available, visible, image_url } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).send('Forbidden');
  }
  try {
    const othersPath = path.join(__dirname, 'src/data/others.json');
    const imagesDir = path.join(__dirname, 'images/others');
    let others = JSON.parse(fs.readFileSync(othersPath, 'utf-8'));
    const product = others.products.find(p => p.id === req.params.id);
    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }
    const flavour = product.flavors.find(f => f.id === req.params.flavourId);
    if (!flavour) {
      return res.status(404).json({ error: 'Flavour not found' });
    }
    if (name) flavour.name = name;
    if (description) flavour.description = description;
    if (price) flavour.price = parseFloat(price);
    if (typeof available === 'boolean') flavour.available = available;
    if (typeof visible === 'boolean') flavour.visible = visible;
    if (image_url) {
      // Delete old image if exists
      if (flavour.image) {
        const oldImagePath = path.join(imagesDir, flavour.image);
        if (fs.existsSync(oldImagePath)) {
          try { fs.unlinkSync(oldImagePath); } catch (e) { console.error('Failed to delete old flavour image:', flavour.image, e); }
        }
      }
      // Download new image
      const timestamp = Date.now();
      const randomStr = Math.random().toString(36).substring(7);
      const extension = path.extname(image_url) || '.jpg';
      const newImageFilename = `${product.id}-${flavour.id}-${timestamp}-${randomStr}${extension}`;
      await downloadOthersImage(image_url, newImageFilename);
      flavour.image = newImageFilename;
    }
    fs.writeFileSync(othersPath, JSON.stringify(others, null, 2));
    res.json(flavour);
  } catch (error) {
    console.error('Error editing flavour:', error);
    res.status(500).json({ error: 'Failed to edit flavour: ' + error.message });
  }
});

// POST /api/products/:id/flavours/:flavourId/hide - toggle flavour visibility
app.post('/api/products/:id/flavours/:flavourId/hide', (req, res) => {
  const { secret } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).send('Forbidden');
  }
  try {
    const othersPath = path.join(__dirname, 'src/data/others.json');
    let others = JSON.parse(fs.readFileSync(othersPath, 'utf-8'));
    const product = others.products.find(p => p.id === req.params.id);
    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }
    const flavour = product.flavors.find(f => f.id === req.params.flavourId);
    if (!flavour) {
      return res.status(404).json({ error: 'Flavour not found' });
    }
    flavour.visible = !flavour.visible;
    fs.writeFileSync(othersPath, JSON.stringify(others, null, 2));
    res.json({ id: flavour.id, visible: flavour.visible });
  } catch (error) {
    console.error('Error toggling flavour visibility:', error);
    res.status(500).json({ error: 'Failed to toggle flavour visibility: ' + error.message });
  }
});

// POST /api/categories/:id/hide - toggle category visibility
app.post('/api/categories/:id/hide', (req, res) => {
  const { secret } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).send('Forbidden');
  }
  try {
    const othersPath = path.join(__dirname, 'src/data/others.json');
    let others = JSON.parse(fs.readFileSync(othersPath, 'utf-8'));
    const category = others.categories.find(cat => cat.id === req.params.id);
    if (!category) {
      return res.status(404).json({ error: 'Category not found' });
    }
    category.visible = !category.visible;
    fs.writeFileSync(othersPath, JSON.stringify(others, null, 2));
    res.json({ id: category.id, visible: category.visible });
  } catch (error) {
    console.error('Error toggling category visibility:', error);
    res.status(500).json({ error: 'Failed to toggle category visibility: ' + error.message });
  }
});

// GET /api/discounts - list all discounts with their status
app.get('/api/discounts', (req, res) => {
  let discounts = [];
  if (fs.existsSync(DISCOUNTS_FILE)) {
    try {
      discounts = JSON.parse(fs.readFileSync(DISCOUNTS_FILE, 'utf-8'));
    } catch (e) {
      return res.status(500).json({ error: 'Could not parse discounts.json', discounts: [] });
    }
  }
  res.json(discounts);
});

// POST /api/discounts - add a new discount
app.post('/api/discounts', (req, res) => {
  const { title, images, occurrence, description, visibility, secret } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).send('Forbidden');
  }
  let discounts = [];
  if (fs.existsSync(DISCOUNTS_FILE)) {
    try {
      discounts = JSON.parse(fs.readFileSync(DISCOUNTS_FILE, 'utf-8'));
    } catch (e) {
      return res.status(500).send('Could not parse discounts.json');
    }
  }
  const newDiscount = {
    title,
    images: Array.isArray(images) ? images : [],
    occurrence,
    description,
    visibility: visibility || 'visible'
  };
  discounts.unshift(newDiscount);
  fs.writeFileSync(DISCOUNTS_FILE, JSON.stringify(discounts, null, 2));
  res.json(newDiscount);
});

// DELETE /api/discounts/:index - delete a discount by index
app.delete('/api/discounts/:index', (req, res) => {
  const { secret } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).send('Forbidden');
  }
  const idx = parseInt(req.params.index, 10);
  if (isNaN(idx)) {
    return res.status(400).send('Invalid index');
  }
  let discounts = [];
  if (fs.existsSync(DISCOUNTS_FILE)) {
    try {
      discounts = JSON.parse(fs.readFileSync(DISCOUNTS_FILE, 'utf-8'));
    } catch (e) {
      return res.status(500).send('Could not parse discounts.json');
    }
  }
  if (idx < 0 || idx >= discounts.length) {
    return res.status(404).send('Discount not found');
  }
  discounts.splice(idx, 1);
  fs.writeFileSync(DISCOUNTS_FILE, JSON.stringify(discounts, null, 2));
  res.send('Discount deleted!');
});

// POST /api/discounts/:index/toggle-visibility - toggle a discount's visibility
app.post('/api/discounts/:index/toggle-visibility', (req, res) => {
  const { secret } = req.body;
  if (secret !== API_SECRET) {
    return res.status(403).send('Forbidden');
  }
  const idx = parseInt(req.params.index, 10);
  if (isNaN(idx)) {
    return res.status(400).send('Invalid index');
  }
  let discounts = [];
  if (fs.existsSync(DISCOUNTS_FILE)) {
    try {
      discounts = JSON.parse(fs.readFileSync(DISCOUNTS_FILE, 'utf-8'));
    } catch (e) {
      return res.status(500).send('Could not parse discounts.json');
    }
  }
  if (idx < 0 || idx >= discounts.length) {
    return res.status(404).send('Discount not found');
  }
  discounts[idx].visibility = discounts[idx].visibility === 'visible' ? 'hidden' : 'visible';
  fs.writeFileSync(DISCOUNTS_FILE, JSON.stringify(discounts, null, 2));
  res.json({ index: idx, visibility: discounts[idx].visibility });
});

app.listen(PORT, () => {
  console.log('API server running on port ' + PORT);
});
# But First Cacao

A modern web application built with React, TypeScript, Vite, and Material-UI.

## Getting Started

### Prerequisites

- Node.js (version 18 or higher)
- npm or yarn

### Installation

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   # or
   yarn install
   ```

### Development

To start the development server:

```bash
npm run dev
# or
yarn dev
```

The application will be available at `http://localhost:5173`

### Building for Production

To create a production build:

```bash
npm run build
# or
yarn build
```

The build artifacts will be stored in the `dist/` directory.

## Project Structure

- `src/` - Source files
  - `main.tsx` - Application entry point
  - `App.tsx` - Main application component
  - `index.css` - Global styles
- `public/` - Static assets
- `vite.config.ts` - Vite configuration
- `tsconfig.json` - TypeScript configuration
- `package.json` - Project dependencies and scripts

## Technologies Used

- React 18.2.0
- TypeScript 5.2.2
- Vite 5.1.0
- Material-UI (MUI) 5.15.7
- React Router 6.22.0
- ESLint 8.56.0
- Emotion (for styled components) 11.11.3

## License 